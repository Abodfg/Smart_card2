import { sql } from "drizzle-orm";
import { pgTable, text, integer, serial, timestamp, varchar, bigint } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// الأصناف الرئيسية للمنتجات (شحن الألعاب، بطاقات الهدايا، إلخ)
export const productCategories = pgTable("product_categories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(), // اسم الصنف (مثل "شحن الألعاب")
  description: text("description").notNull(), // وصف الصنف
  icon: varchar("icon", { length: 100 }), // رمز أو أيقونة اختيارية
  sortOrder: integer("sort_order").default(0).notNull(), // ترتيب العرض
  isActive: integer("is_active").default(1).notNull(), // 1 = مفعل، 0 = معطل
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at"), // آخر تحديث
});

export const users = pgTable("users", {
  id: bigint("user_id", { mode: "number" }).primaryKey().notNull(),
  username: varchar("username", { length: 255 }).notNull(),
  balance: integer("balance").default(0).notNull(),
  dateJoined: timestamp("date_joined").defaultNow().notNull(),
  totalOrders: integer("total_orders").default(0).notNull(),
  lastActive: timestamp("last_active").defaultNow().notNull(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  categoryId: integer("category_id").notNull().references(() => productCategories.id), // ربط مع الصنف الرئيسي
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description").notNull(),
  detailedDescription: text("detailed_description"), // وصف تفصيلي إضافي
  shippingType: varchar("shipping_type", { length: 20 }).notNull(), // 'code' | 'id' | 'phone' | 'email'
  estimatedCompletionTime: integer("estimated_completion_time").default(15), // الوقت المتوقع بالدقائق
  isActive: integer("is_active").default(1).notNull(), // 1 = مفعل، 0 = معطل
  sortOrder: integer("sort_order").default(0).notNull(), // ترتيب العرض
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at"), // آخر تحديث
});

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull().references(() => products.id),
  name: varchar("name", { length: 255 }).notNull(),
  price: integer("price").notNull(), // Price in Telegram Stars
  description: text("description").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number" }).notNull().references(() => users.id),
  productId: integer("product_id").notNull().references(() => products.id),
  categoryId: integer("category_id").notNull().references(() => categories.id),
  inputData: text("input_data").notNull(),
  status: varchar("status", { length: 20 }).default('pending').notNull(), // 'pending' | 'completed' | 'cancelled'
  paidAmount: integer("paid_amount"), // السعر المدفوع فعلياً عند إنشاء الطلب (للإرجاع الصحيح)
  adminNotes: text("admin_notes"),
  codeIfAny: text("code_if_any"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
});

// طلبات شحن الرصيد
export const balanceTopupRequests = pgTable("balance_topup_requests", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number" }).notNull().references(() => users.id),
  amount: integer("amount").notNull(), // المبلغ المطلوب شحنه
  status: varchar("status", { length: 20 }).default('pending').notNull(), // 'pending' | 'approved' | 'rejected'
  paymentMethod: varchar("payment_method", { length: 50 }), // طريقة الدفع المقترحة
  adminNotes: text("admin_notes"), // ملاحظات الإدارة
  approvedBy: bigint("approved_by", { mode: "number" }).references(() => users.id), // من وافق على الطلب
  requestDetails: text("request_details"), // تفاصيل إضافية من المستخدم
  createdAt: timestamp("created_at").defaultNow().notNull(),
  processedAt: timestamp("processed_at"), // وقت المعالجة
});

// سجل معاملات الرصيد
export const balanceTransactions = pgTable("balance_transactions", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number" }).notNull().references(() => users.id),
  type: varchar("type", { length: 20 }).notNull(), // 'credit' | 'debit' | 'topup' | 'purchase'
  amount: integer("amount").notNull(), // المبلغ (موجب للإضافة، سالب للخصم)
  balanceBefore: integer("balance_before").notNull(), // الرصيد قبل المعاملة
  balanceAfter: integer("balance_after").notNull(), // الرصيد بعد المعاملة
  description: text("description").notNull(), // وصف المعاملة
  relatedOrderId: integer("related_order_id").references(() => orders.id), // ربط بطلب إن وجد
  relatedTopupId: integer("related_topup_id").references(() => balanceTopupRequests.id), // ربط بطلب شحن
  processedBy: bigint("processed_by", { mode: "number" }).references(() => users.id), // من عالج المعاملة
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Insert schemas - مخططات الإدخال
export const insertProductCategorySchema = createInsertSchema(productCategories).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  dateJoined: true,
  lastActive: true,
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCategorySchema = createInsertSchema(categories).omit({
  id: true,
  createdAt: true,
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export const insertBalanceTopupRequestSchema = createInsertSchema(balanceTopupRequests).omit({
  id: true,
  createdAt: true,
  processedAt: true,
});

export const insertBalanceTransactionSchema = createInsertSchema(balanceTransactions).omit({
  id: true,
  createdAt: true,
});

// Types - أنواع البيانات
export type ProductCategory = typeof productCategories.$inferSelect;
export type InsertProductCategory = z.infer<typeof insertProductCategorySchema>;
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Category = typeof categories.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type BalanceTopupRequest = typeof balanceTopupRequests.$inferSelect;
export type InsertBalanceTopupRequest = z.infer<typeof insertBalanceTopupRequestSchema>;
export type BalanceTransaction = typeof balanceTransactions.$inferSelect;
export type InsertBalanceTransaction = z.infer<typeof insertBalanceTransactionSchema>;
