/**
 * Startup validation checks to ensure all required environment variables and services are available
 */

export function validateEnvironment(): void {
  const requiredEnvVars = [
    'USER_BOT_TOKEN',
    'ADMIN_BOT_TOKEN', 
    'DATABASE_URL'
  ];

  const missing = requiredEnvVars.filter(envVar => !process.env[envVar]);
  
  if (missing.length > 0) {
    console.error('❌ Missing required environment variables:', missing.join(', '));
    console.error('Please set these environment variables before starting the application.');
    process.exit(1);
  }

  console.log('✅ All required environment variables are set');
}

export function validateTokenFormat(): void {
  const userToken = process.env.USER_BOT_TOKEN;
  const adminToken = process.env.ADMIN_BOT_TOKEN;

  // Basic Telegram bot token format validation (number:alphanumeric)
  const tokenRegex = /^\d+:[A-Za-z0-9_-]+$/;

  if (!tokenRegex.test(userToken!)) {
    console.error('❌ Invalid USER_BOT_TOKEN format');
    process.exit(1);
  }

  if (!tokenRegex.test(adminToken!)) {
    console.error('❌ Invalid ADMIN_BOT_TOKEN format');
    process.exit(1);
  }

  console.log('✅ Bot tokens have valid format');
}

export async function validateDatabaseConnection(): Promise<void> {
  try {
    const { storage } = await import('../storage');
    // Try a simple operation to test DB connection
    await storage.getAllUsers();
    console.log('✅ Database connection successful');
  } catch (error) {
    console.error('❌ Database connection failed:', error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}