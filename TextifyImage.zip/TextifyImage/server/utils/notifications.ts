import { BOT_CONFIG } from '../config/bot-config';
import type { Order, User, Product, Category } from '@shared/schema';

export class NotificationService {
  static async sendToAdmins(message: string, keyboard?: any): Promise<void> {
    if (BOT_CONFIG.ADMIN_IDS.length === 0) {
      console.log('No admin IDs configured for notifications');
      return;
    }

    for (const adminId of BOT_CONFIG.ADMIN_IDS) {
      try {
        const requestBody: any = {
          chat_id: adminId,
          text: message,
          parse_mode: 'HTML',
        };

        if (keyboard) {
          requestBody.reply_markup = keyboard;
        }

        await fetch(`https://api.telegram.org/bot${BOT_CONFIG.ADMIN_BOT_TOKEN}/sendMessage`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(requestBody),
        });
      } catch (error) {
        console.error(`Failed to send notification to admin ${adminId}:`, error);
      }
    }
  }

  static async sendToUser(userId: number, message: string, keyboard?: any): Promise<void> {
    try {
      const requestBody: any = {
        chat_id: userId,
        text: message,
        parse_mode: 'HTML',
      };

      if (keyboard) {
        requestBody.reply_markup = keyboard;
      }

      await fetch(`https://api.telegram.org/bot${BOT_CONFIG.USER_BOT_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
      });
    } catch (error) {
      console.error(`Failed to send notification to user ${userId}:`, error);
    }
  }

  static async notifyNewOrder(order: Order, user: User, product: Product, category: Category): Promise<void> {
    const message = `🔔 <b>طلب جديد</b>
رقم الطلب: #${order.id}
المنتج: ${product.name}
الفئة: ${category.name}
من: @${user.username}
البيانات: ${order.inputData}
المبلغ: ⭐ ${category.price}
التاريخ: ${new Date(order.createdAt).toLocaleString('ar-EG')}`;

    const keyboard = {
      inline_keyboard: [
        [
          { text: '✅ تنفيذ الطلب', callback_data: `complete_order_${order.id}` },
          { text: '❌ إلغاء الطلب', callback_data: `cancel_order_${order.id}` }
        ]
      ]
    };

    await this.sendToAdmins(message, keyboard);
  }

  static async notifyOrderCompleted(order: Order, user: User, product: Product, category: Category, details: string): Promise<void> {
    const userMessage = BOT_CONFIG.MESSAGES.ORDER_COMPLETED
      .replace('{product}', product.name)
      .replace('{category}', category.name)
      .replace('{details}', details);

    await this.sendToUser(user.id, userMessage);

    // Also notify admins
    const adminMessage = `✅ <b>تم تنفيذ الطلب</b>
رقم الطلب: #${order.id}
المستخدم: @${user.username}
المنتج: ${product.name}
الفئة: ${category.name}`;

    await this.sendToAdmins(adminMessage);
  }

  static async notifyOrderCancelled(order: Order, user: User, reason: string, refundAmount?: number): Promise<void> {
    let userMessage = `❌ تم إلغاء طلبك #${order.id}
السبب: ${reason}`;

    // إضافة معلومات إرجاع النجوم إذا كانت متوفرة
    if (refundAmount && refundAmount > 0) {
      userMessage += `\n\n💰 تم إرجاع ${refundAmount} نجمة إلى رصيدك
✨ يمكنك استخدام النجوم المُرجعة في طلبات أخرى`;
    }

    await this.sendToUser(user.id, userMessage);
  }
}
