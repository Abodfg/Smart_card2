import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { startUserBot } from "./bots/user-bot";
import { startAdminBot } from "./bots/admin-bot";
import { validateEnvironment, validateTokenFormat, validateDatabaseConnection } from "./utils/startup-checks";

export async function registerRoutes(app: Express): Promise<Server> {
  // Validate environment and dependencies at startup
  console.log('🔍 Running startup checks...');
  validateEnvironment();
  validateTokenFormat();
  await validateDatabaseConnection();
  console.log('✅ Startup checks completed successfully');

  // API routes for bot management and statistics
  
  // Get order statistics
  app.get('/api/stats', async (req, res) => {
    try {
      const stats = await storage.getOrderStats();
      const totalUsers = (await storage.getAllUsers()).length;
      
      res.json({
        ...stats,
        totalUsers,
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch statistics' });
    }
  });

  // Get all orders
  app.get('/api/orders', async (req, res) => {
    try {
      const { status, user_id, userId } = req.query;
      let orders;
      
      // Support both user_id and userId query parameters
      const userIdParam = user_id || userId;
      
      if (userIdParam && typeof userIdParam === 'string') {
        // Filter orders by user ID
        const numericUserId = parseInt(userIdParam);
        if (!isNaN(numericUserId)) {
          orders = await storage.getOrdersByUser(numericUserId);
        } else {
          return res.status(400).json({ error: 'Invalid user ID format' });
        }
      } else if (status && typeof status === 'string') {
        orders = await storage.getOrdersByStatus(status);
      } else {
        const pendingOrders = await storage.getOrdersByStatus('pending');
        const completedOrders = await storage.getOrdersByStatus('completed');
        orders = [...pendingOrders, ...completedOrders];
      }
      
      res.json(orders);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch orders' });
    }
  });

  // Get all products
  app.get('/api/products', async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch products' });
    }
  });

  // Get all users
  app.get('/api/users', async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch users' });
    }
  });

  // Start the Telegram bots with better error handling
  console.log('🤖 Starting Telegram bots...');
  
  try {
    // Start bots without external timeout - let them handle their own connection
    const userBotPromise = startUserBot();
    const adminBotPromise = startAdminBot();
    
    // Don't wait for completion - let them start in background
    userBotPromise.then(() => {
      console.log('🎉 User bot connected and ready!');
    }).catch(err => {
      console.log(`⚠️ User bot connection issue: ${err.message}`);
    });
    
    adminBotPromise.then(() => {
      console.log('🎉 Admin bot connected and ready!');
    }).catch(err => {
      console.log(`⚠️ Admin bot connection issue: ${err.message}`);
    });
    
    console.log('✅ Bots are starting in background - server will continue');
  } catch (error) {
    console.error('🔥 Bot startup error:', error instanceof Error ? error.message : 'Unknown error');
    console.log('📡 Server continuing with API-only functionality');
  }

  const httpServer = createServer(app);
  return httpServer;
}
