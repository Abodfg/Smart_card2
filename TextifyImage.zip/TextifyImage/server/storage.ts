import { type User, type InsertUser, type Product, type InsertProduct, type Category, type InsertCategory, type Order, type InsertOrder, type ProductCategory, type InsertProductCategory, type BalanceTopupRequest, type InsertBalanceTopupRequest, type BalanceTransaction, type InsertBalanceTransaction } from "@shared/schema";
import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import { users, products, categories, orders, productCategories, balanceTopupRequests, balanceTransactions } from '@shared/schema';
import { eq, desc, and, asc } from 'drizzle-orm';
import { BOT_CONFIG } from './config/bot-config';

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserById(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;

  // Product Category operations (الأصناف الرئيسية)
  getProductCategory(id: number): Promise<ProductCategory | undefined>;
  getAllProductCategories(): Promise<ProductCategory[]>;
  getActiveProductCategories(): Promise<ProductCategory[]>;
  createProductCategory(category: InsertProductCategory): Promise<ProductCategory>;
  updateProductCategory(id: number, updates: Partial<ProductCategory>): Promise<ProductCategory | undefined>;
  deleteProductCategory(id: number): Promise<boolean>;

  // Product operations
  getProduct(id: number): Promise<Product | undefined>;
  getProductsByCategory(categoryId: number): Promise<Product[]>;
  getActiveProductsByCategory(categoryId: number): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, updates: Partial<Product>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  getAllProducts(): Promise<Product[]>;

  // Category operations (الفئات)
  getCategory(id: number): Promise<Category | undefined>;
  getCategoriesByProduct(productId: number): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, updates: Partial<Category>): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;

  // Order operations
  getOrder(id: number): Promise<Order | undefined>;
  getAllOrders(): Promise<Order[]>;
  getOrdersByUser(userId: number): Promise<Order[]>;
  getOrdersByStatus(status: string): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: number, updates: Partial<Order>): Promise<Order | undefined>;
  // Atomic order operations with transaction safety
  completeOrderAtomic(orderId: number, adminId: number, completionDetails: string): Promise<{ success: boolean; order?: Order; error?: string }>;
  cancelOrderAtomic(orderId: number, adminId: number, cancellationReason: string): Promise<{ success: boolean; order?: Order; error?: string }>;
  getOrderStats(): Promise<{
    totalOrders: number;
    pendingOrders: number;
    completedOrders: number;
    totalRevenue: number;
  }>;

  // Balance Topup Request operations
  createBalanceTopupRequest(request: InsertBalanceTopupRequest): Promise<BalanceTopupRequest>;
  getBalanceTopupRequest(id: number): Promise<BalanceTopupRequest | undefined>;
  getBalanceTopupRequestsByUser(userId: number): Promise<BalanceTopupRequest[]>;
  getBalanceTopupRequestsByStatus(status: string): Promise<BalanceTopupRequest[]>;
  updateBalanceTopupRequest(id: number, updates: Partial<BalanceTopupRequest>): Promise<BalanceTopupRequest | undefined>;
  
  // Balance Transaction operations
  createBalanceTransaction(transaction: InsertBalanceTransaction): Promise<BalanceTransaction>;
  getBalanceTransactionsByUser(userId: number): Promise<BalanceTransaction[]>;
  getUserBalanceHistory(userId: number, limit?: number): Promise<BalanceTransaction[]>;
  
  // Wallet operations
  addUserBalance(userId: number, amount: number, description: string, processedBy?: number, relatedTopupId?: number): Promise<BalanceTransaction>;
  deductUserBalance(userId: number, amount: number, description: string, processedBy?: number, relatedOrderId?: number): Promise<BalanceTransaction | null>;
  
  // Admin-only balance operations
  approveBalanceTopupRequest(requestId: number, adminId: number): Promise<{ success: boolean; transaction?: BalanceTransaction; error?: string }>;
  rejectBalanceTopupRequest(requestId: number, adminId: number, reason?: string): Promise<{ success: boolean; error?: string }>;
}

export class PostgreSQLStorage implements IStorage {
  private db: ReturnType<typeof drizzle>;
  private sql: ReturnType<typeof postgres>;

  constructor() {
    if (!process.env.DATABASE_URL) {
      throw new Error('DATABASE_URL environment variable is required');
    }
    this.sql = postgres(process.env.DATABASE_URL);
    this.db = drizzle(this.sql);
    this.initDatabase();
  }

  // Admin privilege validation - SECURITY: No hardcoded defaults allowed
  private isValidAdmin(adminId: number): boolean {
    // Use centralized admin configuration from BOT_CONFIG
    const adminIds = BOT_CONFIG.ADMIN_IDS;
    if (!adminIds || adminIds.length === 0) {
      console.error('SECURITY ERROR: No admin IDs configured in BOT_CONFIG');
      return false;
    }
    return adminIds.includes(adminId);
  }

  private async initDatabase() {
    // Seed database with sample data if tables are empty
    await this.seedDatabase();
  }

  private async seedDatabase() {
    try {
      // Check if product categories exist
      const categoryCount = await this.db.select().from(productCategories);
      
      if (categoryCount.length === 0) {
        // Insert sample product categories
        const sampleCategories = [
          {
            name: 'شحن الألعاب',
            description: 'شحن العملات والنقاط لجميع الألعاب الشعبية',
            icon: '🎮',
            sortOrder: 1,
            isActive: 1,
          },
          {
            name: 'بطاقات الهدايا',
            description: 'بطاقات هدايا لمختلف المتاجر والخدمات',
            icon: '🎁',
            sortOrder: 2,
            isActive: 1,
          },
          {
            name: 'خدمات التطبيقات',
            description: 'اشتراكات وخدمات التطبيقات المختلفة',
            icon: '📱',
            sortOrder: 3,
            isActive: 1,
          }
        ];

        for (const category of sampleCategories) {
          const [insertedCategory] = await this.db.insert(productCategories).values(category).returning();
          
          // Insert sample products for each category
          if (insertedCategory.name === 'شحن الألعاب') {
            const gameProducts = [
              {
                categoryId: insertedCategory.id,
                name: 'ببجي موبايل',
                description: 'شحن شدات ببجي موبايل',
                shippingType: 'id',
                sortOrder: 1,
                isActive: 1,
              },
              {
                categoryId: insertedCategory.id,
                name: 'فري فاير',
                description: 'شحن الماس فري فاير',
                shippingType: 'id',
                sortOrder: 2,
                isActive: 1,
              },
              {
                categoryId: insertedCategory.id,
                name: 'كول أوف ديوتي موبايل',
                description: 'شحن نقاط كول أوف ديوتي',
                shippingType: 'id',
                sortOrder: 3,
                isActive: 1,
              }
            ];

            for (const product of gameProducts) {
              const [insertedProduct] = await this.db.insert(products).values(product).returning();
              
              // Insert sample categories (variants) for each product
              const variants = [
                { name: '60 شدة', price: 60, description: '60 شدة ببجي موبايل' },
                { name: '300 شدة', price: 250, description: '300 شدة ببجي موبايل' },
                { name: '600 شدة', price: 450, description: '600 شدة ببجي موبايل' },
              ];

              for (const variant of variants) {
                await this.db.insert(categories).values({
                  productId: insertedProduct.id,
                  ...variant
                });
              }
            }
          }
        }
      }
    } catch (error) {
      console.error('Error seeding database:', error);
    }
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserById(id: string): Promise<User | undefined> {
    const numericId = parseInt(id);
    if (isNaN(numericId)) return undefined;
    return this.getUser(numericId);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await this.db.insert(users).values(user).returning();
    return newUser;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await this.db.update(users).set(updates).where(eq(users.id, id)).returning();
    return updatedUser;
  }

  async getAllUsers(): Promise<User[]> {
    return await this.db.select().from(users).orderBy(desc(users.lastActive));
  }

  // Product Category operations (الأصناف الرئيسية)
  async getProductCategory(id: number): Promise<ProductCategory | undefined> {
    const result = await this.db.select().from(productCategories).where(eq(productCategories.id, id)).limit(1);
    return result[0];
  }

  async getAllProductCategories(): Promise<ProductCategory[]> {
    return await this.db.select().from(productCategories).orderBy(asc(productCategories.sortOrder));
  }

  async getActiveProductCategories(): Promise<ProductCategory[]> {
    return await this.db.select().from(productCategories)
      .where(eq(productCategories.isActive, 1))
      .orderBy(asc(productCategories.sortOrder));
  }

  async createProductCategory(category: InsertProductCategory): Promise<ProductCategory> {
    const [newCategory] = await this.db.insert(productCategories).values(category).returning();
    return newCategory;
  }

  async updateProductCategory(id: number, updates: Partial<ProductCategory>): Promise<ProductCategory | undefined> {
    const updateData = { ...updates };
    if (Object.keys(updates).length > 0) {
      updateData.updatedAt = new Date();
    }
    const [updatedCategory] = await this.db.update(productCategories).set(updateData).where(eq(productCategories.id, id)).returning();
    return updatedCategory;
  }

  async deleteProductCategory(id: number): Promise<boolean> {
    // 🛡️ SECURITY GUARD: Check if category has associated products before deletion
    console.log('🗑️ Attempting to delete product category:', id);
    
    // First check if category exists
    const category = await this.getProductCategory(id);
    if (!category) {
      console.warn('⚠️ Cannot delete non-existent category:', id);
      return false;
    }
    
    // Check for associated products
    const associatedProducts = await this.db.select().from(products).where(eq(products.categoryId, id));
    if (associatedProducts.length > 0) {
      console.error('❌ Cannot delete category with associated products:', {
        categoryId: id,
        categoryName: category.name,
        associatedProductsCount: associatedProducts.length,
        associatedProducts: associatedProducts.map(p => ({ id: p.id, name: p.name }))
      });
      throw new Error(`Cannot delete category "${category.name}" - it has ${associatedProducts.length} associated product(s). Delete products first.`);
    }
    
    // Check for existing orders using this category
    const associatedOrders = await this.db.select().from(orders).where(eq(orders.categoryId, id)).limit(1);
    if (associatedOrders.length > 0) {
      console.error('❌ Cannot delete category with existing orders:', {
        categoryId: id,
        categoryName: category.name,
        hasOrders: true
      });
      throw new Error(`Cannot delete category "${category.name}" - it has existing orders. Archive instead of deleting.`);
    }
    
    console.log('✅ Safe to delete category:', {
      categoryId: id,
      categoryName: category.name,
      timestamp: new Date().toISOString()
    });
    
    const result = await this.db.delete(productCategories).where(eq(productCategories.id, id)).returning({ id: productCategories.id });
    
    if (result.length > 0) {
      console.log('✅ Category deleted successfully:', {
        deletedCategoryId: result[0].id,
        categoryName: category.name
      });
    }
    
    return result.length > 0;
  }

  // Product operations
  async getProduct(id: number): Promise<Product | undefined> {
    const result = await this.db.select().from(products).where(eq(products.id, id)).limit(1);
    return result[0];
  }

  async getProductsByCategory(categoryId: number): Promise<Product[]> {
    return await this.db.select().from(products)
      .where(eq(products.categoryId, categoryId))
      .orderBy(asc(products.sortOrder));
  }

  async getActiveProductsByCategory(categoryId: number): Promise<Product[]> {
    return await this.db.select().from(products)
      .where(and(eq(products.categoryId, categoryId), eq(products.isActive, 1)))
      .orderBy(asc(products.sortOrder));
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await this.db.insert(products).values(product).returning();
    return newProduct;
  }

  async updateProduct(id: number, updates: Partial<Product>): Promise<Product | undefined> {
    const updateData = { ...updates };
    if (Object.keys(updates).length > 0) {
      updateData.updatedAt = new Date();
    }
    const [updatedProduct] = await this.db.update(products).set(updateData).where(eq(products.id, id)).returning();
    return updatedProduct;
  }

  async deleteProduct(id: number): Promise<boolean> {
    const result = await this.db.delete(products).where(eq(products.id, id)).returning({ id: products.id });
    return result.length > 0;
  }

  async getAllProducts(): Promise<Product[]> {
    return await this.db.select().from(products).orderBy(desc(products.createdAt));
  }

  // Category operations (الفئات)
  async getCategory(id: number): Promise<Category | undefined> {
    const result = await this.db.select().from(categories).where(eq(categories.id, id)).limit(1);
    return result[0];
  }

  async getCategoriesByProduct(productId: number): Promise<Category[]> {
    return await this.db.select().from(categories).where(eq(categories.productId, productId));
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await this.db.insert(categories).values(category).returning();
    return newCategory;
  }

  async updateCategory(id: number, updates: Partial<Category>): Promise<Category | undefined> {
    const [updatedCategory] = await this.db.update(categories).set(updates).where(eq(categories.id, id)).returning();
    return updatedCategory;
  }

  async deleteCategory(id: number): Promise<boolean> {
    const result = await this.db.delete(categories).where(eq(categories.id, id)).returning({ id: categories.id });
    return result.length > 0;
  }

  // Order operations
  async getOrder(id: number): Promise<Order | undefined> {
    const result = await this.db.select().from(orders).where(eq(orders.id, id)).limit(1);
    return result[0];
  }

  async getAllOrders(): Promise<Order[]> {
    return await this.db.select().from(orders).orderBy(desc(orders.createdAt));
  }

  async getOrdersByUser(userId: number): Promise<Order[]> {
    return await this.db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt));
  }

  async getOrdersByStatus(status: string): Promise<Order[]> {
    return await this.db.select().from(orders).where(eq(orders.status, status)).orderBy(desc(orders.createdAt));
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const [newOrder] = await this.db.insert(orders).values(order).returning();
    
    // Update user's total orders
    const user = await this.getUser(order.userId);
    if (user) {
      await this.updateUser(order.userId, { totalOrders: user.totalOrders + 1 });
    }
    
    return newOrder;
  }

  async updateOrder(id: number, updates: Partial<Order>): Promise<Order | undefined> {
    const updateData = { ...updates };
    if (updates.status === 'completed' && !updates.completedAt) {
      updateData.completedAt = new Date();
    }
    
    const [updatedOrder] = await this.db.update(orders).set(updateData).where(eq(orders.id, id)).returning();
    return updatedOrder;
  }

  // Atomic order completion with transaction safety
  async completeOrderAtomic(orderId: number, adminId: number, completionDetails: string): Promise<{ success: boolean; order?: Order; error?: string }> {
    return await this.db.transaction(async (tx) => {
      try {
        // First, check if order exists and is still pending (with SELECT FOR UPDATE lock)
        const [existingOrder] = await tx.select().from(orders)
          .where(and(eq(orders.id, orderId), eq(orders.status, 'pending')))
          .for('update')
          .limit(1);
        
        if (!existingOrder) {
          return { 
            success: false, 
            error: 'الطلب غير موجود أو تم معالجته مسبقاً' 
          };
        }
        
        // Update order status atomically with conditional check
        const [updatedOrder] = await tx.update(orders)
          .set({
            status: 'completed',
            adminNotes: completionDetails,
            codeIfAny: completionDetails,
            completedAt: new Date()
          })
          .where(and(eq(orders.id, orderId), eq(orders.status, 'pending')))
          .returning();
        
        if (!updatedOrder) {
          return { 
            success: false, 
            error: 'فشل في تحديث حالة الطلب - تم معالجته من قبل مشرف آخر' 
          };
        }
        
        return { 
          success: true, 
          order: updatedOrder 
        };
      } catch (error) {
        console.error('Error in completeOrderAtomic:', error);
        return { 
          success: false, 
          error: 'حدث خطأ أثناء إكمال الطلب' 
        };
      }
    });
  }

  // Atomic order cancellation with transaction safety and refund
  async cancelOrderAtomic(orderId: number, adminId: number, cancellationReason: string): Promise<{ success: boolean; order?: Order; error?: string }> {
    return await this.db.transaction(async (tx) => {
      try {
        // First, check if order exists and is still pending (with SELECT FOR UPDATE lock)
        const [existingOrder] = await tx.select().from(orders)
          .where(and(eq(orders.id, orderId), eq(orders.status, 'pending')))
          .for('update')
          .limit(1);
        
        if (!existingOrder) {
          return { 
            success: false, 
            error: 'الطلب غير موجود أو تم معالجته مسبقاً' 
          };
        }
        
        // Process refund if there was a paid amount
        if (existingOrder.paidAmount && existingOrder.paidAmount > 0) {
          // Get current user balance for validation
          const [currentUser] = await tx.select().from(users)
            .where(eq(users.id, existingOrder.userId))
            .limit(1);
          
          if (!currentUser) {
            return { 
              success: false, 
              error: 'لم يتم العثور على بيانات العميل' 
            };
          }
          
          const newBalance = currentUser.balance + existingOrder.paidAmount;
          
          // Update user balance atomically
          await tx.update(users)
            .set({ balance: newBalance })
            .where(eq(users.id, existingOrder.userId));
          
          // Record the refund transaction
          await tx.insert(balanceTransactions).values({
            userId: existingOrder.userId,
            type: 'credit',
            amount: existingOrder.paidAmount,
            balanceBefore: currentUser.balance,
            balanceAfter: newBalance,
            description: `استرداد طلب ملغي #${orderId}`,
            relatedOrderId: orderId,
            processedBy: adminId
          });
        }
        
        // Update order status atomically with conditional check
        const [updatedOrder] = await tx.update(orders)
          .set({
            status: 'cancelled',
            adminNotes: cancellationReason
          })
          .where(and(eq(orders.id, orderId), eq(orders.status, 'pending')))
          .returning();
        
        if (!updatedOrder) {
          return { 
            success: false, 
            error: 'فشل في إلغاء الطلب - تم معالجته من قبل مشرف آخر' 
          };
        }
        
        return { 
          success: true, 
          order: updatedOrder 
        };
      } catch (error) {
        console.error('Error in cancelOrderAtomic:', error);
        return { 
          success: false, 
          error: 'حدث خطأ أثناء إلغاء الطلب' 
        };
      }
    });
  }

  async getOrderStats(): Promise<{
    totalOrders: number;
    pendingOrders: number;
    completedOrders: number;
    totalRevenue: number;
  }> {
    const allOrders = await this.db.select().from(orders);
    const pendingOrders = allOrders.filter(order => order.status === 'pending');
    const completedOrders = allOrders.filter(order => order.status === 'completed');
    
    // Calculate total revenue from completed orders
    let totalRevenue = 0;
    for (const order of completedOrders) {
      const category = await this.getCategory(order.categoryId);
      if (category) {
        totalRevenue += category.price;
      }
    }
    
    return {
      totalOrders: allOrders.length,
      pendingOrders: pendingOrders.length,
      completedOrders: completedOrders.length,
      totalRevenue,
    };
  }

  // Balance Topup Request operations
  async createBalanceTopupRequest(request: InsertBalanceTopupRequest): Promise<BalanceTopupRequest> {
    const [newRequest] = await this.db.insert(balanceTopupRequests).values(request).returning();
    return newRequest;
  }

  async getBalanceTopupRequest(id: number): Promise<BalanceTopupRequest | undefined> {
    const result = await this.db.select().from(balanceTopupRequests).where(eq(balanceTopupRequests.id, id)).limit(1);
    return result[0];
  }

  async getBalanceTopupRequestsByUser(userId: number): Promise<BalanceTopupRequest[]> {
    return await this.db.select().from(balanceTopupRequests)
      .where(eq(balanceTopupRequests.userId, userId))
      .orderBy(desc(balanceTopupRequests.createdAt));
  }

  async getBalanceTopupRequestsByStatus(status: string): Promise<BalanceTopupRequest[]> {
    return await this.db.select().from(balanceTopupRequests)
      .where(eq(balanceTopupRequests.status, status))
      .orderBy(desc(balanceTopupRequests.createdAt));
  }

  async updateBalanceTopupRequest(id: number, updates: Partial<BalanceTopupRequest>): Promise<BalanceTopupRequest | undefined> {
    const updateData = { ...updates };
    if (Object.keys(updates).length > 0 && (updates.status === 'approved' || updates.status === 'rejected')) {
      updateData.processedAt = new Date();
    }
    const [updatedRequest] = await this.db.update(balanceTopupRequests).set(updateData).where(eq(balanceTopupRequests.id, id)).returning();
    return updatedRequest;
  }

  // Secure admin-only approval/rejection methods
  async approveBalanceTopupRequest(requestId: number, adminId: number): Promise<{ success: boolean; transaction?: BalanceTransaction; error?: string }> {
    // Security check: Verify admin privileges (can be implemented with BOT_CONFIG check)
    const isValidAdmin = this.isValidAdmin(adminId);
    if (!isValidAdmin) {
      return { success: false, error: 'ليس لديك صلاحيات الإدارة المطلوبة' };
    }
    
    try {
      return await this.db.transaction(async (tx) => {
        // Get the request with lock
        const [request] = await tx.select().from(balanceTopupRequests)
          .where(eq(balanceTopupRequests.id, requestId))
          .for('update');
        
        if (!request) {
          return { success: false, error: 'طلب الشحن غير موجود' };
        }

        // Check if already processed (idempotent)
        if (request.status !== 'pending') {
          return { success: false, error: 'تم معالجة هذا الطلب مسبقاً' };
        }

        // Validate amount
        if (request.amount <= 0) {
          return { success: false, error: 'مبلغ الشحن غير صالح' };
        }

        // Update request status
        await tx.update(balanceTopupRequests).set({
          status: 'approved',
          approvedBy: adminId,
          processedAt: new Date(),
        }).where(eq(balanceTopupRequests.id, requestId));

        // Add balance to user (inline transaction logic)
        const [user] = await tx.select().from(users).where(eq(users.id, request.userId)).for('update');
        if (!user) {
          throw new Error('User not found');
        }

        const balanceBefore = user.balance;
        const balanceAfter = balanceBefore + request.amount;

        // Update user balance
        await tx.update(users).set({ balance: balanceAfter }).where(eq(users.id, request.userId));

        // Create transaction record
        const [balanceTransaction] = await tx.insert(balanceTransactions).values({
          userId: request.userId,
          type: 'credit',
          amount: request.amount,
          balanceBefore,
          balanceAfter,
          description: `شحن رصيد - طلب #${requestId}`,
          relatedTopupId: requestId,
          processedBy: adminId,
        }).returning();

        return { success: true, transaction: balanceTransaction };
      });
    } catch (error) {
      console.error('Error approving topup request:', error);
      return { success: false, error: 'حدث خطأ أثناء الموافقة على الطلب' };
    }
  }

  async rejectBalanceTopupRequest(requestId: number, adminId: number, reason?: string): Promise<{ success: boolean; error?: string }> {
    // Security check: Verify admin privileges
    const isValidAdmin = this.isValidAdmin(adminId);
    if (!isValidAdmin) {
      return { success: false, error: 'ليس لديك صلاحيات الإدارة المطلوبة' };
    }
    
    try {
      return await this.db.transaction(async (tx) => {
        // Get the request with lock
        const [request] = await tx.select().from(balanceTopupRequests)
          .where(eq(balanceTopupRequests.id, requestId))
          .for('update');
        
        if (!request) {
          return { success: false, error: 'طلب الشحن غير موجود' };
        }

        // Check if already processed (idempotent)
        if (request.status !== 'pending') {
          return { success: false, error: 'تم معالجة هذا الطلب مسبقاً' };
        }

        // Update request status
        await tx.update(balanceTopupRequests).set({
          status: 'rejected',
          approvedBy: adminId,
          processedAt: new Date(),
          adminNotes: reason || 'تم رفض الطلب من قبل الإدارة',
        }).where(eq(balanceTopupRequests.id, requestId));

        return { success: true };
      });
    } catch (error) {
      console.error('Error rejecting topup request:', error);
      return { success: false, error: 'حدث خطأ أثناء رفض الطلب' };
    }
  }

  // Balance Transaction operations
  async createBalanceTransaction(transaction: InsertBalanceTransaction): Promise<BalanceTransaction> {
    const [newTransaction] = await this.db.insert(balanceTransactions).values(transaction).returning();
    return newTransaction;
  }

  async getBalanceTransactionsByUser(userId: number): Promise<BalanceTransaction[]> {
    return await this.db.select().from(balanceTransactions)
      .where(eq(balanceTransactions.userId, userId))
      .orderBy(desc(balanceTransactions.createdAt));
  }

  async getUserBalanceHistory(userId: number, limit: number = 50): Promise<BalanceTransaction[]> {
    return await this.db.select().from(balanceTransactions)
      .where(eq(balanceTransactions.userId, userId))
      .orderBy(desc(balanceTransactions.createdAt))
      .limit(limit);
  }

  // Wallet operations with transaction safety
  async addUserBalance(userId: number, amount: number, description: string, processedBy?: number, relatedTopupId?: number): Promise<BalanceTransaction> {
    // Validate amount
    if (amount <= 0) {
      throw new Error('Amount must be positive');
    }

    // Use database transaction for atomicity
    return await this.db.transaction(async (tx) => {
      // Get current user with lock
      const [user] = await tx.select().from(users).where(eq(users.id, userId)).for('update');
      if (!user) {
        throw new Error('User not found');
      }

      const balanceBefore = user.balance;
      const balanceAfter = balanceBefore + amount;

      // Update user balance
      await tx.update(users).set({ balance: balanceAfter }).where(eq(users.id, userId));

      // Create transaction record
      const [transaction] = await tx.insert(balanceTransactions).values({
        userId,
        type: 'credit',
        amount,
        balanceBefore,
        balanceAfter,
        description,
        relatedTopupId,
        processedBy,
      }).returning();

      return transaction;
    });
  }

  async deductUserBalance(userId: number, amount: number, description: string, processedBy?: number, relatedOrderId?: number): Promise<BalanceTransaction | null> {
    // Validate amount
    if (amount <= 0) {
      throw new Error('Amount must be positive');
    }

    // Use database transaction for atomicity
    return await this.db.transaction(async (tx) => {
      // Get current user with lock
      const [user] = await tx.select().from(users).where(eq(users.id, userId)).for('update');
      if (!user) {
        throw new Error('User not found');
      }

      const balanceBefore = user.balance;
      const balanceAfter = balanceBefore - amount;

      // Check if user has sufficient balance
      if (balanceAfter < 0) {
        return null; // Insufficient balance
      }

      // Update user balance
      await tx.update(users).set({ balance: balanceAfter }).where(eq(users.id, userId));

      // Create transaction record
      const [transaction] = await tx.insert(balanceTransactions).values({
        userId,
        type: 'debit',
        amount: -amount, // Negative for debit
        balanceBefore,
        balanceAfter,
        description,
        relatedOrderId,
        processedBy,
      }).returning();

      return transaction;
    });
  }
}

export const storage = new PostgreSQLStorage();