import { storage } from '../storage';
import type { User, Product, Category, Order } from '@shared/schema';

export class DatabaseService {
  static async ensureUser(telegramUserId: number, username: string): Promise<User> {
    let user = await storage.getUser(telegramUserId);
    
    if (!user) {
      user = await storage.createUser({
        id: telegramUserId,
        username: username || `user_${telegramUserId}`,
        balance: 0,
        totalOrders: 0,
      });
    } else {
      // Update last active time
      await storage.updateUser(telegramUserId, { lastActive: new Date() });
    }
    
    return user;
  }

  static async getProductWithCategories(productId: number): Promise<{ product: Product; categories: Category[] } | null> {
    const product = await storage.getProduct(productId);
    if (!product) return null;
    
    const categories = await storage.getCategoriesByProduct(productId);
    return { product, categories };
  }

  static async createOrderWithNotification(orderData: {
    userId: number;
    productId: number;
    categoryId: number;
    inputData: string;
  }): Promise<Order> {
    const order = await storage.createOrder({
      ...orderData,
      status: 'pending',
    });
    
    return order;
  }

  static async completeOrder(orderId: number, adminNotes: string, codeIfAny?: string): Promise<Order | null> {
    const order = await storage.updateOrder(orderId, {
      status: 'completed',
      adminNotes,
      codeIfAny,
      completedAt: new Date(),
    });
    
    return order || null;
  }

  static async cancelOrder(orderId: number, reason: string): Promise<Order | null> {
    // الحصول على تفاصيل الطلب أولاً
    const orderDetails = await this.getOrderDetails(orderId);
    if (!orderDetails) {
      throw new Error('Order not found');
    }

    const { order, user, category } = orderDetails;
    
    // ✅ فحص أمني محسن: التأكد من أن الطلب لم يُلغ مسبقاً
    if (order.status !== 'pending') {
      throw new Error(`Cannot cancel order #${orderId} - already ${order.status}`);
    }
    
    // 🔒 إلغاء آمن بـ conditional update (يمنع race conditions)
    const cancelledOrder = await storage.updateOrder(orderId, {
      status: 'cancelled',
      adminNotes: reason,
    });
    
    if (!cancelledOrder) {
      throw new Error('Failed to cancel order - order may have been cancelled already');
    }

    // 💰 تحديد المبلغ المُرجع: استخدم السعر المدفوع إن وُجد، وإلا السعر الحالي
    const refundAmount = order.paidAmount || category.price;
    
    // إرجاع النجوم للمستخدم
    const currentUser = await storage.getUser(user.id);
    if (currentUser) {
      const newBalance = currentUser.balance + refundAmount;
      
      // تحديث رصيد المستخدم
      await storage.updateUser(user.id, { balance: newBalance });
      
      // إضافة معاملة للرصيد
      await storage.createBalanceTransaction({
        userId: user.id,
        type: 'credit',
        amount: refundAmount,
        balanceBefore: currentUser.balance,
        balanceAfter: newBalance,
        description: `إرجاع النجوم للطلب الملغي #${orderId} - ${reason}`,
        relatedOrderId: orderId,
      });
      
      console.log(`✅ Refunded ${refundAmount} stars to user ${user.id} for cancelled order #${orderId}`);
    }
    
    return cancelledOrder;
  }

  static async getUserOrders(userId: number): Promise<Order[]> {
    return await storage.getOrdersByUser(userId);
  }

  static async getPendingOrders(): Promise<Order[]> {
    return await storage.getOrdersByStatus('pending');
  }

  static async getOrderDetails(orderId: number): Promise<{
    order: Order;
    user: User;
    product: Product;
    category: Category;
  } | null> {
    const order = await storage.getOrder(orderId);
    if (!order) return null;
    
    const [user, product, category] = await Promise.all([
      storage.getUser(order.userId),
      storage.getProduct(order.productId),
      storage.getCategory(order.categoryId),
    ]);
    
    if (!user || !product || !category) return null;
    
    return { order, user, product, category };
  }
}
