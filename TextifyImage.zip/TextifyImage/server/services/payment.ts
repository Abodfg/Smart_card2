import { BOT_CONFIG } from '../config/bot-config';

export interface PaymentResult {
  success: boolean;
  transactionId?: string;
  error?: string;
}

export class PaymentService {
  static async createStarsInvoice(params: {
    chatId: number;
    title: string;
    description: string;
    amount: number;
    payload: string;
  }): Promise<{ invoiceUrl: string }> {
    // ✨ Enhanced Telegram Stars invoice creation with better error handling
    const invoiceData = {
      chat_id: params.chatId,
      title: params.title,
      description: params.description,
      payload: params.payload,
      provider_token: '', // Empty for Telegram Stars (CRITICAL)
      currency: 'XTR', // Telegram Stars currency code
      prices: [{ label: params.title, amount: params.amount }],
      // Enhanced parameters for better UX
      photo_url: '',
      photo_size: 0,
      photo_width: 0,
      photo_height: 0,
      need_name: false,
      need_phone_number: false,
      need_email: false,
      need_shipping_address: false,
      send_phone_number_to_provider: false,
      send_email_to_provider: false,
      is_flexible: false
    };

    try {
      console.log('🌟 Creating Telegram Stars invoice:', {
        chatId: params.chatId,
        amount: params.amount,
        title: params.title
      });
      
      const response = await fetch(`https://api.telegram.org/bot${BOT_CONFIG.USER_BOT_TOKEN}/sendInvoice`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(invoiceData),
      });

      const result = await response.json();
      
      if (result.ok) {
        console.log('✅ Stars invoice created successfully:', result.result.message_id);
        return { invoiceUrl: result.result.url || '' };
      } else {
        console.error('❌ Stars invoice creation failed:', {
          error_code: result.error_code,
          description: result.description,
          parameters: result.parameters
        });
        
        // Better error messages based on common issues
        let errorMessage = 'فشل في إنشاء فاتورة الدفع بالنجوم';
        if (result.description?.includes('Bad Request: CURRENCY_TOTAL_AMOUNT_INVALID')) {
          errorMessage = 'خطأ في مبلغ الدفع. تأكد من أن المبلغ صحيح.';
        } else if (result.description?.includes('chat not found')) {
          errorMessage = 'خطأ في معرف المحادثة.';
        } else if (result.description?.includes('Unauthorized')) {
          errorMessage = 'خطأ في توكن البوت. تواصل مع الدعم الفني.';
        }
        
        throw new Error(errorMessage);
      }
    } catch (error: any) {
      console.error('💥 Payment creation error:', error);
      if (error.message.startsWith('فشل') || error.message.startsWith('خطأ')) {
        throw error; // Re-throw our custom errors
      }
      throw new Error('فشل في إنشاء فاتورة الدفع بالنجوم. حاول مرة أخرى.');
    }
  }

  static async verifyPayment(preCheckoutQuery: any): Promise<PaymentResult> {
    try {
      console.log('🔍 Verifying payment:', {
        queryId: preCheckoutQuery.id,
        currency: preCheckoutQuery.currency,
        totalAmount: preCheckoutQuery.total_amount,
        userId: preCheckoutQuery.from.id
      });
      
      // Enhanced payment verification with validation
      const isValidPayment = this.validatePaymentQuery(preCheckoutQuery);
      
      if (!isValidPayment.valid) {
        console.warn('⚠️ Payment validation failed:', isValidPayment.reason);
        return {
          success: false,
          error: isValidPayment.reason || 'بيانات الدفع غير صحيحة'
        };
      }
      
      // Answer the pre-checkout query
      const response = await fetch(`https://api.telegram.org/bot${BOT_CONFIG.USER_BOT_TOKEN}/answerPreCheckoutQuery`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          pre_checkout_query_id: preCheckoutQuery.id,
          ok: true,
        }),
      });

      const result = await response.json();
      
      if (result.ok) {
        console.log('✅ Payment verification successful');
        return {
          success: true,
          transactionId: preCheckoutQuery.id,
        };
      } else {
        console.error('❌ Payment verification failed:', result);
        return {
          success: false,
          error: result.description || 'فشل في التحقق من الدفع',
        };
      }
    } catch (error) {
      console.error('💥 Payment verification error:', error);
      return {
        success: false,
        error: 'فشل في التحقق من الدفع',
      };
    }
  }
  
  // Helper method to validate payment query
  private static validatePaymentQuery(query: any): { valid: boolean; reason?: string } {
    // Check required fields
    if (!query.id) {
      return { valid: false, reason: 'معرف الاستعلام مفقود' };
    }
    
    if (!query.from?.id) {
      return { valid: false, reason: 'معرف المستخدم مفقود' };
    }
    
    if (query.currency !== 'XTR') {
      return { valid: false, reason: 'عملة الدفع غير صحيحة' };
    }
    
    if (!query.total_amount || query.total_amount <= 0) {
      return { valid: false, reason: 'مبلغ الدفع غير صحيح' };
    }
    
    try {
      // Validate payload JSON
      JSON.parse(query.invoice_payload);
    } catch {
      return { valid: false, reason: 'بيانات الطلب غير صحيحة' };
    }
    
    return { valid: true };
  }

  static async processSuccessfulPayment(paymentData: any): Promise<PaymentResult> {
    try {
      console.log('🎉 Processing successful payment:', {
        chargeId: paymentData.telegram_payment_charge_id,
        providerChargeId: paymentData.provider_payment_charge_id,
        currency: paymentData.currency,
        totalAmount: paymentData.total_amount,
        payload: paymentData.invoice_payload
      });
      
      // Validate payment data
      if (!paymentData.telegram_payment_charge_id) {
        throw new Error('معرف معاملة تليجرام مفقود');
      }
      
      if (paymentData.currency !== 'XTR') {
        throw new Error('عملة الدفع غير صحيحة');
      }
      
      // Validate payload
      let orderInfo;
      try {
        orderInfo = JSON.parse(paymentData.invoice_payload);
      } catch {
        throw new Error('بيانات الطلب في الفاتورة غير صحيحة');
      }
      
      if (!orderInfo.userId || !orderInfo.productId || !orderInfo.categoryId) {
        throw new Error('بيانات الطلب ناقصة');
      }
      
      console.log('✅ Payment processed successfully:', {
        transactionId: paymentData.telegram_payment_charge_id,
        orderInfo: orderInfo
      });
      
      return {
        success: true,
        transactionId: paymentData.telegram_payment_charge_id,
      };
    } catch (error: any) {
      console.error('💥 Payment processing error:', error);
      return {
        success: false,
        error: error.message || 'فشل في معالجة الدفع',
      };
    }
  }
}
