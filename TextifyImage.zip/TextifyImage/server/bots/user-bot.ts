import { Telegraf, Markup } from 'telegraf';
import { BOT_CONFIG } from '../config/bot-config';
import { DatabaseService } from '../services/database';
import { PaymentService } from '../services/payment';
import { NotificationService } from '../utils/notifications';
import { storage } from '../storage';

const bot = new Telegraf(BOT_CONFIG.USER_BOT_TOKEN);

// Safe edit message function to handle "message is not modified" error
async function safeEditMessage(ctx: any, text: string, extra?: any) {
  try {
    await ctx.editMessageText(text, extra);
  } catch (error: any) {
    // Silently ignore "message is not modified" error (400)
    if (error.code === 400 && error.description?.includes('message is not modified')) {
      // Message content is the same, no need to update
      return;
    }
    // Re-throw other errors
    throw error;
  }
}

// User session management
const userSessions = new Map<number, any>();

// Helper function to get or create user session
function getUserSession(userId: number) {
  if (!userSessions.has(userId)) {
    userSessions.set(userId, {
      currentStep: 'main',
      selectedProduct: null,
      selectedCategory: null,
      inputData: '',
    });
  }
  return userSessions.get(userId);
}

// Reply Keyboard button handlers
bot.hears('🛍️ المنتجات', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId) return;

  try {
    const categories = await storage.getAllProductCategories();
    
    if (categories.length === 0) {
      await ctx.reply('❌ لا توجد منتجات متاحة حالياً.');
      return;
    }
    
    const keyboard = categories.map(category => [
      Markup.button.callback(`${category.icon || '🎮'} ${category.name}`, `main_category_${category.id}`)
    ]);
    
    keyboard.push([Markup.button.callback('🔙 رجوع للقائمة الرئيسية', 'main_menu')]);
    
    await ctx.reply('🛍️ **المنتجات المتوفرة:**\n\nاختر الصنف المطلوب:', { parse_mode: 'Markdown', ...Markup.inlineKeyboard(keyboard) });
  } catch (error) {
    console.error('Error in products handler:', error);
    await ctx.reply('❌ حدث خطأ أثناء تحميل المنتجات. حاول مرة أخرى.');
  }
});

bot.hears('⏳ طلباتي', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId) return;

  try {
    const orders = await storage.getOrdersByUser(userId);
    
    let message = '⏳ **طلباتي:**\n\n';
    
    if (orders.length === 0) {
      message += '📦 لا توجد لديك طلبات سابقة.';
    } else {
      for (const order of orders.slice(0, 10)) {
        const product = await storage.getProduct(order.productId);
        const category = await storage.getCategory(order.categoryId);
        
        const statusEmoji = order.status === 'pending' ? '⏳' : 
                           order.status === 'completed' ? '✅' : '❌';
        const statusText = order.status === 'pending' ? 'قيد التنفيذ' : 
                          order.status === 'completed' ? 'مكتمل' : 'ملغي';
        
        message += `🆔 طلب #${order.id}\n`;
        message += `📱 ${product?.name || 'غير معروف'}\n`;
        message += `💰 ${category?.price || 0} ⭐\n`;
        message += `${statusEmoji} ${statusText}\n`;
        message += `📅 ${new Date(order.createdAt).toLocaleDateString('ar-SA')}\n`;
        
        // إضافة الملاحظات إذا كانت موجودة
        if (order.adminNotes) {
          message += `📝 ملاحظات: ${order.adminNotes}\n`;
        }
        
        // إضافة الكود إذا كان موجوداً
        if (order.codeIfAny) {
          message += `🎁 الكود: ${order.codeIfAny}\n`;
        }
        
        message += `\n`;
      }
      
      if (orders.length > 10) {
        message += `... و ${orders.length - 10} طلبات أخرى`;
      }
    }
    
    await ctx.reply(message, { parse_mode: 'Markdown' });
  } catch (error) {
    console.error('Error in orders handler:', error);
    await ctx.reply('❌ حدث خطأ أثناء تحميل الطلبات.');
  }
});

bot.hears('💰 رصيدي', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId) return;

  try {
    const user = await storage.getUser(userId);
    if (!user) {
      await ctx.reply('❌ لم يتم العثور على حساب المستخدم.');
      return;
    }

    const balance = user.balance || 0;
    
    let message = `💰 **رصيدي الحالي:**\n\n`;
    message += `💳 ${balance} ج.م\n\n`;
    
    if (balance < 50) {
      message += `⚠️ رصيدك منخفض! \n📲 يمكنك طلب شحن الرصيد الآن.`;
    }
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('💳 طلب شحن رصيد', 'request_topup')],
      [Markup.button.callback('📄 طلبات الشحن', 'my_topup_requests')]
    ]);
    
    await ctx.reply(message, { parse_mode: 'Markdown', ...keyboard });
  } catch (error) {
    console.error('Error in balance handler:', error);
    await ctx.reply('❌ حدث خطأ أثناء تحميل الرصيد.');
  }
});

bot.hears('🎧 الدعم الفني', (ctx) => {
  let message = '🎧 **الدعم الفني:**\n\n';
  message += '📞 للحصول على المساعدة أو الإبلاغ عن مشكلة:\n\n';
  message += '💬 تيليجرام: @YourSupportBot\n';
  message += '📧 إيميل: support@yourstore.com\n';
  message += '⏰ ساعات العمل: من 9 صباحاً إلى 11 مساءً\n\n';
  message += '⚡ نحن هنا لمساعدتك!';
  
  ctx.reply(message, { parse_mode: 'Markdown' });
});

bot.hears('👨‍💻 عن المطور', (ctx) => {
  let message = '👨‍💻 **عن المطور:**\n\n';
  message += '🔧 مطور البوت: فريق التطوير\n';
  message += '🌐 الموقع: www.yourstore.com\n';
  message += '💬 تيليجرام: @YourDeveloper\n';
  message += '📧 للتواصل: dev@yourstore.com\n\n';
  message += '💡 شكراً لاستخدام خدماتنا!';
  
  ctx.reply(message, { parse_mode: 'Markdown' });
});

// Start command
bot.start(async (ctx) => {
  const userId = ctx.from?.id;
  const username = ctx.from?.username || ctx.from?.first_name || '';
  
  if (!userId) return;

  await DatabaseService.ensureUser(userId, username);
  
  // Reply Keyboard (always visible)
  const replyKeyboard = Markup.keyboard([
    ['🛍️ المنتجات', '⏳ طلباتي'],
    ['💰 رصيدي', '🎧 الدعم الفني'],
    ['👨‍💻 عن المطور']
  ]).resize();

  await ctx.reply(
    `أهلاً وسهلاً بك في متجرنا للشحن الرقمي! 🎮\n\n` +
    `🛍️ تسوق من مجموعة كبيرة من المنتجات الرقمية\n` +
    `💰 ادفع من رصيدك أو بـ Telegram Stars\n` +
    `⚡ استلم طلبك فوراً\n\n` +
    `استخدم الأزرار أدناه أو الأوامر المباشرة:\n` +
    `/products - المنتجات\n` +
    `/orders - طلباتي\n` +
    `/balance - رصيدي\n` +
    `/support - الدعم الفني\n` +
    `/developer - عن المطور`,
    replyKeyboard
  );
});

// Command: /products
bot.command('products', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId) return;

  try {
    const categories = await storage.getAllProductCategories();
    
    if (categories.length === 0) {
      await ctx.reply('❌ لا توجد منتجات متاحة حالياً.');
      return;
    }
    
    const keyboard = categories.map(category => [
      Markup.button.callback(`${category.icon || '🎮'} ${category.name}`, `main_category_${category.id}`)
    ]);
    
    keyboard.push([Markup.button.callback('🔙 رجوع للقائمة الرئيسية', 'main_menu')]);
    
    await ctx.reply('🛍️ **المنتجات المتوفرة:**\n\nاختر الصنف المطلوب:', { parse_mode: 'Markdown', ...Markup.inlineKeyboard(keyboard) });
  } catch (error) {
    console.error('Error in products command:', error);
    await ctx.reply('❌ حدث خطأ أثناء تحميل المنتجات. حاول مرة أخرى.');
  }
});

// Command: /orders
bot.command('orders', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId) return;

  try {
    const orders = await storage.getOrdersByUser(userId);
    
    let message = '⏳ **طلباتي:**\n\n';
    
    if (orders.length === 0) {
      message += '📦 لا توجد لديك طلبات سابقة.';
    } else {
      for (const order of orders.slice(0, 10)) {
        const product = await storage.getProduct(order.productId);
        const category = await storage.getCategory(order.categoryId);
        
        const statusEmoji = order.status === 'pending' ? '⏳' : 
                           order.status === 'completed' ? '✅' : '❌';
        const statusText = order.status === 'pending' ? 'قيد التنفيذ' : 
                          order.status === 'completed' ? 'مكتمل' : 'ملغي';
        
        message += `🆔 طلب #${order.id}\n`;
        message += `📱 ${product?.name || 'غير معروف'}\n`;
        message += `💰 ${category?.price || 0} ⭐\n`;
        message += `${statusEmoji} ${statusText}\n`;
        message += `📅 ${new Date(order.createdAt).toLocaleDateString('ar-SA')}\n`;
        
        // إضافة الملاحظات إذا كانت موجودة
        if (order.adminNotes) {
          message += `📝 ملاحظات: ${order.adminNotes}\n`;
        }
        
        // إضافة الكود إذا كان موجوداً
        if (order.codeIfAny) {
          message += `🎁 الكود: ${order.codeIfAny}\n`;
        }
        
        message += `\n`;
      }
      
      if (orders.length > 10) {
        message += `... و ${orders.length - 10} طلبات أخرى`;
      }
    }
    
    await ctx.reply(message, { parse_mode: 'Markdown' });
  } catch (error) {
    console.error('Error in orders command:', error);
    await ctx.reply('❌ حدث خطأ أثناء تحميل الطلبات.');
  }
});

// Command: /support
bot.command('support', (ctx) => {
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('🔙 رجوع للقائمة الرئيسية', 'main_menu')]
  ]);
  
  let message = '🎧 **الدعم الفني:**\n\n';
  message += '📞 للحصول على المساعدة أو الإبلاغ عن مشكلة:\n\n';
  message += '💬 تيليجرام: @YourSupportBot\n';
  message += '📧 إيميل: support@yourstore.com\n';
  message += '⏰ ساعات العمل: من 9 صباحاً إلى 11 مساءً\n\n';
  message += '⚡ نحن هنا لمساعدتك!';
  
  ctx.reply(message, { parse_mode: 'Markdown', ...keyboard });
});

// Command: /developer
bot.command('developer', (ctx) => {
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('🔙 رجوع للقائمة الرئيسية', 'main_menu')]
  ]);
  
  let message = '👨‍💻 **عن المطور:**\n\n';
  message += '🔧 مطور البوت: فريق التطوير\n';
  message += '🌐 الموقع: www.yourstore.com\n';
  message += '💬 تيليجرام: @YourDeveloper\n';
  message += '📧 للتواصل: dev@yourstore.com\n\n';
  message += '💡 شكراً لاستخدام خدماتنا!';
  
  ctx.reply(message, { parse_mode: 'Markdown', ...keyboard });
});

// Command: /balance
bot.command('balance', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId) return;

  try {
    const user = await storage.getUser(userId);
    if (!user) {
      await ctx.reply('❌ لم يتم العثور على حساب المستخدم.');
      return;
    }

    const balance = user.balance || 0;
    
    let message = `💰 **رصيدي الحالي:**\n\n`;
    message += `💳 ${balance} ج.م\n\n`;
    
    if (balance < 50) {
      message += `⚠️ رصيدك منخفض! \n📲 يمكنك طلب شحن الرصيد الآن.`;
    }
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('💳 طلب شحن رصيد', 'request_topup')],
      [Markup.button.callback('📄 طلبات الشحن', 'my_topup_requests')]
    ]);
    
    await ctx.reply(message, { parse_mode: 'Markdown', ...keyboard });
  } catch (error) {
    console.error('Error in balance command:', error);
    await ctx.reply('❌ حدث خطأ أثناء تحميل الرصيد.');
  }
});

// Add missing request_topup handler (duplicate of add_balance for compatibility)
bot.action('request_topup', async (ctx) => {
  await ctx.answerCbQuery('💳 شحن الرصيد');
  
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('💰 50 ج.م', 'request_charge_50')],
    [Markup.button.callback('💰 100 ج.م', 'request_charge_100')],
    [Markup.button.callback('💰 200 ج.م', 'request_charge_200')],
    [Markup.button.callback('💰 500 ج.م', 'request_charge_500')],
    [Markup.button.callback('💰 مبلغ مخصص', 'custom_charge_amount')],
    [Markup.button.callback('📄 طلباتي السابقة', 'my_topup_requests')],
    [Markup.button.callback('🔙 رجوع', 'balance')]
  ]);
  
  const message = '💳 **طلب شحن الرصيد**\n\n' +
    '🔹 اختر المبلغ المطلوب شحنه\n' +
    '🔹 سيتم إرسال طلبك للإدارة\n' +
    '🔹 ستتلقى إشعار عند الموافقة\n\n' +
    '💡 **طرق الدفع المتاحة:**\n' +
    '• فودافون كاش\n' +
    '• انستاباي\n' +
    '• البنوك الإلكترونية';
  
  await safeEditMessage(ctx, message, keyboard);
});

// Products menu - showing main categories
bot.action('products', async (ctx) => {
  console.log('🛍️ USER PRODUCTS CALLBACK TRIGGERED');
  try {
    const categories = await storage.getAllProductCategories();
    
    if (categories.length === 0) {
      await ctx.answerCbQuery('❌ لا توجد أصناف متاحة حالياً.');
      return;
    }
    
    const keyboard = categories.map(category => [
      Markup.button.callback(`${category.icon || '🎮'} ${category.name}`, `main_category_${category.id}`)
    ]);
    
    keyboard.push([Markup.button.callback('🔙 رجوع للقائمة الرئيسية', 'back_to_main')]);
    
    await ctx.answerCbQuery('عرض الأصناف الرئيسية');
    await safeEditMessage(ctx, '🛍️ اختر الصنف المطلوب:', Markup.inlineKeyboard(keyboard));
  } catch (error) {
    console.error('Error in products action:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء تحميل الأصناف.');
  }
});

// Main category selection - showing products within category
bot.action(/main_category_(\d+)/, async (ctx) => {
  console.log('🏷️ USER MAIN CATEGORY CALLBACK TRIGGERED:', ctx.match![1]);
  const categoryId = parseInt(ctx.match![1]);
  
  try {
    const category = await storage.getProductCategory(categoryId);
    if (!category) {
      await ctx.answerCbQuery('❌ الصنف غير موجود');
      return;
    }

    const products = await storage.getProductsByCategory(categoryId);
    
    if (products.length === 0) {
      await ctx.answerCbQuery('❌ لا توجد منتجات في هذا الصنف حالياً.');
      return;
    }
    
    const keyboard = products.map(product => [
      Markup.button.callback(`${product.name}`, `product_${product.id}`)
    ]);
    
    keyboard.push([Markup.button.callback('🔙 رجوع للأصناف', 'products')]);
    
    await ctx.answerCbQuery(`فتح صنف ${category.name}`);
    await safeEditMessage(ctx, 
      `${category.icon || '🎮'} **${category.name}**\n\n${category.description}\n\n🛍️ اختر المنتج:`,
      Markup.inlineKeyboard(keyboard)
    );
  } catch (error) {
    console.error('Error in main_category action:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء تحميل المنتجات.');
  }
});

// Product selection
bot.action(/product_(\d+)/, async (ctx) => {
  const productId = parseInt(ctx.match[1]);
  const userId = ctx.from?.id;
  
  if (!userId) return;
  
  const session = getUserSession(userId);
  session.selectedProduct = productId;
  
  const productData = await DatabaseService.getProductWithCategories(productId);
  
  if (!productData) {
    await ctx.answerCbQuery('المنتج غير موجود');
    return;
  }
  
  const { product, categories } = productData;
  
  const keyboard = categories.map(category => [
    Markup.button.callback(`${category.name} - ⭐ ${category.price}`, `category_${category.id}`)
  ]);
  
  keyboard.push([Markup.button.callback('← رجوع للمنتجات', 'products')]);
  
  await safeEditMessage(ctx, 
    `📱 ${product.name}\n\n${product.description}\n\nاختر الفئة:`,
    Markup.inlineKeyboard(keyboard)
  );
});

// Category selection
bot.action(/category_(\d+)/, async (ctx) => {
  const categoryId = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  
  if (!userId) {
    await ctx.answerCbQuery('❌ لم يتم التعرف على المستخدم');
    return;
  }
  
  const session = getUserSession(userId);
  
  // Make sure we have a selected product
  if (!session.selectedProduct) {
    await ctx.answerCbQuery('❌ يجب اختيار منتج أولاً');
    return;
  }
  
  session.selectedCategory = categoryId;
  session.currentStep = 'waiting_input';
  
  try {
    const category = await storage.getCategory(categoryId);
    const product = await storage.getProduct(session.selectedProduct);
  
    if (!category || !product) {
      await ctx.answerCbQuery('❌ بيانات المنتج أو الفئة غير موجودة');
      return;
    }

    await ctx.answerCbQuery('جاري عرض نموذج البيانات...');
  
  let inputPrompt = '';
  switch (product.shippingType) {
    case 'id':
      inputPrompt = 'أدخل ID اللعبة:';
      break;
    case 'phone':
      inputPrompt = 'أدخل رقم الهاتف:';
      break;
    case 'email':
      inputPrompt = 'أدخل البريد الإلكتروني:';
      break;
    case 'code':
      inputPrompt = 'أدخل الكود:';
      break;
    default:
      inputPrompt = 'أدخل البيانات المطلوبة:';
  }
  
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('❌ إلغاء', 'cancel_order')]
  ]);
  
    await safeEditMessage(ctx, 
      `📦 ${product.name} - ${category.name}\n💰 السعر: ⭐ ${category.price}\n\n${inputPrompt}`,
      { parse_mode: 'Markdown', ...keyboard }
    );
  } catch (error) {
    console.error('Error in category selection:', error);
    await ctx.answerCbQuery('❌ حدث خطأ في عرض تفاصيل الفئة');
  }
});

// Handle text input for order data
bot.on('text', async (ctx) => {
  const userId = ctx.from?.id;
  
  if (!userId) return;
  
  const session = getUserSession(userId);
  
  if (session.currentStep === 'waiting_input') {
    session.inputData = ctx.message.text;
    
    const category = await storage.getCategory(session.selectedCategory);
    const product = await storage.getProduct(session.selectedProduct);
    
    if (!category || !product) {
      await ctx.reply('خطأ في البيانات، يرجى المحاولة مرة أخرى');
      return;
    }
    
    // Check wallet balance first, then create appropriate payment method
    try {
      const user = await storage.getUser(userId);
      if (!user) {
        await ctx.reply('❌ خطأ في بيانات المستخدم. حاول مرة أخرى.');
        return;
      }

      const productPrice = category.price;
      const currentBalance = user.balance || 0;

      // If user has sufficient balance, pay from wallet directly
      if (currentBalance >= productPrice) {
        const confirmMessage = `💰 **طريقة الدفع المتاحة:**\n\n` +
          `🛍️ المنتج: ${product.name} - ${category.name}\n` +
          `💸 السعر: ${productPrice} ج.م\n` +
          `💳 رصيدك: ${currentBalance} ج.م\n\n` +
          `✅ يمكن الدفع من محفظتك مباشرة\n` +
          `🔄 الرصيد بعد الدفع: ${currentBalance - productPrice} ج.م`;

        const keyboard = Markup.inlineKeyboard([
          [Markup.button.callback('💰 ادفع من المحفظة', 'pay_from_wallet')],
          [Markup.button.callback('⭐ ادفع بـ Telegram Stars', 'pay_with_stars')],
          [Markup.button.callback('❌ إلغاء', 'cancel_order')]
        ]);

        await ctx.reply(confirmMessage, keyboard);
        session.currentStep = 'choosing_payment_method';

      } else if (currentBalance > 0) {
        // Partial wallet balance + stars payment
        const remainingAmount = productPrice - currentBalance;
        
        const partialMessage = `💰 **طرق الدفع المتاحة:**\n\n` +
          `🛍️ المنتج: ${product.name} - ${category.name}\n` +
          `💸 السعر الإجمالي: ${productPrice} ج.م\n` +
          `💳 رصيدك: ${currentBalance} ج.م\n` +
          `💫 المطلوب إضافياً: ${remainingAmount} ج.م\n\n` +
          `**اختر طريقة الدفع:**`;

        const keyboard = Markup.inlineKeyboard([
          [Markup.button.callback(`💰+⭐ محفظة (${currentBalance}) + نجوم (${remainingAmount})`, 'pay_mixed')],
          [Markup.button.callback(`⭐ دفع كامل بالنجوم (${productPrice})`, 'pay_with_stars')],
          [Markup.button.callback('❌ إلغاء', 'cancel_order')]
        ]);

        await ctx.reply(partialMessage, keyboard);
        session.currentStep = 'choosing_payment_method';

      } else {
        // No wallet balance, only stars payment
        const starsOnlyMessage = `⭐ **الدفع بـ Telegram Stars:**\n\n` +
          `🛍️ المنتج: ${product.name} - ${category.name}\n` +
          `💸 السعر: ${productPrice} نجمة\n` +
          `💳 رصيد محفظتك: 0 ج.م\n\n` +
          `🌟 سيتم الدفع باستخدام نجوم Telegram`;

        await createStarsInvoice(ctx, session, product, category, productPrice);
      }
      
    } catch (error) {
      console.error('Payment creation error:', error);
      await ctx.reply('حدث خطأ في إنشاء فاتورة الدفع، يرجى المحاولة مرة أخرى');
    }
  }
});

// Helper function to create Telegram Stars invoice
async function createStarsInvoice(ctx: any, session: any, product: any, category: any, amount: number) {
  const orderPayload = JSON.stringify({
    userId: ctx.from?.id,
    productId: session.selectedProduct,
    categoryId: session.selectedCategory,
    inputData: session.inputData,
    expectedAmount: amount, // 💰 Save expected amount for verification during payment
    timestamp: Date.now(), // 🕐 Add timestamp for additional validation
  });
  
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.pay(`دفع ⭐ ${amount}`)],
    [Markup.button.callback('❌ إلغاء', 'cancel_order')]
  ]);
  
  try {
    await ctx.replyWithInvoice({
      title: `${product.name} - ${category.name}`,
      description: `شحن ${category.name} لـ ${product.name}`,
      payload: orderPayload,
      provider_token: '', // Empty for Telegram Stars payment
      currency: 'XTR',
      prices: [{ label: category.name, amount: amount }],
    }, keyboard);
    
    console.log(`Stars invoice created for user ${ctx.from?.id}: ${amount} stars for ${product.name} - ${category.name}`);
  } catch (error) {
    console.error('Stars invoice creation error:', error);
    await ctx.reply('❌ حدث خطأ في إنشاء فاتورة الدفع بالنجوم. يرجى المحاولة مرة أخرى.');
    return;
  }
  
  session.currentStep = 'waiting_payment';
}

// Payment method handlers
bot.action('pay_from_wallet', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId) return;
  
  const session = getUserSession(userId);
  
  // Prevent double processing
  if (session.paymentInProgress) {
    await ctx.answerCbQuery('⚡ يتم معالجة الدفع بالفعل...');
    return;
  }
  
  try {
    session.paymentInProgress = true;
    await ctx.answerCbQuery('جاري معالجة الدفع من المحفظة...');
    const user = await storage.getUser(userId);
    const category = await storage.getCategory(session.selectedCategory);
    const product = await storage.getProduct(session.selectedProduct);
    
    if (!user || !category || !product) {
      await safeEditMessage(ctx, '❌ خطأ في البيانات. حاول مرة أخرى.');
      return;
    }
    
    const productPrice = category.price;
    
    if (user.balance < productPrice) {
      await safeEditMessage(ctx, '❌ رصيد المحفظة غير كافي.');
      return;
    }
    
    // Deduct from wallet balance
    const newBalance = user.balance - productPrice;
    await storage.updateUser(userId, { balance: newBalance });
    
    // Create order directly (wallet payment)
    const orderData = {
      userId,
      productId: session.selectedProduct,
      categoryId: session.selectedCategory,
      inputData: session.inputData,
    };
    
    const order = await DatabaseService.createOrderWithNotification(orderData);
    
    // Record wallet transaction
    await storage.createBalanceTransaction({
      userId: userId,
      amount: -productPrice,
      type: 'purchase',
      description: `شراء ${product.name} - ${category.name}`,
      balanceBefore: user.balance,
      balanceAfter: newBalance,
      relatedOrderId: order.id
    });
    
    // Success message
    const successMessage = `✅ **تم الدفع بنجاح من المحفظة!**\n\n` +
      `🛍️ المنتج: ${product.name} - ${category.name}\n` +
      `💰 المبلغ المدفوع: ${productPrice} ج.م\n` +
      `💳 رصيدك الجديد: ${newBalance} ج.م\n` +
      `🆔 رقم الطلب: #${order.id}\n\n` +
      `⏳ سيتم معالجة طلبك وإرسال التفاصيل قريباً`;
    
    await safeEditMessage(ctx, successMessage, Markup.inlineKeyboard([
      [Markup.button.callback('📦 طلباتي', 'my_orders')],
      [Markup.button.callback('💰 رصيدي', 'balance')],
      [Markup.button.callback('🏠 القائمة الرئيسية', 'main_menu')]
    ]));
    
    // Send notification to admins about new order
    try {
      const user = await storage.getUser(userId);
      await NotificationService.notifyNewOrder(order, user!, product, category);
      console.log('✅ Admin notification sent for order:', order.id);
    } catch (error) {
      console.error('❌ Failed to send admin notification:', error);
    }
    
    // Reset session
    session.currentStep = 'main';
    session.selectedProduct = null;
    session.selectedCategory = null;
    session.inputData = '';
    session.paymentInProgress = false;
    
  } catch (error) {
    console.error('Wallet payment error:', error);
    session.paymentInProgress = false;
    await ctx.answerCbQuery('❌ حدث خطأ أثناء معالجة الدفع');
  }
});

bot.action('pay_with_stars', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId) return;
  
  try {
    await ctx.answerCbQuery();
    const session = getUserSession(userId);
    const category = await storage.getCategory(session.selectedCategory);
    const product = await storage.getProduct(session.selectedProduct);
    
    if (!category || !product) {
      await safeEditMessage(ctx, '❌ خطأ في البيانات.');
      return;
    }
    
    await createStarsInvoice(ctx, session, product, category, category.price);
    
  } catch (error) {
    console.error('Stars payment error:', error);
    await ctx.answerCbQuery('❌ حدث خطأ');
  }
});

bot.action('pay_mixed', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId) return;
  
  try {
    await ctx.answerCbQuery('جاري معالجة الدفع المختلط...');
    
    const session = getUserSession(userId);
    const user = await storage.getUser(userId);
    const category = await storage.getCategory(session.selectedCategory);
    const product = await storage.getProduct(session.selectedProduct);
    
    if (!user || !category || !product) {
      await safeEditMessage(ctx, '❌ خطأ في البيانات.');
      return;
    }
    
    const productPrice = category.price;
    const walletBalance = user.balance || 0;
    const starsAmount = productPrice - walletBalance;
    
    if (starsAmount <= 0) {
      await safeEditMessage(ctx, '❌ يمكنك الدفع من المحفظة بالكامل.');
      return;
    }
    
    // Store mixed payment data in session
    session.mixedPayment = {
      walletAmount: walletBalance,
      starsAmount: starsAmount,
      totalAmount: productPrice
    };
    
    await createStarsInvoice(ctx, session, product, category, starsAmount);
    
  } catch (error) {
    console.error('Mixed payment error:', error);
    await ctx.answerCbQuery('❌ حدث خطأ');
  }
});

// Handle pre-checkout query
bot.on('pre_checkout_query', async (ctx) => {
  const result = await PaymentService.verifyPayment(ctx.preCheckoutQuery);
  
  if (result.success) {
    await ctx.answerPreCheckoutQuery(true);
  } else {
    await ctx.answerPreCheckoutQuery(false, result.error || 'فشل في التحقق من الدفع');
  }
});

// Handle successful payment
bot.on('successful_payment', async (ctx) => {
  const payingUserId = ctx.from?.id; // الشخص الذي قام بالدفع
  
  if (!payingUserId) return;
  
  try {
    const payment = ctx.message.successful_payment;
    console.log('🎉 Successful payment received:', {
      payingUserId: payingUserId,
      payment: payment
    });
    
    const orderData = JSON.parse(payment.invoice_payload);
    console.log('📦 Parsed order data:', orderData);
    
    // 🔒 CRITICAL SECURITY CHECK: Verify the payer matches the order owner
    if (payingUserId !== orderData.userId) {
      console.error('🚨 SECURITY ALERT: Payment from different user!', {
        payingUserId: payingUserId,
        orderOwnerUserId: orderData.userId,
        paymentChargeId: payment.telegram_payment_charge_id,
        categoryId: orderData.categoryId,
        timestamp: new Date().toISOString()
      });
      
      // Log suspicious activity for monitoring
      await NotificationService.sendToAdmins(
        `🚨 <b>محاولة دفع مشبوهة!</b>\n` +
        `المدفوع من: ${payingUserId}\n` +
        `صاحب الطلب: ${orderData.userId}\n` +
        `معرف المعاملة: ${payment.telegram_payment_charge_id}\n` +
        `الوقت: ${new Date().toLocaleString('ar-SA')}`
      );
      
      throw new Error('❌ خطأ أمني: لا يمكنك الدفع مقابل طلب مستخدم آخر!');
    }
    
    console.log('✅ Security check passed: Payment authorized for correct user');
    
    // Verify payment amount and currency
    const category = await storage.getCategory(orderData.categoryId);
    if (!category) {
      console.error('❌ Category not found for payment verification:', orderData.categoryId);
      throw new Error('الفئة غير موجودة');
    }
    
    // Enhanced amount verification - check both current price AND saved expected amount
    const currentPrice = category.price;
    const savedExpectedAmount = orderData.expectedAmount || currentPrice; // Use saved amount if available
    const receivedAmount = payment.total_amount;
    const currency = payment.currency;
    
    // Log price comparison for debugging
    console.log('💰 Amount verification:', {
      currentPrice: currentPrice,
      savedExpectedAmount: savedExpectedAmount,
      receivedAmount: receivedAmount,
      categoryId: orderData.categoryId,
      categoryName: category.name
    });
    
    // Verify currency is Telegram Stars (XTR)
    if (currency !== 'XTR') {
      console.error('❌ Invalid payment currency:', {
        expected: 'XTR',
        received: currency,
        orderId: orderData.categoryId
      });
      throw new Error(`عملة الدفع غير صحيحة. متوقع: XTR، مستلم: ${currency}`);
    }
    
    // Verify payment amount matches the saved expected price
    if (receivedAmount !== savedExpectedAmount) {
      console.error('❌ Payment amount mismatch:', {
        savedExpected: savedExpectedAmount,
        currentPrice: currentPrice,
        received: receivedAmount,
        categoryId: orderData.categoryId,
        categoryName: category.name
      });
      
      // Log if price changed between invoice creation and payment
      if (currentPrice !== savedExpectedAmount) {
        console.warn('⚠️ Price changed between invoice creation and payment:', {
          originalPrice: savedExpectedAmount,
          currentPrice: currentPrice,
          priceDifference: currentPrice - savedExpectedAmount
        });
      }
      
      throw new Error(`مبلغ الدفع غير صحيح. متوقع: ${savedExpectedAmount} نجمة، مستلم: ${receivedAmount} نجمة`);
    }
    
    console.log('✅ Payment verified successfully:', {
      amount: receivedAmount,
      currency: currency,
      categoryName: category.name
    });
    
    // Use the verified userId (same as payingUserId after security check)
    const userId = payingUserId;
    const session = getUserSession(userId);
    
    // Handle mixed payment if applicable
    if (session.mixedPayment) {
      const user = await storage.getUser(userId);
      if (user) {
        // Deduct wallet balance for mixed payment
        const newBalance = user.balance - session.mixedPayment.walletAmount;
        await storage.updateUser(userId, { balance: newBalance });
        
        // Record wallet transaction
        await storage.createBalanceTransaction({
          userId: userId,
          amount: -session.mixedPayment.walletAmount,
          type: 'purchase',
          description: `دفع مختلط - جزء محفظة`,
          balanceBefore: user.balance,
          balanceAfter: newBalance,
          relatedOrderId: null // Will be updated when order is created
        });
      }
    }
    
    // Validate order data before creating order
    if (!orderData.userId || !orderData.productId || !orderData.categoryId) {
      console.error('❌ Missing required order data:', orderData);
      throw new Error('بيانات الطلب ناقصة');
    }
    
    // Ensure inputData exists
    if (!orderData.inputData) {
      orderData.inputData = 'لا توجد بيانات إضافية';
    }
    
    console.log('✅ Creating order with data:', orderData);
    
    // Create order in database with paidAmount
    const order = await storage.createOrder({
      ...orderData,
      status: 'pending',
      paidAmount: receivedAmount,
    });
    console.log('✅ Order created successfully:', order.id);
    
    // Update wallet transaction with order ID if mixed payment
    if (session.mixedPayment) {
      // This would need a function to update transaction with orderId
      // For now, we'll log it
      console.log(`Mixed payment completed for order ${order.id}`);
    }
    
    // Get order details for notification
    const orderDetails = await DatabaseService.getOrderDetails(order.id);
    
    if (orderDetails) {
      // Customize success message based on payment method
      let successMessage;
      if (session.mixedPayment) {
        const user = await storage.getUser(userId);
        successMessage = `✅ **تم الدفع بنجاح!**\n\n` +
          `🛍️ المنتج: ${orderDetails.product.name} - ${orderDetails.category.name}\n` +
          `💰 دُفع من المحفظة: ${session.mixedPayment.walletAmount} ج.م\n` +
          `⭐ دُفع بالنجوم: ${session.mixedPayment.starsAmount} نجمة\n` +
          `💳 رصيدك الجديد: ${user?.balance || 0} ج.م\n` +
          `🆔 رقم الطلب: #${order.id}\n\n` +
          `⏳ سيتم معالجة طلبك وإرسال التفاصيل قريباً`;
      } else {
        successMessage = BOT_CONFIG.MESSAGES.ORDER_SUCCESS.replace('{orderId}', order.id.toString());
      }
      
      await ctx.reply(successMessage, Markup.inlineKeyboard([
        [Markup.button.callback('📦 طلباتي', 'my_orders')],
        [Markup.button.callback('💰 رصيدي', 'balance')],
        [Markup.button.callback('🏠 القائمة الرئيسية', 'main_menu')]
      ]));
      
      // Notify admins
      await NotificationService.notifyNewOrder(
        orderDetails.order,
        orderDetails.user,
        orderDetails.product,
        orderDetails.category
      );
    }
    
    // Reset user session
    session.currentStep = 'main';
    session.selectedProduct = null;
    session.selectedCategory = null;
    session.inputData = '';
    session.mixedPayment = null; // Clear mixed payment data
    
  } catch (error) {
    console.error('💥 Order creation error:', error);
    
    // Send more specific error message
    let errorMessage = 'حدث خطأ في إنشاء الطلب، يرجى التواصل مع الدعم الفني';
    if (error instanceof Error) {
      console.error('Error details:', error.message);
      if (error.message.includes('بيانات الطلب ناقصة')) {
        errorMessage = '❌ بيانات الطلب غير كاملة. يرجى المحاولة مرة أخرى.';
      } else if (error.message.includes('عملة الدفع غير صحيحة')) {
        errorMessage = '❌ عملة الدفع غير صحيحة. يجب استخدام نجوم التليجرام فقط.';
      } else if (error.message.includes('مبلغ الدفع غير صحيح')) {
        errorMessage = '❌ مبلغ الدفع غير مطابق للسعر المطلوب. يرجى المحاولة مرة أخرى.';
      } else if (error.message.includes('الفئة غير موجودة')) {
        errorMessage = '❌ الفئة المطلوبة غير متوفرة. يرجى اختيار فئة أخرى.';
      }
    }
    
    await ctx.reply(errorMessage);
  }
});

// My orders
bot.action('my_orders', async (ctx) => {
  const userId = ctx.from?.id;
  
  if (!userId) return;
  
  const orders = await DatabaseService.getUserOrders(userId);
  
  if (orders.length === 0) {
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('← رجوع', 'back_to_main')]
    ]);
    await safeEditMessage(ctx, '📦 لا توجد طلبات حالياً', keyboard);
    return;
  }
  
  let message = '📦 طلباتي:\n\n';
  
  for (const order of orders.slice(0, 10)) { // Show last 10 orders
    const product = await storage.getProduct(order.productId);
    const category = await storage.getCategory(order.categoryId);
    
    let statusEmoji = '';
    switch (order.status) {
      case 'pending':
        statusEmoji = '⏳';
        break;
      case 'completed':
        statusEmoji = '✅';
        break;
      case 'cancelled':
        statusEmoji = '❌';
        break;
    }
    
    message += `${statusEmoji} طلب #${order.id}\n`;
    message += `📱 ${product?.name} - ${category?.name}\n`;
    const orderDate = order.createdAt instanceof Date ? order.createdAt : new Date(order.createdAt);
    message += `📅 ${orderDate.toLocaleDateString('ar-EG')}\n`;
    
    if (order.status === 'completed' && order.codeIfAny) {
      message += `🎁 الكود: ${order.codeIfAny}\n`;
    }
    
    message += '\n';
  }
  
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('← رجوع', 'back_to_main')]
  ]);
  
  await safeEditMessage(ctx, message, keyboard);
});

// Balance - Enhanced with better UX
bot.action('balance', async (ctx) => {
  console.log('💰 USER BALANCE CALLBACK TRIGGERED');
  const userId = ctx.from?.id;
  
  if (!userId) return;
  
  try {
    const user = await storage.getUser(userId);
    
    if (!user) {
      await ctx.answerCbQuery('❌ خطأ في البيانات');
      return;
    }
    
    // Enhanced balance display
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('💳 شحن الرصيد', 'add_balance')],
      [Markup.button.callback('📊 سجل المعاملات', 'balance_history')],
      [Markup.button.callback('🔙 رجوع للقائمة الرئيسية', 'back_to_main')]
    ]);
    
    const lastActiveDate = user.lastActive instanceof Date ? user.lastActive : new Date(user.lastActive);
    const message = `💰 **محفظتك الشخصية**\n\n` +
      `💎 رصيدك الحالي: ${user.balance || 0} ج.م\n` +
      `📦 إجمالي الطلبات: ${user.totalOrders || 0}\n` +
      `📅 آخر نشاط: ${lastActiveDate.toLocaleDateString('ar-SA')}\n\n` +
      `📱 يمكنك شحن الرصيد أو عرض سجل المعاملات من الأزرار أدناه.`;
    
    await ctx.answerCbQuery();
    await safeEditMessage(ctx, message, keyboard);
  } catch (error) {
    console.error('Error in balance action:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء تحميل بيانات الرصيد');
  }
});

// Support - Enhanced UX
bot.action('support', async (ctx) => {
  try {
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('📞 الاتصال بالدعم', 'contact_support')],
      [Markup.button.callback('❓ الأسئلة الشائعة', 'faq')],
      [Markup.button.callback('🔙 رجوع للقائمة الرئيسية', 'back_to_main')]
    ]);
    
    await ctx.answerCbQuery();
    await safeEditMessage(ctx, BOT_CONFIG.MESSAGES.SUPPORT_INFO, keyboard);
  } catch (error) {
    console.error('Error in support action:', error);
    await ctx.answerCbQuery('❌ حدث خطأ');
  }
});

// Developer info - Enhanced UX
bot.action('developer', async (ctx) => {
  try {
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('💼 خدماتنا الأخرى', 'other_services')],
      [Markup.button.callback('🔙 رجوع للقائمة الرئيسية', 'back_to_main')]
    ]);
    
    await ctx.answerCbQuery();
    await safeEditMessage(ctx, BOT_CONFIG.MESSAGES.DEVELOPER_INFO, keyboard);
  } catch (error) {
    console.error('Error in developer action:', error);
    await ctx.answerCbQuery('❌ حدث خطأ');
  }
});

// Back to main menu
// Back to main menu action
bot.action(['back_to_main', 'main_menu'], async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId) return;

  const session = getUserSession(userId);
  session.currentStep = 'main';
  session.selectedProduct = null;
  session.selectedCategory = null;
  session.inputData = '';

  await ctx.answerCbQuery('العودة للقائمة الرئيسية');

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('🛍️ المنتجات', 'products')],
    [Markup.button.callback('📦 طلباتي', 'my_orders')],
    [Markup.button.callback('💰 رصيدي', 'balance')],
    [Markup.button.callback('ℹ️ الدعم الفني', 'support')],
    [Markup.button.callback('👨‍💻 عن المطور', 'developer')],
  ]);
  
  await safeEditMessage(ctx, BOT_CONFIG.MESSAGES.WELCOME, keyboard);
});

// Contact support handler
bot.action('contact_support', async (ctx) => {
  try {
    const supportMessage = '📞 **للتواصل مع الدعم الفني:**\n\n' +
      '✉️ Telegram: @AbodStoreVIP\n' +
      '🕐 ساعات العمل: من 9 صباحاً إلى 11 مساءً\n' +
      '⚡ متوسط وقت الرد: 30 دقيقة\n\n' +
      '💡 **نصائح للحصول على مساعدة سريعة:**\n' +
      '• اذكر رقم الطلب إذا كان متعلق بطلب معين\n' +
      '• اشرح المشكلة بالتفصيل\n' +
      '• أرفق لقطة شاشة إذا أمكن';
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.url('💬 تواصل معنا', 'https://t.me/AbodStoreVIP')],
      [Markup.button.callback('🔙 رجوع للدعم', 'support')]
    ]);
    
    await ctx.answerCbQuery();
    await safeEditMessage(ctx, supportMessage, keyboard);
  } catch (error) {
    console.error('Error in contact_support:', error);
    await ctx.answerCbQuery('❌ حدث خطأ');
  }
});

// FAQ handler
bot.action('faq', async (ctx) => {
  try {
    const faqMessage = '❓ **الأسئلة الشائعة:**\n\n' +
      '**س: كم يستغرق تنفيذ الطلب؟**\n' +
      'ج: عادة من 5-30 دقيقة حسب نوع الخدمة\n\n' +
      '**س: هل يمكن إلغاء الطلب؟**\n' +
      'ج: نعم، قبل البدء في التنفيذ فقط\n\n' +
      '**س: ماذا لو لم يعمل الكود؟**\n' +
      'ج: تواصل معنا فوراً وسنحل المشكلة\n\n' +
      '**س: هل الدفع آمن؟**\n' +
      'ج: نعم، نحن نستخدم أنظمة دفع آمنة\n\n' +
      '**س: كيف أشحن رصيدي؟**\n' +
      'ج: من قسم "رصيدي" اختر المبلغ وأرسل إيصال الدفع';
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('📞 تواصل للمزيد', 'contact_support')],
      [Markup.button.callback('🔙 رجوع للدعم', 'support')]
    ]);
    
    await ctx.answerCbQuery();
    await safeEditMessage(ctx, faqMessage, keyboard);
  } catch (error) {
    console.error('Error in faq:', error);
    await ctx.answerCbQuery('❌ حدث خطأ');
  }
});

// Other services handler
bot.action('other_services', async (ctx) => {
  try {
    const servicesMessage = '💼 **خدماتنا الأخرى:**\n\n' +
      '🔹 تطوير التطبيقات والمواقع\n' +
      '🔹 خدمات التصميم الجرافيكي\n' +
      '🔹 إدارة حسابات التواصل الاجتماعي\n' +
      '🔹 حلول التجارة الإلكترونية\n' +
      '🔹 استشارات تقنية متخصصة\n\n' +
      '📞 للاستفسار عن أي خدمة اضافية تواصل معنا';
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('📞 استفسار', 'contact_support')],
      [Markup.button.callback('🔙 رجوع لمعلومات المطور', 'developer')]
    ]);
    
    await ctx.answerCbQuery();
    await safeEditMessage(ctx, servicesMessage, keyboard);
  } catch (error) {
    console.error('Error in other_services:', error);
    await ctx.answerCbQuery('❌ حدث خطأ');
  }
});

// Balance actions - Enhanced with topup request system
bot.action('add_balance', async (ctx) => {
  await ctx.answerCbQuery('💳 شحن الرصيد');
  
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('💰 50 ج.م', 'request_charge_50')],
    [Markup.button.callback('💰 100 ج.م', 'request_charge_100')],
    [Markup.button.callback('💰 200 ج.م', 'request_charge_200')],
    [Markup.button.callback('💰 500 ج.م', 'request_charge_500')],
    [Markup.button.callback('💰 مبلغ مخصص', 'custom_charge_amount')],
    [Markup.button.callback('📄 طلباتي السابقة', 'my_topup_requests')],
    [Markup.button.callback('🔙 رجوع', 'balance')]
  ]);
  
  const message = '💳 **طلب شحن الرصيد**\n\n' +
    '🔹 اختر المبلغ المطلوب شحنه\n' +
    '🔹 سيتم إرسال طلبك للإدارة\n' +
    '🔹 ستتلقى إشعار عند الموافقة\n\n' +
    '💡 **طرق الدفع المتاحة:**\n' +
    '• فودافون كاش\n' +
    '• انستاباي\n' +
    '• البنوك الإلكترونية';
  
  await safeEditMessage(ctx, message, keyboard);
});

// Topup request handlers
bot.action(/request_charge_(\d+)/, async (ctx) => {
  const amount = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  const username = ctx.from?.username || ctx.from?.first_name || `User_${userId}`;
  
  if (!userId) return;
  
  try {
    await ctx.answerCbQuery('جاري إرسال طلب الشحن...');
    
    // Create topup request in database
    const request = await storage.createBalanceTopupRequest({
      userId: userId,
      amount: amount,
      paymentMethod: 'pending' // Will be updated when user provides payment info
    });
    
    // Send notification to admin
    await sendTopupRequestToAdmin(userId, username, amount, request.id);
    
    const successMessage = `✅ **تم إرسال طلب شحن الرصيد**\n\n` +
      `💰 المبلغ: ${amount} ج.م\n` +
      `🆔 رقم الطلب: #${request.id}\n` +
      `👤 اسم المستخدم: ${username}\n\n` +
      `⏳ **الخطوات التالية:**\n` +
      `1. ستتلقى رسالة من الإدارة قريباً\n` +
      `2. سيتم إرسال تفاصيل الدفع\n` +
      `3. أرسل إيصال الدفع للإدارة\n` +
      `4. سيتم شحن رصيدك فوراً\n\n` +
      `📱 للاستفسار: @AbodStoreVIP`;
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('📄 طلباتي', 'my_topup_requests')],
      [Markup.button.callback('💰 الرصيد', 'balance')],
      [Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')]
    ]);
    
    await safeEditMessage(ctx, successMessage, keyboard);
  } catch (error) {
    console.error('Error creating topup request:', error);
    await safeEditMessage(ctx, '❌ حدث خطأ أثناء إرسال طلب الشحن. حاول مرة أخرى.',
      Markup.inlineKeyboard([
        [Markup.button.callback('🔄 إعادة المحاولة', 'add_balance')],
        [Markup.button.callback('🔙 رجوع', 'balance')]
      ])
    );
  }
});

// Custom amount handler
bot.action('custom_charge_amount', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId) return;
  
  const session = getUserSession(userId);
  session.currentStep = 'awaiting_custom_amount';
  
  await ctx.answerCbQuery();
  await safeEditMessage(ctx, '💰 **أدخل المبلغ المطلوب**\n\n' +
    '📝 اكتب المبلغ بالجنيه المصري\n' +
    '💡 الحد الأدنى: 10 ج.م\n' +
    '💡 الحد الأقصى: 5000 ج.م\n\n' +
    'مثال: 150',
    Markup.inlineKeyboard([
      [Markup.button.callback('❌ إلغاء', 'add_balance')]
    ])
  );
});

// My topup requests
bot.action('my_topup_requests', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId) return;
  
  try {
    await ctx.answerCbQuery();
    const requests = await storage.getBalanceTopupRequestsByUser(userId);
    
    let message = '📄 **طلباتك للشحن:**\n\n';
    
    if (requests.length === 0) {
      message += '📭 لا توجد طلبات شحن سابقة.';
    } else {
      requests.forEach((request: any, index: number) => {
        const statusEmoji: { [key: string]: string } = {
          'pending': '⏳',
          'approved': '✅', 
          'rejected': '❌'
        };
        const emoji = statusEmoji[request.status] || '❓';
        
        const date = new Date(request.createdAt).toLocaleDateString('ar-SA');
        message += `${emoji} طلب #${request.id}\n`;
        message += `💰 ${request.amount} ج.م - ${request.status === 'approved' ? 'مكتمل' : request.status === 'pending' ? 'قيد المراجعة' : 'مرفوض'}\n`;
        message += `📅 ${date}\n\n`;
      });
    }
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('💳 طلب شحن جديد', 'add_balance')],
      [Markup.button.callback('🔙 رجوع للرصيد', 'balance')]
    ]);
    
    await safeEditMessage(ctx, message, keyboard);
  } catch (error) {
    console.error('Error fetching user topup requests:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء جلب الطلبات');
  }
});

// Text handler for custom amount and command suggestions
bot.on('text', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId) return;
  
  const session = getUserSession(userId);
  const text = ctx.message.text;
  
  // Handle custom amount input
  if (session.currentStep === 'awaiting_custom_amount') {
    const amount = parseFloat(text);
    
    if (isNaN(amount) || amount < 10 || amount > 5000) {
      await ctx.reply('❌ المبلغ غير صحيح!\n\n💡 يجب أن يكون بين 10 و 5000 جنيه مصري.\nحاول مرة أخرى:');
      return;
    }
    
    try {
      const username = ctx.from?.username || ctx.from?.first_name || `User_${userId}`;
      
      // Create custom amount topup request
      const request = await storage.createBalanceTopupRequest({
        userId: userId,
        amount: amount,
        paymentMethod: 'pending'
      });
      
      // Send to admin
      await sendTopupRequestToAdmin(userId, username, amount, request.id);
      
      // Reset session
      session.currentStep = 'main';
      
      const successMessage = `✅ **تم إرسال طلب شحن بمبلغ ${amount} ج.م**\n\n` +
        `🆔 رقم الطلب: #${request.id}\n` +
        `⏳ سيتم مراجعة طلبك وإرسال تفاصيل الدفع قريباً`;
      
      await ctx.reply(successMessage, Markup.inlineKeyboard([
        [Markup.button.callback('📄 طلباتي', 'my_topup_requests')],
        [Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')]
      ]));
      
    } catch (error) {
      console.error('Error creating custom topup request:', error);
      await ctx.reply('❌ حدث خطأ أثناء إرسال الطلب. حاول مرة أخرى.');
    }
    return;
  }
  
  // Handle general text input - Show available commands
  if (session.currentStep === 'main' || !session.currentStep) {
    const commandSuggestions = getCommandSuggestions(text);
    
    if (commandSuggestions.length > 0) {
      let message = '🤖 **الأوامر المتاحة:**\n\n';
      message += 'يبدو أنك تبحث عن أحد الأوامر التالية:\n\n';
      
      const keyboard = commandSuggestions.map(cmd => [
        Markup.button.callback(`${cmd.icon} ${cmd.title}`, cmd.action)
      ]);
      
      // Always add main menu option
      keyboard.push([Markup.button.callback('🏠 القائمة الرئيسية', 'main_menu')]);
      
      await ctx.reply(message, Markup.inlineKeyboard(keyboard));
    } else {
      // Show all available commands if no specific match
      const allCommandsMessage = '💡 **الأوامر المتاحة:**\n\n' +
        'يمكنك استخدام هذه الأوامر بكتابتها مباشرة أو اختيارها من الأزرار:\n\n' +
        '🛍️ `/digital_goods` - عرض المنتجات الرقمية\n' +
        '💰 `/balance` - عرض رصيدك الحالي\n' +
        'ℹ️ `/support` - معلومات الدعم الفني\n' +
        '👨‍💻 `/developer` - معلومات المطور\n\n' +
        'أو استخدم الأزرار أدناه:';
      
      const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🛍️ المنتجات الرقمية', 'products')],
        [Markup.button.callback('💰 رصيدي', 'balance')],
        [Markup.button.callback('📦 طلباتي', 'my_orders')],
        [Markup.button.callback('ℹ️ الدعم الفني', 'support')],
        [Markup.button.callback('👨‍💻 عن المطور', 'developer')],
        [Markup.button.callback('🏠 القائمة الرئيسية', 'main_menu')]
      ]);
      
      await ctx.reply(allCommandsMessage, keyboard);
    }
  }
});

// Function to get command suggestions based on user input
function getCommandSuggestions(text: string): Array<{title: string, icon: string, action: string}> {
  const lowerText = text.toLowerCase().trim();
  const suggestions = [];
  
  // Arabic and English keywords for different commands
  const keywords = {
    products: ['منتج', 'منتجات', 'شراء', 'بضائع', 'رقمي', 'digital', 'products', 'goods', 'buy', 'purchase', 'game', 'games', 'العاب', 'لعب', 'لعبة'],
    balance: ['رصيد', 'محفظة', 'فلوس', 'مال', 'balance', 'wallet', 'money', 'funds', 'شحن'],
    orders: ['طلب', 'طلبات', 'شراء', 'مشتريات', 'orders', 'purchases', 'history', 'تاريخ'],
    support: ['دعم', 'مساعدة', 'مشكلة', 'help', 'support', 'contact', 'تواصل', 'استفسار'],
    developer: ['مطور', 'صانع', 'developer', 'creator', 'about', 'من', 'info', 'معلومات']
  };
  
  // Check for product-related keywords
  if (keywords.products.some(keyword => lowerText.includes(keyword))) {
    suggestions.push({
      title: 'المنتجات الرقمية',
      icon: '🛍️',
      action: 'products'
    });
  }
  
  // Check for balance-related keywords
  if (keywords.balance.some(keyword => lowerText.includes(keyword))) {
    suggestions.push({
      title: 'عرض الرصيد',
      icon: '💰',
      action: 'balance'
    });
  }
  
  // Check for orders-related keywords
  if (keywords.orders.some(keyword => lowerText.includes(keyword))) {
    suggestions.push({
      title: 'طلباتي',
      icon: '📦',
      action: 'my_orders'
    });
  }
  
  // Check for support-related keywords
  if (keywords.support.some(keyword => lowerText.includes(keyword))) {
    suggestions.push({
      title: 'الدعم الفني',
      icon: 'ℹ️',
      action: 'support'
    });
  }
  
  // Check for developer-related keywords
  if (keywords.developer.some(keyword => lowerText.includes(keyword))) {
    suggestions.push({
      title: 'عن المطور',
      icon: '👨‍💻',
      action: 'developer'
    });
  }
  
  return suggestions;
}

// Cancel order handler
bot.action('cancel_order', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId) return;
  
  try {
    await ctx.answerCbQuery('❌ تم إلغاء الطلب');
    
    const session = getUserSession(userId);
    // Reset session
    session.currentStep = 'main';
    session.selectedProduct = null;
    session.selectedCategory = null;
    session.inputData = '';
    session.mixedPayment = null;
    session.paymentInProgress = false;
    
    // Return to main menu
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('🛍️ المنتجات', 'products')],
      [Markup.button.callback('📦 طلباتي', 'my_orders')],
      [Markup.button.callback('💰 رصيدي', 'balance')],
      [Markup.button.callback('ℹ️ الدعم الفني', 'support')],
      [Markup.button.callback('👨‍💻 عن المطور', 'developer')]
    ]);
    
    await safeEditMessage(ctx, '😔 **تم إلغاء الطلب**\n\n🏠 عدت للقائمة الرئيسية. ماذا تريد أن تفعل؟', keyboard);
    
  } catch (error) {
    console.error('Error in cancel_order:', error);
    await ctx.answerCbQuery('⚠️ حدث خطأ');
  }
});

// Function to send topup request to admin
async function sendTopupRequestToAdmin(userId: number, username: string, amount: number, requestId: number) {
  try {
    const { BOT_CONFIG } = await import('../config/bot-config');
    const { Telegraf } = await import('telegraf');
    const adminBot = new Telegraf(BOT_CONFIG.ADMIN_BOT_TOKEN);
    
    const message = `🔔 **طلب شحن رصيد جديد**\n\n` +
      `👤 المستخدم: ${username}\n` +
      `🆔 الآيدي: \`${userId}\`\n` +
      `💰 المبلغ: ${amount} ج.م\n` +
      `📝 رقم الطلب: #${requestId}\n` +
      `📅 التوقيت: ${new Date().toLocaleString('ar-SA')}\n\n` +
      `📋 **للمعالجة:**\n` +
      `• انسخ الآيدي: \`${userId}\`\n` +
      `• ادخل على قسم "طلبات الشحن"\n` +
      `• اضغط موافقة بعد استلام الدفع`;
    
    const keyboard = {
      inline_keyboard: [
        [
          { text: '✅ موافقة سريعة', callback_data: `quick_approve_${requestId}` },
          { text: '❌ رفض', callback_data: `quick_reject_${requestId}` }
        ],
        [
          { text: '💳 إدارة طلبات الشحن', callback_data: 'topup_requests' }
        ]
      ]
    };
    
    // Send to all admin IDs
    for (const adminId of BOT_CONFIG.ADMIN_IDS) {
      try {
        await adminBot.telegram.sendMessage(adminId, message, {
          parse_mode: 'Markdown',
          reply_markup: keyboard
        });
      } catch (error) {
        console.error(`Failed to send notification to admin ${adminId}:`, error);
      }
    }
  } catch (error) {
    console.error('Error sending admin notification:', error);
  }
}

bot.action('balance_history', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId) return;

  await ctx.answerCbQuery('📊 سجل المعاملات');
  
  try {
    const transactions = await storage.getUserBalanceHistory(userId, 10);
    
    let historyText = '📊 **سجل المعاملات الأخيرة:**\n\n';
    
    if (transactions.length === 0) {
      historyText += '❌ لا توجد معاملات سابقة.';
    } else {
      transactions.forEach((transaction, index) => {
        const typeIcon = transaction.type === 'credit' ? '📈' : '📉';
        const sign = transaction.amount >= 0 ? '+' : '';
        const date = new Date(transaction.createdAt).toLocaleDateString('ar-SA');
        
        historyText += `${typeIcon} ${sign}${transaction.amount} ج.م\n`;
        historyText += `📝 ${transaction.description}\n`;
        historyText += `📅 ${date}\n`;
        historyText += `💰 الرصيد بعدها: ${transaction.balanceAfter} ج.م\n\n`;
      });
    }
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('🔄 تحديث', 'balance_history')],
      [Markup.button.callback('🔙 رجوع', 'balance')]
    ]);
    
    await safeEditMessage(ctx, historyText, keyboard);
  } catch (error) {
    console.error('Error fetching balance history:', error);
    await safeEditMessage(ctx, 
      '❌ حدث خطأ أثناء جلب سجل المعاملات.',
      Markup.inlineKeyboard([
        [Markup.button.callback('🔙 رجوع', 'balance')]
      ])
    );
  }
});

// Topup status tracking
bot.action(/topup_status_(\d+)/, async (ctx) => {
  const topupId = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  
  if (!userId) return;
  
  try {
    const topupRequest = await storage.getBalanceTopupRequest(topupId);
    
    if (!topupRequest || topupRequest.userId !== userId) {
      await ctx.answerCbQuery('❌ طلب الشحن غير موجود أو ليس مخصص لك.');
      return;
    }
    
    let statusText = `📞 **متابعة طلب الشحن #${topupRequest.id}**\n\n`;
    statusText += `💰 المبلغ: ${topupRequest.amount} ج.م\n`;
    statusText += `📅 تاريخ الطلب: ${new Date(topupRequest.createdAt).toLocaleDateString('ar-SA')}\n`;
    
    let statusIcon = '';
    let statusDesc = '';
    
    switch (topupRequest.status) {
      case 'pending':
        statusIcon = '⏳';
        statusDesc = 'قيد المراجعة';
        break;
      case 'approved':
        statusIcon = '✅';
        statusDesc = 'تم الموافقة والشحن';
        break;
      case 'rejected':
        statusIcon = '❌';
        statusDesc = 'تم الرفض';
        break;
    }
    
    statusText += `${statusIcon} الحالة: ${statusDesc}\n`;
    
    if (topupRequest.adminNotes) {
      statusText += `📝 ملاحظات الإدارة: ${topupRequest.adminNotes}\n`;
    }
    
    if (topupRequest.processedAt) {
      statusText += `⚡ تاريخ المعالجة: ${new Date(topupRequest.processedAt).toLocaleDateString('ar-SA')}\n`;
    }
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('🔄 تحديث الحالة', `topup_status_${topupId}`)],
      [Markup.button.callback('💰 عرض الرصيد', 'balance')],
      [Markup.button.callback('🔙 القائمة الرئيسية', 'main_menu')]
    ]);
    
    await ctx.answerCbQuery('تم تحديث حالة الطلب');
    await safeEditMessage(ctx, statusText, keyboard);
    
  } catch (error) {
    console.error('Error fetching topup status:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء جلب حالة الطلب.');
  }
});

// Charge amount actions
bot.action(['charge_50', 'charge_100', 'charge_200', 'charge_500'], async (ctx) => {
  const amount = ctx.match![0].replace('charge_', '');
  await ctx.answerCbQuery(`جاري معالجة شحن ${amount} ج.م`);
  
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('💳 تأكيد الدفع', `confirm_payment_${amount}`)],
    [Markup.button.callback('❌ إلغاء', 'add_balance')]
  ]);
  
  await safeEditMessage(ctx, `💳 تأكيد شحن الرصيد بمبلغ ${amount} ج.م\n\nالمبلغ المطلوب: ${amount} ج.م`, keyboard);
});

bot.action(/confirm_payment_(\d+)/, async (ctx) => {
  const amount = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  
  if (!userId) return;
  
  await ctx.answerCbQuery('جاري معالجة طلب الشحن...');
  
  try {
    // Create balance topup request
    const topupRequest = await storage.createBalanceTopupRequest({
      userId: userId,
      amount: amount,
      paymentMethod: 'manual_payment',
      requestDetails: `طلب شحن رصيد بمبلغ ${amount} ج.م من البوت`,
    });
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('📞 متابعة الطلب', `topup_status_${topupRequest.id}`)],
      [Markup.button.callback('💰 عرض الرصيد', 'balance')],
      [Markup.button.callback('🔙 القائمة الرئيسية', 'main_menu')]
    ]);
    
    await safeEditMessage(ctx, 
      `✅ تم إرسال طلب الشحن بنجاح!\n\n💰 المبلغ: ${amount} ج.م\n🆔 رقم الطلب: #${topupRequest.id}\n⏳ الحالة: قيد المراجعة\n\n📞 سيتواصل معك الدعم الفني قريباً لإتمام العملية.\n\n🏪 @AbodStoreVIP`,
      keyboard
    );
  } catch (error) {
    console.error('Error creating topup request:', error);
    await safeEditMessage(ctx, 
      '❌ حدث خطأ أثناء إنشاء طلب الشحن. يرجى المحاولة مرة أخرى.',
      Markup.inlineKeyboard([
        [Markup.button.callback('🔙 رجوع', 'add_balance')]
      ])
    );
  }
});

// My orders action
bot.action('my_orders', async (ctx) => {
  console.log('📦 USER MY ORDERS CALLBACK TRIGGERED');
  const userId = ctx.from?.id;
  if (!userId) return;

  try {
    await ctx.answerCbQuery('جاري تحميل طلباتك...');
    
    const orders = await storage.getOrdersByUser(userId);
    
    let message = '⏳ **طلباتي:**\n\n';
    
    if (orders.length === 0) {
      message += '📦 لا توجد لديك طلبات سابقة.';
    } else {
      for (const order of orders.slice(0, 10)) {
        const product = await storage.getProduct(order.productId);
        const category = await storage.getCategory(order.categoryId);
        
        const statusEmoji = order.status === 'pending' ? '⏳' : 
                           order.status === 'completed' ? '✅' : '❌';
        const statusText = order.status === 'pending' ? 'قيد التنفيذ' : 
                          order.status === 'completed' ? 'مكتمل' : 'ملغي';
        
        message += `🆔 طلب #${order.id}\n`;
        message += `📱 ${product?.name || 'غير معروف'}\n`;
        message += `💰 ${category?.price || 0} ⭐\n`;
        message += `${statusEmoji} ${statusText}\n`;
        message += `📅 ${new Date(order.createdAt).toLocaleDateString('ar-SA')}\n`;
        
        // إضافة الملاحظات إذا كانت موجودة
        if (order.adminNotes) {
          message += `📝 ملاحظات: ${order.adminNotes}\n`;
        }
        
        // إضافة الكود إذا كان موجوداً
        if (order.codeIfAny) {
          message += `🎁 الكود: ${order.codeIfAny}\n`;
        }
        
        message += `\n`;
      }
      
      if (orders.length > 10) {
        message += `... و ${orders.length - 10} طلبات أخرى`;
      }
    }
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('🔙 رجوع للقائمة الرئيسية', 'main_menu')]
    ]);
    
    await safeEditMessage(ctx, message, { parse_mode: 'Markdown', ...keyboard });
  } catch (error) {
    console.error('Error in my_orders action:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء تحميل الطلبات.');
  }
});

// Cancel order
bot.action('cancel_order', async (ctx) => {
  const userId = ctx.from?.id;
  
  if (!userId) return;
  
  const session = getUserSession(userId);
  session.currentStep = 'main';
  session.selectedProduct = null;
  session.selectedCategory = null;
  session.inputData = '';
  
  await ctx.answerCbQuery('تم إلغاء الطلب');
  
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('🛍️ المنتجات', 'products')],
    [Markup.button.callback('📦 طلباتي', 'my_orders')],
    [Markup.button.callback('💰 رصيدي', 'balance')],
    [Markup.button.callback('ℹ️ الدعم الفني', 'support')],
    [Markup.button.callback('👨‍💻 عن المطور', 'developer')],
  ]);
  
  await safeEditMessage(ctx, BOT_CONFIG.MESSAGES.WELCOME, keyboard);
});

export async function startUserBot(): Promise<void> {
  try {
    console.log('🔧 Starting user bot...');
    
    // Clear any existing webhook first
    await bot.telegram.deleteWebhook();
    console.log('🗑️ Cleared user bot webhook');
    
    // Test bot connection first
    const botInfo = await bot.telegram.getMe();
    console.log(`📱 User bot info: @${botInfo.username} (ID: ${botInfo.id})`);
    
    // Configure bot settings
    bot.telegram.webhookReply = false;
    
    // Start the bot without timeout - let it run naturally
    console.log('🚀 Launching user bot...');
    bot.launch({
      dropPendingUpdates: true,
      allowedUpdates: ['message', 'callback_query'] as const
    }).then(() => {
      console.log('✅ User bot connected and ready!');
    }).catch((error) => {
      console.error('❌ User bot launch failed:', error);
      console.log('🔄 Will retry in 10 seconds...');
      setTimeout(() => startUserBot(), 10000);
    });
    
    // Don't wait for launch - return immediately
    console.log('🎆 User bot startup initiated');
    
  } catch (error) {
    console.error('❌ Failed to start user bot:', error);
    console.log('🔄 Retrying in 5 seconds...');
    setTimeout(() => startUserBot(), 5000);
  }
}

// Graceful shutdown
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
