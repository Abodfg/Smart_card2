import { Telegraf, Markup } from 'telegraf';
import { BOT_CONFIG } from '../config/bot-config';
import { DatabaseService } from '../services/database';
import { NotificationService } from '../utils/notifications';
import { storage } from '../storage';

const bot = new Telegraf(BOT_CONFIG.ADMIN_BOT_TOKEN);

// Safe edit message function to handle "message is not modified" error
async function safeEditMessage(ctx: any, text: string, extra?: any) {
  try {
    await ctx.editMessageText(text, extra);
  } catch (error: any) {
    // Silently ignore "message is not modified" error (400)
    if (error.code === 400 && error.description?.includes('message is not modified')) {
      // Message content is the same, no need to update
      return;
    }
    // Re-throw other errors
    throw error;
  }
}

// Admin session management
const adminSessions = new Map<number, any>();

// Helper function to check if user is admin
function isAdmin(userId: number): boolean {
  return BOT_CONFIG.ADMIN_IDS.includes(userId);
}

// Helper function to get or create admin session
function getAdminSession(userId: number) {
  if (!adminSessions.has(userId)) {
    adminSessions.set(userId, {
      currentStep: 'main',
      currentProduct: null,
    });
  }
  return adminSessions.get(userId);
}

// Start command
bot.start(async (ctx) => {
  const userId = ctx.from?.id;
  
  if (!userId || !isAdmin(userId)) {
    await ctx.reply('❌ غير مسموح لك بالوصول لهذا البوت');
    return;
  }
  
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('📊 الإحصائيات', 'stats')],
    [Markup.button.callback('📦 الطلبات', 'orders')],
    [Markup.button.callback('💳 طلبات الشحن', 'topup_requests')],
    [Markup.button.callback('🛍️ المنتجات', 'products')],
    [Markup.button.callback('👥 المستخدمين', 'users')],
    [Markup.button.callback('💰 الرصيد', 'balance')],
    [Markup.button.callback('⚙️ الإعدادات', 'settings')],
  ]);

  await ctx.reply('👨‍💼 مرحباً بك في لوحة تحكم الإدارة', keyboard);
});

// Statistics
bot.action('stats', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  await ctx.answerCbQuery('جاري تحميل الإحصائيات...');
  
  const stats = await storage.getOrderStats();
  const totalUsers = (await storage.getAllUsers()).length;
  
  let message = '📊 إحصائيات النظام:\n\n';
  message += `👥 إجمالي المستخدمين: ${totalUsers}\n`;
  message += `💰 إجمالي المبيعات: ⭐ ${stats.totalRevenue}\n`;
  
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('🔄 تحديث', 'stats')],
    [Markup.button.callback('← رجوع', 'back_to_main')]
  ]);
  
  await safeEditMessage(ctx, message, keyboard);
});

// Orders Management
bot.action('orders', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  await ctx.answerCbQuery('جاري تحميل قائمة الطلبات...');
  
  try {
    const allOrders = await storage.getAllOrders();
    
    let message = '📦 **إدارة الطلبات:**\n\n';
    
    if (allOrders.length === 0) {
      message += '✅ لا توجد طلبات مسجلة حالياً.';
    } else {
      // Group orders by status
      const pendingOrders = allOrders.filter(order => order.status === 'pending');
      const completedOrders = allOrders.filter(order => order.status === 'completed');
      const cancelledOrders = allOrders.filter(order => order.status === 'cancelled');
      
      message += `📊 **إحصائيات سريعة:**\n`;
      message += `⏳ قيد التنفيذ: ${pendingOrders.length}\n`;
      message += `✅ مكتمل: ${completedOrders.length}\n`;
      message += `❌ ملغي: ${cancelledOrders.length}\n`;
      message += `📋 الإجمالي: ${allOrders.length}\n\n`;
      
      // Show recent orders (last 10)
      const recentOrders = allOrders.slice(-10).reverse();
      message += `📋 **آخر ${Math.min(10, allOrders.length)} طلبات:**\n\n`;
      
      for (const order of recentOrders) {
        const user = await storage.getUser(order.userId);
        const product = await storage.getProduct(order.productId);
        const category = await storage.getCategory(order.categoryId);
        
        const username = user?.username || `المستخدم ${order.userId}`;
        const productName = product?.name || 'منتج محذوف';
        const categoryName = category?.name || 'فئة محذوفة';
        const statusEmoji = order.status === 'pending' ? '⏳' : 
                           order.status === 'completed' ? '✅' : '❌';
        
        const createdDate = new Date(order.createdAt).toLocaleDateString('ar-SA');
        
        message += `${statusEmoji} **طلب #${order.id}**\n`;
        message += `👤 ${username}\n`;
        message += `🎮 ${productName} - ${categoryName}\n`;
        message += `📅 ${createdDate}\n`;
        message += `💰 ⭐ ${order.paidAmount || 'غير محدد'}\n\n`;
      }
      
      if (allOrders.length > 10) {
        message += `... و ${allOrders.length - 10} طلبات أخرى`;
      }
    }
    
    const keyboard = [];
    
    // Filter buttons
    keyboard.push([
      Markup.button.callback('⏳ الطلبات المعلقة', 'pending_orders'),
      Markup.button.callback('✅ الطلبات المكتملة', 'completed_orders')
    ]);
    
    keyboard.push([
      Markup.button.callback('❌ الطلبات الملغية', 'cancelled_orders'),
      Markup.button.callback('🔍 البحث عن طلب', 'search_order')
    ]);
    
    keyboard.push([
      Markup.button.callback('🔄 تحديث القائمة', 'orders'),
      Markup.button.callback('← رجوع', 'back_to_main')
    ]);
    
    await safeEditMessage(ctx, message, Markup.inlineKeyboard(keyboard));
  } catch (error) {
    console.error('Error fetching orders:', error);
    await safeEditMessage(ctx, '❌ حدث خطأ أثناء جلب الطلبات.', 
      Markup.inlineKeyboard([[Markup.button.callback('← رجوع', 'back_to_main')]]));
  }
});

// Pending Orders
bot.action('pending_orders', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  await ctx.answerCbQuery('جاري تحميل الطلبات المعلقة...');
  
  try {
    const pendingOrders = await storage.getOrdersByStatus('pending');
    
    let message = '⏳ **الطلبات قيد التنفيذ:**\n\n';
    
    if (pendingOrders.length === 0) {
      message += '✅ لا توجد طلبات قيد التنفيذ حالياً.';
    } else {
      message += `📊 عدد الطلبات المعلقة: ${pendingOrders.length}\n\n`;
      
      // Show first 8 pending orders
      const displayOrders = pendingOrders.slice(0, 8);
      
      for (const order of displayOrders) {
        const user = await storage.getUser(order.userId);
        const product = await storage.getProduct(order.productId);
        const category = await storage.getCategory(order.categoryId);
        
        const username = user?.username || `المستخدم ${order.userId}`;
        const productName = product?.name || 'منتج محذوف';
        const categoryName = category?.name || 'فئة محذوفة';
        const createdDate = new Date(order.createdAt).toLocaleDateString('ar-SA');
        
        message += `🆔 **طلب #${order.id}**\n`;
        message += `👤 ${username}\n`;
        message += `🎮 ${productName} - ${categoryName}\n`;
        message += `📅 ${createdDate}\n`;
        message += `💰 ⭐ ${order.paidAmount || 'غير محدد'}\n\n`;
      }
      
      if (pendingOrders.length > 8) {
        message += `... و ${pendingOrders.length - 8} طلبات أخرى`;
      }
    }
    
    const keyboard = [];
    
    // Show action buttons for first 4 pending orders
    if (pendingOrders.length > 0) {
      const actionOrders = pendingOrders.slice(0, 4);
      actionOrders.forEach(order => {
        keyboard.push([
          Markup.button.callback(`👀 عرض #${order.id}`, `order_${order.id}`)
        ]);
      });
      
      keyboard.push([Markup.button.callback('🔄 تحديث القائمة', 'pending_orders')]);
    }
    
    keyboard.push([
      Markup.button.callback('📦 جميع الطلبات', 'orders'),
      Markup.button.callback('← رجوع', 'back_to_main')
    ]);
    
    await safeEditMessage(ctx, message, Markup.inlineKeyboard(keyboard));
  } catch (error) {
    console.error('Error fetching pending orders:', error);
    await safeEditMessage(ctx, '❌ حدث خطأ أثناء جلب الطلبات المعلقة.', 
      Markup.inlineKeyboard([[Markup.button.callback('← رجوع', 'back_to_main')]]));
  }
});

// Completed Orders
bot.action('completed_orders', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  await ctx.answerCbQuery('جاري تحميل الطلبات المكتملة...');
  
  try {
    const completedOrders = await storage.getOrdersByStatus('completed');
    
    let message = '✅ **الطلبات المكتملة:**\n\n';
    
    if (completedOrders.length === 0) {
      message += '📋 لا توجد طلبات مكتملة حالياً.';
    } else {
      message += `📊 عدد الطلبات المكتملة: ${completedOrders.length}\n\n`;
      
      // Show last 8 completed orders (most recent first)
      const displayOrders = completedOrders.slice(-8).reverse();
      
      for (const order of displayOrders) {
        const user = await storage.getUser(order.userId);
        const product = await storage.getProduct(order.productId);
        const category = await storage.getCategory(order.categoryId);
        
        const username = user?.username || `المستخدم ${order.userId}`;
        const productName = product?.name || 'منتج محذوف';
        const categoryName = category?.name || 'فئة محذوفة';
        const completedDate = order.completedAt ? 
          new Date(order.completedAt).toLocaleDateString('ar-SA') : 'غير محدد';
        
        message += `🆔 **طلب #${order.id}**\n`;
        message += `👤 ${username}\n`;
        message += `🎮 ${productName} - ${categoryName}\n`;
        message += `📅 اكتمل في: ${completedDate}\n`;
        message += `💰 ⭐ ${order.paidAmount || 'غير محدد'}\n\n`;
      }
      
      if (completedOrders.length > 8) {
        message += `... و ${completedOrders.length - 8} طلبات أخرى`;
      }
    }
    
    const keyboard = [];
    
    // Show view buttons for first 4 completed orders
    if (completedOrders.length > 0) {
      const actionOrders = completedOrders.slice(-4).reverse();
      actionOrders.forEach(order => {
        keyboard.push([
          Markup.button.callback(`👀 عرض #${order.id}`, `order_${order.id}`)
        ]);
      });
      
      keyboard.push([Markup.button.callback('🔄 تحديث القائمة', 'completed_orders')]);
    }
    
    keyboard.push([
      Markup.button.callback('📦 جميع الطلبات', 'orders'),
      Markup.button.callback('← رجوع', 'back_to_main')
    ]);
    
    await safeEditMessage(ctx, message, Markup.inlineKeyboard(keyboard));
  } catch (error) {
    console.error('Error fetching completed orders:', error);
    await safeEditMessage(ctx, '❌ حدث خطأ أثناء جلب الطلبات المكتملة.', 
      Markup.inlineKeyboard([[Markup.button.callback('← رجوع', 'back_to_main')]]));
  }
});

// Cancelled Orders
bot.action('cancelled_orders', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  await ctx.answerCbQuery('جاري تحميل الطلبات الملغية...');
  
  try {
    const cancelledOrders = await storage.getOrdersByStatus('cancelled');
    
    let message = '❌ **الطلبات الملغية:**\n\n';
    
    if (cancelledOrders.length === 0) {
      message += '📋 لا توجد طلبات ملغية حالياً.';
    } else {
      message += `📊 عدد الطلبات الملغية: ${cancelledOrders.length}\n\n`;
      
      // Show last 8 cancelled orders (most recent first)
      const displayOrders = cancelledOrders.slice(-8).reverse();
      
      for (const order of displayOrders) {
        const user = await storage.getUser(order.userId);
        const product = await storage.getProduct(order.productId);
        const category = await storage.getCategory(order.categoryId);
        
        const username = user?.username || `المستخدم ${order.userId}`;
        const productName = product?.name || 'منتج محذوف';
        const categoryName = category?.name || 'فئة محذوفة';
        const createdDate = new Date(order.createdAt).toLocaleDateString('ar-SA');
        
        message += `🆔 **طلب #${order.id}**\n`;
        message += `👤 ${username}\n`;
        message += `🎮 ${productName} - ${categoryName}\n`;
        message += `📅 ${createdDate}\n`;
        message += `💰 ⭐ ${order.paidAmount || 'غير محدد'}\n`;
        if (order.adminNotes) {
          message += `📝 سبب الإلغاء: ${order.adminNotes}\n`;
        }
        message += '\n';
      }
      
      if (cancelledOrders.length > 8) {
        message += `... و ${cancelledOrders.length - 8} طلبات أخرى`;
      }
    }
    
    const keyboard = [];
    
    // Show view buttons for first 4 cancelled orders
    if (cancelledOrders.length > 0) {
      const actionOrders = cancelledOrders.slice(-4).reverse();
      actionOrders.forEach(order => {
        keyboard.push([
          Markup.button.callback(`👀 عرض #${order.id}`, `order_${order.id}`)
        ]);
      });
      
      keyboard.push([Markup.button.callback('🔄 تحديث القائمة', 'cancelled_orders')]);
    }
    
    keyboard.push([
      Markup.button.callback('📦 جميع الطلبات', 'orders'),
      Markup.button.callback('← رجوع', 'back_to_main')
    ]);
    
    await safeEditMessage(ctx, message, Markup.inlineKeyboard(keyboard));
  } catch (error) {
    console.error('Error fetching cancelled orders:', error);
    await safeEditMessage(ctx, '❌ حدث خطأ أثناء جلب الطلبات الملغية.', 
      Markup.inlineKeyboard([[Markup.button.callback('← رجوع', 'back_to_main')]]));
  }
});

// Order Details - معالج عرض تفاصيل الطلب الكاملة
bot.action(/order_(\d+)/, async (ctx) => {
  const orderId = parseInt(ctx.match![1]);
  const adminId = ctx.from?.id;
  
  if (!adminId || !isAdmin(adminId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  await ctx.answerCbQuery('جاري تحميل تفاصيل الطلب...');
  
  try {
    const order = await storage.getOrder(orderId);
    
    if (!order) {
      await safeEditMessage(ctx, '❌ لم يتم العثور على الطلب المطلوب.', 
        Markup.inlineKeyboard([[Markup.button.callback('← رجوع', 'orders')]]));
      return;
    }
    
    // Get related data
    const user = await storage.getUser(order.userId);
    const product = await storage.getProduct(order.productId);
    const category = await storage.getCategory(order.categoryId);
    
    const username = user?.username || `المستخدم ${order.userId}`;
    const productName = product?.name || 'منتج محذوف';
    const categoryName = category?.name || 'فئة محذوفة';
    const statusEmoji = order.status === 'pending' ? '⏳' : 
                       order.status === 'completed' ? '✅' : '❌';
    const statusText = order.status === 'pending' ? 'قيد التنفيذ' : 
                      order.status === 'completed' ? 'مكتمل' : 'ملغي';
    
    const createdDate = new Date(order.createdAt).toLocaleString('ar-SA');
    const completedDate = order.completedAt ? 
      new Date(order.completedAt).toLocaleString('ar-SA') : null;
    
    // Build detailed message
    let message = `${statusEmoji} **تفاصيل الطلب #${order.id}**\n\n`;
    
    // Customer Information
    message += `👤 **معلومات العميل:**\n`;
    message += `الاسم: ${username}\n`;
    message += `المعرف: \`${order.userId}\`\n\n`;
    
    // Product Information
    message += `🎮 **معلومات المنتج:**\n`;
    message += `المنتج: ${productName}\n`;
    message += `الفئة: ${categoryName}\n`;
    message += `السعر: ⭐ ${order.paidAmount || 'غير محدد'}\n\n`;
    
    // Order Details
    message += `📋 **تفاصيل الطلب:**\n`;
    message += `الحالة: ${statusText} ${statusEmoji}\n`;
    message += `تاريخ الإنشاء: ${createdDate}\n`;
    if (completedDate) {
      message += `تاريخ الإكمال: ${completedDate}\n`;
    }
    message += `\n`;
    
    // Customer Input Data (Copyable)
    if (order.inputData && order.inputData.trim()) {
      message += `📝 **البيانات المُدخلة من العميل:**\n`;
      message += `\`${order.inputData}\`\n\n`;
    }
    
    // Admin Notes (if any)
    if (order.adminNotes && order.adminNotes.trim()) {
      message += `📋 **ملاحظات الإدارة:**\n`;
      message += `${order.adminNotes}\n\n`;
    }
    
    // Code/Response (if any)
    if (order.codeIfAny && order.codeIfAny.trim()) {
      message += `🎁 **الكود/التفاصيل المُسلمة:**\n`;
      message += `\`${order.codeIfAny}\`\n\n`;
    }
    
    // Quick Copy Section
    message += `📋 **نسخ سريع:**\n`;
    if (order.inputData && order.inputData.trim()) {
      message += `البيانات: \`${order.inputData}\`\n`;
    }
    if (order.codeIfAny && order.codeIfAny.trim()) {
      message += `الكود: \`${order.codeIfAny}\`\n`;
    }
    
    const keyboard = [];
    
    // Action buttons based on order status
    if (order.status === 'pending') {
      keyboard.push([
        Markup.button.callback('✅ إكمال الطلب', `complete_order_${order.id}`),
        Markup.button.callback('❌ إلغاء الطلب', `cancel_order_${order.id}`)
      ]);
    }
    
    // Navigation buttons
    keyboard.push([
      Markup.button.callback('🔄 تحديث التفاصيل', `order_${order.id}`)
    ]);
    
    keyboard.push([
      Markup.button.callback('📦 جميع الطلبات', 'orders'),
      Markup.button.callback('← رجوع', 'back_to_main')
    ]);
    
    await safeEditMessage(ctx, message, Markup.inlineKeyboard(keyboard));
  } catch (error) {
    console.error('Error fetching order details:', error);
    await safeEditMessage(ctx, '❌ حدث خطأ أثناء جلب تفاصيل الطلب.', 
      Markup.inlineKeyboard([[Markup.button.callback('← رجوع', 'orders')]]));
  }
});

// 🚨 PRIORITY HANDLERS - MOVED TO TOP TO AVOID CONFLICTS
// Cancel Order - إلغاء الطلب (HIGH PRIORITY)
bot.action(/cancel_order_(\d+)/, async (ctx) => {
  console.log('🔴 CANCEL ORDER CALLBACK TRIGGERED for Order:', ctx.match![1]);
  const orderId = parseInt(ctx.match![1]);
  const adminId = ctx.from?.id;
  
  console.log('🔴 Admin ID:', adminId, 'Order ID:', orderId);
  
  if (!adminId || !isAdmin(adminId)) {
    console.log('❌ Admin check failed for user:', adminId);
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  try {
    const order = await storage.getOrder(orderId);
    
    if (!order) {
      await ctx.answerCbQuery('❌ لم يتم العثور على الطلب');
      return;
    }
    
    if (order.status !== 'pending') {
      await ctx.answerCbQuery('❌ هذا الطلب تم معالجته مسبقاً');
      return;
    }
    
    // Get session and store current order
    const session = getAdminSession(adminId);
    session.currentOrder = orderId;
    session.currentStep = 'waiting_cancellation_reason';
    
    const user = await storage.getUser(order.userId);
    const product = await storage.getProduct(order.productId);
    const category = await storage.getCategory(order.categoryId);
    
    const username = user?.username || `المستخدم ${order.userId}`;
    const productName = product?.name || 'منتج محذوف';
    const categoryName = category?.name || 'فئة محذوفة';
    
    let message = `❌ **إلغاء الطلب #${order.id}**\n\n`;
    message += `👤 العميل: ${username}\n`;
    message += `🎮 المنتج: ${productName} - ${categoryName}\n`;
    message += `💰 السعر: ⭐ ${order.paidAmount || 'غير محدد'}\n\n`;
    
    if (order.inputData && order.inputData.trim()) {
      message += `📝 بيانات العميل:\n\`${order.inputData}\`\n\n`;
    }
    
    message += `📝 **أدخل سبب الإلغاء:**\n`;
    message += `💡 مثال: نفدت الكمية، مشكلة فنية، طلب العميل، إلخ...\n\n`;
    message += `👆 **اكتب سبب الإلغاء الآن:**`;
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('❌ إلغاء العملية', `order_${order.id}`)]
    ]);
    
    await safeEditMessage(ctx, message, keyboard);
    await ctx.answerCbQuery('أدخل سبب الإلغاء...');
  } catch (error) {
    console.error('Error initiating order cancellation:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء معالجة الطلب');
  }
});

// Complete Order - إكمال الطلب (HIGH PRIORITY)
bot.action(/complete_order_(\d+)/, async (ctx) => {
  console.log('🟢 COMPLETE ORDER CALLBACK TRIGGERED for Order:', ctx.match![1]);
  const orderId = parseInt(ctx.match![1]);
  const adminId = ctx.from?.id;
  
  console.log('🟢 Admin ID:', adminId, 'Order ID:', orderId);
  
  if (!adminId || !isAdmin(adminId)) {
    console.log('❌ Admin check failed for user:', adminId);
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  try {
    const order = await storage.getOrder(orderId);
    
    if (!order) {
      await ctx.answerCbQuery('❌ لم يتم العثور على الطلب');
      return;
    }
    
    if (order.status !== 'pending') {
      await ctx.answerCbQuery('❌ هذا الطلب تم معالجته مسبقاً');
      return;
    }
    
    // Get session and store current order for completion
    const session = getAdminSession(adminId);
    session.currentOrder = orderId;
    session.currentStep = 'waiting_completion_details';
    
    const user = await storage.getUser(order.userId);
    const product = await storage.getProduct(order.productId);
    const category = await storage.getCategory(order.categoryId);
    
    const username = user?.username || `المستخدم ${order.userId}`;
    const productName = product?.name || 'منتج محذوف';
    const categoryName = category?.name || 'فئة محذوفة';
    
    let message = `✅ **إكمال الطلب #${order.id}**\n\n`;
    message += `👤 العميل: ${username}\n`;
    message += `🎮 المنتج: ${productName} - ${categoryName}\n`;
    message += `💰 السعر: ⭐ ${order.paidAmount || 'غير محدد'}\n\n`;
    
    if (order.inputData && order.inputData.trim()) {
      message += `📝 بيانات العميل:\n\`${order.inputData}\`\n\n`;
    }
    
    message += `📝 **أدخل تفاصيل التنفيذ:**\n`;
    message += `💡 مثال: الكود، رقم الحساب المشحون، تفاصيل الاشتراك، إلخ...\n\n`;
    message += `👆 **اكتب التفاصيل الآن:**`;
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('❌ إلغاء العملية', `order_${order.id}`)]
    ]);
    
    await safeEditMessage(ctx, message, keyboard);
    await ctx.answerCbQuery('أدخل تفاصيل التنفيذ...');
  } catch (error) {
    console.error('Error initiating order completion:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء معالجة الطلب');
  }
});

// 🔍 DEBUG: Log ALL callback queries AFTER priority handlers
bot.on('callback_query', (ctx, next) => {
  const data = 'data' in ctx.callbackQuery ? ctx.callbackQuery.data : 'no_data';
  console.log('🔍 ADMIN BOT CALLBACK:', {
    data,
    userId: ctx.from?.id,
    username: ctx.from?.username,
    firstName: ctx.from?.first_name
  });
  return next();
});

// Search Order - البحث عن طلب  
bot.action('search_order', async (ctx) => {
  console.log('🔍 SEARCH USER CALLBACK TRIGGERED');
  const adminId = ctx.from?.id;
  
  if (!adminId || !isAdmin(adminId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  await ctx.answerCbQuery();
  // Search functionality here - placeholder for now
});

// Products - إدارة المنتجات

// 🗑️ REMOVED DUPLICATE TEXT HANDLER #1 - Using unified handler below

// Search Order - البحث عن طلب
bot.action('search_order', async (ctx) => {
  const adminId = ctx.from?.id;
  if (!adminId || !isAdmin(adminId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  // Get session and set search mode
  const session = getAdminSession(adminId);
  session.currentStep = 'waiting_order_search';
  
  let message = `🔍 **البحث عن طلب**\n\n`;
  message += `📋 أدخل أحد الطرق التالية للبحث:\n\n`;
  message += `🆔 **رقم الطلب:** أدخل الرقم فقط (مثل: 123)\n`;
  message += `👤 **معرف المستخدم:** أدخل معرف التليجرام\n`;
  message += `📱 **اسم المستخدم:** أدخل @username أو بدون @\n\n`;
  message += `💡 مثال: 123 أو 98765432 أو username`;
  
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('❌ إلغاء البحث', 'orders')]
  ]);
  
  await safeEditMessage(ctx, message, keyboard);
  await ctx.answerCbQuery('أدخل البيانات للبحث...');
});

// 🗑️ REMOVED DUPLICATE TEXT HANDLER #2 - Using unified handler below

// Products management
bot.action('products', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  await ctx.answerCbQuery('جاري تحميل قائمة المنتجات...');

  try {
    const products = await storage.getAllProducts();
    
    let message = '🛍️ إدارة المنتجات:\n\n';
    
    if (products.length === 0) {
      message += '📦 لا توجد منتجات حالياً.\n\n';
    } else {
      for (const product of products) {
        const categories = await storage.getCategoriesByProduct(product.id);
        message += `📱 ${product.name}\n`;
        message += `📝 ${product.description}\n`;
        message += `🚚 نوع الشحن: ${product.shippingType}\n`;
        message += `📋 عدد الفئات: ${categories.length}\n\n`;
      }
    }
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('➕ إضافة منتج جديد', 'add_new_product')],
      [Markup.button.callback('📝 إدارة المنتجات الموجودة', 'manage_existing_products')],
      [Markup.button.callback('🏷️ إدارة الأصناف الرئيسية', 'manage_main_categories')],
      [Markup.button.callback('← رجوع', 'back_to_main')]
    ]);
    
    // Use answerCbQuery first to avoid editMessage errors
    await ctx.answerCbQuery();
    await safeEditMessage(ctx, message, keyboard);
  } catch (error) {
    console.error('Error in products action:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء تحميل المنتجات');
  }
});

// 🚀 Simplified Add Product System
bot.action('add_new_product', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }

  const session = getAdminSession(userId);
  session.currentStep = 'simple_adding_product_name';
  session.productData = null; // Reset product data

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('❌ إلغاء', 'products')]
  ]);

  await ctx.answerCbQuery();
  await safeEditMessage(ctx, 
    '🚀 **إضافة منتج جديد - النظام المبسط**\n\n' +
    '📝 **خطوة 1/3:** أرسل اسم المنتج\n' +
    '💡 مثال: شحن شدات PUBG\n\n' +
    '👆 أكتب اسم المنتج الآن:', 
    { parse_mode: 'Markdown', ...keyboard }
  );
});

// Manage existing products
bot.action('manage_existing_products', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }

  try {
    const products = await storage.getAllProducts();
    
    let message = '📝 **إدارة المنتجات الموجودة:**\n\n';
    
    if (products.length === 0) {
      message += '📦 لا توجد منتجات حالياً.\n\n';
      message += '💡 استخدم "إضافة منتج جديد" لإنشاء منتج أول.';
    } else {
      for (const product of products) {
        const categories = await storage.getCategoriesByProduct(product.id);
        message += `📱 **${product.name}**\n`;
        message += `📝 ${product.description}\n`;
        message += `🚚 الشحن: ${product.shippingType}\n`;
        message += `💎 عدد الفئات: ${categories.length}\n\n`;
      }
    }
    
    const keyboard = [];
    
    // Add edit buttons for each product
    if (products.length > 0) {
      const productButtons = products.map(product => [
        Markup.button.callback(`✏️ تعديل ${product.name}`, `edit_product_${product.id}`)
      ]);
      keyboard.push(...productButtons);
    }
    
    keyboard.push([Markup.button.callback('🔙 رجوع للمنتجات', 'products')]);
    
    await ctx.answerCbQuery();
    await safeEditMessage(ctx, message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    });
  } catch (error) {
    console.error('Error in manage_existing_products:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء تحميل المنتجات');
  }
});

// Edit Product Handler - MISSING CRITICAL HANDLER!
bot.action(/edit_product_(\d+)/, async (ctx) => {
  console.log('🟡 EDIT PRODUCT CALLBACK TRIGGERED:', ctx.match![1]);
  const productId = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  try {
    const product = await storage.getProduct(productId);
    if (!product) {
      await ctx.answerCbQuery('❌ المنتج غير موجود');
      return;
    }
    
    const categories = await storage.getCategoriesByProduct(productId);
    
    let message = `✏️ **تعديل المنتج: ${product.name}**\n\n`;
    message += `📝 الوصف: ${product.description}\n`;
    message += `📦 نوع التوصيل: ${product.shippingType}\n`;
    message += `📅 تاريخ الإنشاء: ${new Date(product.createdAt).toLocaleDateString('ar-SA')}\n\n`;
    
    if (categories.length > 0) {
      message += `💎 **الفئات المتاحة:**\n`;
      for (const category of categories) {
        message += `• ${category.name} - ⭐ ${category.price} نجمة\n`;
      }
    } else {
      message += `⚠️ لا توجد فئات لهذا المنتج\n`;
    }
    message += `\n💡 اختر ما تريد فعله:`;
    
    const keyboard = [];
    
    // Action buttons
    keyboard.push([
      Markup.button.callback(`💎 إضافة فئة جديدة`, `add_category_to_${productId}`)
    ]);
    
    if (categories.length > 0) {
      keyboard.push([
        Markup.button.callback(`📋 إدارة الفئات الموجودة`, `manage_categories_for_${productId}`)
      ]);
    }
    
    keyboard.push([
      Markup.button.callback(`🗑️ حذف المنتج`, `delete_product_${productId}`)
    ]);
    
    keyboard.push([
      Markup.button.callback('🔙 رجوع للمنتجات', 'manage_existing_products'),
      Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')
    ]);
    
    await ctx.answerCbQuery('تحميل تفاصيل المنتج...');
    await safeEditMessage(ctx, message, Markup.inlineKeyboard(keyboard));
    
  } catch (error) {
    console.error('Error in edit_product_:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء تحميل بيانات المنتج');
  }
});

// Delete Product Handler
bot.action(/delete_product_(\d+)/, async (ctx) => {
  console.log('🗑️ DELETE PRODUCT CALLBACK TRIGGERED:', ctx.match![1]);
  const productId = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  try {
    const product = await storage.getProduct(productId);
    if (!product) {
      await ctx.answerCbQuery('❌ المنتج غير موجود');
      return;
    }
    
    const categories = await storage.getCategoriesByProduct(productId);
    
    let message = `🗑️ **تأكيد حذف المنتج**\n\n`;
    message += `📱 المنتج: ${product.name}\n`;
    message += `📝 الوصف: ${product.description}\n`;
    if (categories.length > 0) {
      message += `💎 عدد الفئات: ${categories.length}\n`;
    }
    message += `\n⚠️ **تحذير:** سيتم حذف المنتج وجميع فئاته نهائياً!\n`;
    message += `هذا الإجراء لا يمكن التراجع عنه.\n\n`;
    message += `هل أنت متأكد من الحذف؟`;
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('✅ نعم، احذف المنتج', `confirm_delete_product_${productId}`)],
      [Markup.button.callback('❌ إلغاء', `edit_product_${productId}`)]
    ]);
    
    await ctx.answerCbQuery();
    await safeEditMessage(ctx, message, keyboard);
    
  } catch (error) {
    console.error('Error in delete_product_:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء تحميل بيانات المنتج');
  }
});

// Confirm Delete Product Handler
bot.action(/confirm_delete_product_(\d+)/, async (ctx) => {
  const productId = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  try {
    const product = await storage.getProduct(productId);
    if (!product) {
      await ctx.answerCbQuery('❌ المنتج غير موجود');
      return;
    }
    
    // Delete product (this should also delete related categories)
    const success = await storage.deleteProduct(productId);
    
    if (success) {
      let message = `✅ **تم حذف المنتج بنجاح!**\n\n`;
      message += `📱 المنتج المحذوف: ${product.name}\n`;
      message += `🗑️ تم حذف المنتج وجميع فئاته المرتبطة`;
      
      const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('📋 عرض جميع المنتجات', 'manage_existing_products')],
        [Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')]
      ]);
      
      await ctx.answerCbQuery('تم الحذف بنجاح');
      await safeEditMessage(ctx, message, keyboard);
    } else {
      await ctx.answerCbQuery('❌ فشل في حذف المنتج');
    }
    
  } catch (error) {
    console.error('Error in confirm_delete_product_:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء حذف المنتج');
  }
});

// Manage Categories for Product Handler
bot.action(/manage_categories_for_(\d+)/, async (ctx) => {
  console.log('📋 MANAGE CATEGORIES CALLBACK TRIGGERED:', ctx.match![1]);
  const productId = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  try {
    const product = await storage.getProduct(productId);
    if (!product) {
      await ctx.answerCbQuery('❌ المنتج غير موجود');
      return;
    }
    
    const categories = await storage.getCategoriesByProduct(productId);
    
    let message = `📋 **إدارة فئات: ${product.name}**\n\n`;
    
    if (categories.length === 0) {
      message += `⚠️ لا توجد فئات لهذا المنتج`;
    } else {
      message += `💎 **الفئات المتاحة:**\n`;
      for (const category of categories) {
        message += `• ${category.name} - ⭐ ${category.price} نجمة\n`;
      }
    }
    
    message += `\n💡 اختر الفئة التي تريد تعديلها:`;
    
    const keyboard = [];
    
    // Add edit buttons for each category
    if (categories.length > 0) {
      const categoryButtons = categories.map(category => [
        Markup.button.callback(`✏️ ${category.name}`, `edit_category_${category.id}`)
      ]);
      keyboard.push(...categoryButtons);
    }
    
    keyboard.push([
      Markup.button.callback('💎 إضافة فئة جديدة', `add_category_to_${productId}`)
    ]);
    
    keyboard.push([
      Markup.button.callback('🔙 رجوع للمنتج', `edit_product_${productId}`),
      Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')
    ]);
    
    await ctx.answerCbQuery();
    await safeEditMessage(ctx, message, Markup.inlineKeyboard(keyboard));
    
  } catch (error) {
    console.error('Error in manage_categories_for_:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء تحميل الفئات');
  }
});

// Edit Category Handler
bot.action(/edit_category_(\d+)/, async (ctx) => {
  console.log('💎 EDIT CATEGORY CALLBACK TRIGGERED:', ctx.match![1]);
  const categoryId = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  try {
    const category = await storage.getCategory(categoryId);
    if (!category) {
      await ctx.answerCbQuery('❌ الفئة غير موجودة');
      return;
    }
    
    const product = await storage.getProduct(category.productId);
    
    let message = `💎 **تعديل الفئة: ${category.name}**\n\n`;
    message += `📱 المنتج: ${product?.name || 'منتج محذوف'}\n`;
    message += `💎 اسم الفئة: ${category.name}\n`;
    message += `💰 السعر الحالي: ⭐ ${category.price} نجمة\n`;
    message += `📅 تاريخ الإنشاء: ${new Date(category.createdAt).toLocaleDateString('ar-SA')}\n\n`;
    message += `💡 اختر ما تريد تعديله:`;
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('📝 تغيير اسم الفئة', `change_category_name_${categoryId}`)],
      [Markup.button.callback('💰 تغيير السعر', `change_category_price_${categoryId}`)],
      [Markup.button.callback('🗑️ حذف الفئة', `delete_category_${categoryId}`)],
      [Markup.button.callback('🔙 رجوع لإدارة الفئات', `manage_categories_for_${category.productId}`)],
      [Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')]
    ]);
    
    await ctx.answerCbQuery();
    await safeEditMessage(ctx, message, keyboard);
    
  } catch (error) {
    console.error('Error in edit_category_:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء تحميل بيانات الفئة');
  }
});

// Change Category Name Handler - المعالج الناقص
bot.action(/change_category_name_(\d+)/, async (ctx) => {
  console.log('📝 CHANGE CATEGORY NAME CALLBACK TRIGGERED:', ctx.match![1]);
  const categoryId = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  try {
    const category = await storage.getCategory(categoryId);
    if (!category) {
      await ctx.answerCbQuery('❌ الفئة غير موجودة');
      return;
    }
    
    const session = getAdminSession(userId);
    session.currentStep = 'changing_category_name';
    session.editingCategoryId = categoryId;
    
    let message = `📝 **تغيير اسم الفئة**\n\n`;
    message += `💎 الاسم الحالي: ${category.name}\n`;
    message += `💰 السعر: ⭐ ${category.price} نجمة\n\n`;
    message += `✏️ أدخل الاسم الجديد للفئة:`;
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('❌ إلغاء', `edit_category_${categoryId}`)]
    ]);
    
    await ctx.answerCbQuery('تغيير اسم الفئة');
    await safeEditMessage(ctx, message, { parse_mode: 'Markdown', ...keyboard });
    
  } catch (error) {
    console.error('Error in change_category_name_:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء تحميل بيانات الفئة');
  }
});

// Change Category Price Handler - المعالج الناقص
bot.action(/change_category_price_(\d+)/, async (ctx) => {
  console.log('💰 CHANGE CATEGORY PRICE CALLBACK TRIGGERED:', ctx.match![1]);
  const categoryId = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  try {
    const category = await storage.getCategory(categoryId);
    if (!category) {
      await ctx.answerCbQuery('❌ الفئة غير موجودة');
      return;
    }
    
    const session = getAdminSession(userId);
    session.currentStep = 'changing_category_price';
    session.editingCategoryId = categoryId;
    
    let message = `💰 **تغيير سعر الفئة**\n\n`;
    message += `💎 اسم الفئة: ${category.name}\n`;
    message += `💰 السعر الحالي: ⭐ ${category.price} نجمة\n\n`;
    message += `🔢 أدخل السعر الجديد بالنجوم:`;
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('❌ إلغاء', `edit_category_${categoryId}`)]
    ]);
    
    await ctx.answerCbQuery('تغيير سعر الفئة');
    await safeEditMessage(ctx, message, { parse_mode: 'Markdown', ...keyboard });
    
  } catch (error) {
    console.error('Error in change_category_price_:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء تحميل بيانات الفئة');
  }
});

// Manage main categories
bot.action('manage_main_categories', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }

  try {
    const categories = await storage.getAllProductCategories();
    
    let message = '🏷️ **إدارة الأصناف الرئيسية:**\n\n';
    
    if (categories.length === 0) {
      message += '📂 لا توجد أصناف رئيسية حالياً.\n\n';
    } else {
      categories.forEach((category, index) => {
        message += `${index + 1}. ${category.icon || '📱'} **${category.name}**\n`;
        message += `   📝 ${category.description || 'لا يوجد وصف'}\n`;
        
        // عرض عدد الفئات المرتبطة بكل صنف رئيسي
        message += `   🔢 الفئات: قيد التحميل...\n\n`;
      });
    }
    
    // إنشاء أزرار للتعديل وأزرار إضافية
    const keyboard = [];
    
    // إضافة أزرار لكل فئة للتعديل
    if (categories.length > 0) {
      const categoryButtons = categories.map(category => [
        Markup.button.callback(`✏️ ${category.name}`, `edit_main_category_${category.id}`)
      ]);
      keyboard.push(...categoryButtons);
    }
    
    // أزرار الإدارة العامة
    keyboard.push(
      [Markup.button.callback('➕ إضافة صنف رئيسي', 'add_main_category')],
      [Markup.button.callback('🔙 رجوع للمنتجات', 'products')]
    );
    
    await ctx.answerCbQuery();
    await safeEditMessage(ctx, message, { 
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    });
  } catch (error) {
    console.error('Error in manage_main_categories:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء تحميل الأصناف');
  }
});

// Add main category
bot.action('add_main_category', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }

  const session = getAdminSession(userId);
  session.currentStep = 'adding_category_name';

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('❌ إلغاء', 'manage_main_categories')]
  ]);

  await ctx.answerCbQuery();
  await safeEditMessage(ctx, '➕ إضافة صنف رئيسي جديد\n\n📝 أرسل اسم الصنف:', keyboard);
});

// Edit main category handler
bot.action(/edit_main_category_(\d+)/, async (ctx) => {
  const categoryId = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }

  try {
    const category = await storage.getProductCategory(categoryId);
    
    if (!category) {
      await ctx.answerCbQuery('❌ الفئة غير موجودة');
      return;
    }
    
    // عرض الفئات الفرعية لهذا المنتج
    const subCategories = await storage.getCategoriesByProduct(categoryId);
    
    let message = `🏷️ **إدارة: ${category.name}**\n\n`;
    message += `📝 الوصف: ${category.description || 'لا يوجد وصف'}\n`;
    message += `🎨 الأيقونة: ${category.icon || '📱'}\n\n`;
    
    if (subCategories.length > 0) {
      message += `💎 **الفئات الفرعية:**\n`;
      subCategories.forEach((subCat, index) => {
        message += `${index + 1}. ${subCat.name} - ⭐ ${subCat.price}\n`;
      });
      message += '\n';
    } else {
      message += '📦 لا توجد فئات فرعية.\n\n';
    }
    
    const keyboard = [
      [Markup.button.callback('➕ إضافة فئة فرعية', `add_subcategory_${categoryId}`)],
      [Markup.button.callback('✏️ تعديل البيانات', `edit_category_info_${categoryId}`)],
      [Markup.button.callback('🗑️ حذف الفئة', `delete_category_${categoryId}`)],
      [Markup.button.callback('🔙 رجوع للأصناف', 'manage_main_categories')]
    ];
    
    // إضافة أزرار تعديل الفئات الفرعية إذا وجدت
    if (subCategories.length > 0) {
      const subCatButtons = subCategories.map(subCat => [
        Markup.button.callback(`💰 تعديل سعر ${subCat.name}`, `edit_price_${subCat.id}`)
      ]);
      keyboard.splice(-1, 0, ...subCatButtons); // إدراج قبل زر الرجوع
    }
    
    await ctx.answerCbQuery(`تعديل ${category.name}`);
    await safeEditMessage(ctx, message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    });
  } catch (error) {
    console.error('Error in edit_main_category:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء تحميل بيانات الفئة');
  }
});

// Edit price handler
bot.action(/edit_price_(\d+)/, async (ctx) => {
  const categoryId = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }

  try {
    const category = await storage.getCategory(categoryId);
    
    if (!category) {
      await ctx.answerCbQuery('❌ الفئة غير موجودة');
      return;
    }
    
    const session = getAdminSession(userId);
    session.currentStep = 'editing_price';
    session.editingCategoryId = categoryId;
    
    const message = `💰 **تعديل سعر: ${category.name}**\n\n` +
      `💎 السعر الحالي: ⭐ ${category.price}\n\n` +
      `🔢 أدخل السعر الجديد بالنجوم:`;
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('❌ إلغاء', `edit_main_category_${category.productId}`)]
    ]);
    
    await ctx.answerCbQuery('تعديل السعر');
    await safeEditMessage(ctx, message, { parse_mode: 'Markdown', ...keyboard });
  } catch (error) {
    console.error('Error in edit_price:', error);
    await ctx.answerCbQuery('❌ حدث خطأ');
  }
});

// Delete category handler
bot.action(/delete_category_(\d+)/, async (ctx) => {
  const categoryId = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }

  try {
    const category = await storage.getProductCategory(categoryId);
    
    if (!category) {
      await ctx.answerCbQuery('❌ الفئة غير موجودة');
      return;
    }
    
    // Check if there are products in this category
    const productsInCategory = await storage.getProductsByCategory(categoryId);
    
    let confirmMessage = `🗑️ **تأكيد حذف الفئة**\n\n`;
    confirmMessage += `📂 الفئة: ${category.name}\n`;
    confirmMessage += `📝 الوصف: ${category.description || 'لا يوجد'}\n`;
    
    if (productsInCategory.length > 0) {
      confirmMessage += `\n⚠️ **تحذير**: هذه الفئة تحتوي على ${productsInCategory.length} منتجات.\n`;
      confirmMessage += `لا يمكن حذف فئة تحتوي على منتجات. يرجى حذف المنتجات أولاً.\n`;
    }
    
    confirmMessage += `\n❓ هل أنت متأكد من الحذف؟`;
    
    const keyboard = [];
    if (productsInCategory.length === 0) {
      // Only allow deletion if no products exist
      keyboard.push([Markup.button.callback('✅ نعم، احذف', `confirm_delete_${categoryId}`)]);
    }
    keyboard.push([Markup.button.callback('❌ إلغاء', `edit_main_category_${categoryId}`)]);
    
    const inlineKeyboard = Markup.inlineKeyboard(keyboard);
    
    await ctx.answerCbQuery('تأكيد حذف الفئة');
    await safeEditMessage(ctx, confirmMessage, { parse_mode: 'Markdown', ...inlineKeyboard });
  } catch (error) {
    console.error('Error in delete_category:', error);
    await ctx.answerCbQuery('❌ حدث خطأ');
  }
});

// Confirm delete category handler
bot.action(/confirm_delete_(\d+)/, async (ctx) => {
  const categoryId = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }

  try {
    const category = await storage.getProductCategory(categoryId);
    
    if (!category) {
      await ctx.answerCbQuery('❌ الفئة غير موجودة');
      return;
    }
    
    // Delete the category (this should also delete subcategories)
    const success = await storage.deleteProductCategory(categoryId);
    
    if (success) {
      await ctx.answerCbQuery('✅ تم حذف الفئة بنجاح');
      
      // Redirect to main categories
      const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🏷️ عرض الأصناف', 'manage_main_categories')],
        [Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')]
      ]);
      
      await safeEditMessage(ctx, `✅ **تم حذف الفئة بنجاح**\n\n📂 الفئة المحذوفة: ${category.name}`, {
        parse_mode: 'Markdown',
        ...keyboard
      });
    } else {
      await ctx.answerCbQuery('❌ فشل في حذف الفئة');
    }
  } catch (error) {
    console.error('Error in confirm_delete:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء الحذف');
  }
});

// Edit category info handler
bot.action(/edit_category_info_(\d+)/, async (ctx) => {
  const categoryId = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }

  try {
    const category = await storage.getProductCategory(categoryId);
    
    if (!category) {
      await ctx.answerCbQuery('❌ الفئة غير موجودة');
      return;
    }
    
    let message = `✏️ **تعديل بيانات: ${category.name}**\n\n`;
    message += `📝 الاسم الحالي: ${category.name}\n`;
    message += `📄 الوصف الحالي: ${category.description || 'لا يوجد'}\n`;
    message += `🎨 الأيقونة الحالية: ${category.icon || '📱'}\n\n`;
    message += `اختر العنصر المراد تعديله:`;
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('📝 تعديل الاسم', `edit_name_${categoryId}`)],
      [Markup.button.callback('📄 تعديل الوصف', `edit_desc_${categoryId}`)],
      [Markup.button.callback('🎨 تعديل الأيقونة', `edit_icon_${categoryId}`)],
      [Markup.button.callback('← رجوع', `edit_main_category_${categoryId}`)]
    ]);
    
    await ctx.answerCbQuery('تعديل بيانات الفئة');
    await safeEditMessage(ctx, message, { parse_mode: 'Markdown', ...keyboard });
  } catch (error) {
    console.error('Error in edit_category_info:', error);
    await ctx.answerCbQuery('❌ حدث خطأ');
  }
});

// Edit category name handler
bot.action(/edit_name_(\d+)/, async (ctx) => {
  const categoryId = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }

  try {
    const category = await storage.getProductCategory(categoryId);
    
    if (!category) {
      await ctx.answerCbQuery('❌ الفئة غير موجودة');
      return;
    }
    
    const session = getAdminSession(userId);
    session.currentStep = 'editing_category_name';
    session.editingCategoryId = categoryId;
    
    const message = `📝 **تعديل اسم الفئة**\n\n` +
      `📂 الفئة: ${category.name}\n` +
      `📝 الاسم الحالي: ${category.name}\n\n` +
      `✍️ أدخل الاسم الجديد:`;
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('❌ إلغاء', `edit_category_info_${categoryId}`)]
    ]);
    
    await ctx.answerCbQuery('تعديل اسم الفئة');
    await safeEditMessage(ctx, message, { parse_mode: 'Markdown', ...keyboard });
  } catch (error) {
    console.error('Error in edit_name:', error);
    await ctx.answerCbQuery('❌ حدث خطأ');
  }
});

// Edit category description handler
bot.action(/edit_desc_(\d+)/, async (ctx) => {
  const categoryId = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }

  try {
    const category = await storage.getProductCategory(categoryId);
    
    if (!category) {
      await ctx.answerCbQuery('❌ الفئة غير موجودة');
      return;
    }
    
    const session = getAdminSession(userId);
    session.currentStep = 'editing_category_description';
    session.editingCategoryId = categoryId;
    
    const message = `📄 **تعديل وصف الفئة**\n\n` +
      `📂 الفئة: ${category.name}\n` +
      `📄 الوصف الحالي: ${category.description || 'لا يوجد'}\n\n` +
      `✍️ أدخل الوصف الجديد:`;
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('❌ إلغاء', `edit_category_info_${categoryId}`)]
    ]);
    
    await ctx.answerCbQuery('تعديل وصف الفئة');
    await safeEditMessage(ctx, message, { parse_mode: 'Markdown', ...keyboard });
  } catch (error) {
    console.error('Error in edit_desc:', error);
    await ctx.answerCbQuery('❌ حدث خطأ');
  }
});

// Edit category icon handler
bot.action(/edit_icon_(\d+)/, async (ctx) => {
  const categoryId = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }

  try {
    const category = await storage.getProductCategory(categoryId);
    
    if (!category) {
      await ctx.answerCbQuery('❌ الفئة غير موجودة');
      return;
    }
    
    const session = getAdminSession(userId);
    session.currentStep = 'editing_category_icon';
    session.editingCategoryId = categoryId;
    
    const message = `🎨 **تعديل أيقونة الفئة**\n\n` +
      `📂 الفئة: ${category.name}\n` +
      `🎨 الأيقونة الحالية: ${category.icon || '📱'}\n\n` +
      `✍️ أدخل الأيقونة الجديدة (رمز تعبيري):`;
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('❌ إلغاء', `edit_category_info_${categoryId}`)]
    ]);
    
    await ctx.answerCbQuery('تعديل أيقونة الفئة');
    await safeEditMessage(ctx, message, { parse_mode: 'Markdown', ...keyboard });
  } catch (error) {
    console.error('Error in edit_icon:', error);
    await ctx.answerCbQuery('❌ حدث خطأ');
  }
});

// Add subcategory handler
bot.action(/add_subcategory_(\d+)/, async (ctx) => {
  const productId = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }

  try {
    const product = await storage.getProduct(productId);
    
    if (!product) {
      await ctx.answerCbQuery('❌ المنتج غير موجود');
      return;
    }
    
    const session = getAdminSession(userId);
    session.currentStep = 'adding_subcategory_name';
    session.parentProductId = productId;
    
    const message = `➕ **إضافة فئة فرعية لـ: ${product.name}**\n\n` +
      `📝 أرسل اسم الفئة الفرعية:\n` +
      `💡 مثال: "60 شدة"، "300 شدة"، "باقة مميزة"`;
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('❌ إلغاء', `edit_main_category_${productId}`)]
    ]);
    
    await ctx.answerCbQuery('إضافة فئة فرعية');
    await safeEditMessage(ctx, message, { parse_mode: 'Markdown', ...keyboard });
  } catch (error) {
    console.error('Error in add_subcategory:', error);
    await ctx.answerCbQuery('❌ حدث خطأ');
  }
});

// Users management
bot.action('users', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  await ctx.answerCbQuery('جاري تحميل بيانات المستخدمين...');
  
  const users = await storage.getAllUsers();
  
  let message = '👥 آخر المستخدمين:\n\n';
  
  for (const user of users.slice(0, 10)) {
    message += `👤 @${user.username}\n`;
    message += `💰 الرصيد: ⭐ ${user.balance}\n`;
    message += `📅 آخر نشاط: ${new Date(user.lastActive).toLocaleDateString('ar-EG')}\n\n`;
  }
  
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('🔍 البحث عن مستخدم', 'search_user')],
    [Markup.button.callback('← رجوع', 'back_to_main')]
  ]);
  
  await safeEditMessage(ctx, message, keyboard);
});

// Search User Handler - المعالج الناقص
bot.action('search_user', async (ctx) => {
  console.log('🔍 SEARCH USER CALLBACK TRIGGERED');
  const userId = ctx.from?.id;
  
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  try {
    const session = getAdminSession(userId);
    session.currentStep = 'searching_user';
    
    let message = `🔍 **البحث عن مستخدم**\n\n`;
    message += `📝 أدخل أحد المعايير التالية للبحث:\n\n`;
    message += `🆔 معرف المستخدم (User ID)\n`;
    message += `👤 اسم المستخدم (Username)\n`;
    message += `📧 رقم الهاتف\n\n`;
    message += `💡 مثال: 123456789 أو @username`;
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('❌ إلغاء', 'users')]
    ]);
    
    await ctx.answerCbQuery('البحث عن مستخدم');
    await safeEditMessage(ctx, message, { parse_mode: 'Markdown', ...keyboard });
    
  } catch (error) {
    console.error('Error in search_user:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء فتح نافذة البحث');
  }
});

// Topup requests management
bot.action('topup_requests', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) return;

  try {
    const pendingRequests = await storage.getBalanceTopupRequestsByStatus('pending');
    
    let message = '💳 **طلبات الشحن المعلقة:**\n\n';
    
    if (pendingRequests.length === 0) {
      message += '✅ لا توجد طلبات شحن معلقة حالياً.';
    } else {
      message += `📊 عدد الطلبات المعلقة: ${pendingRequests.length}\n\n`;
      
      // Show first 5 requests
      const displayRequests = pendingRequests.slice(0, 5);
      
      for (const request of displayRequests) {
        const user = await storage.getUser(request.userId);
        const username = user?.username || `المستخدم ${request.userId}`;
        const date = new Date(request.createdAt).toLocaleDateString('ar-SA');
        
        message += `🆔 طلب #${request.id}\n`;
        message += `👤 ${username}\n`;
        message += `💰 ${request.amount} ج.م\n`;
        message += `📅 ${date}\n`;
        message += `💳 ${request.paymentMethod}\n\n`;
      }
      
      if (pendingRequests.length > 5) {
        message += `... و ${pendingRequests.length - 5} طلبات أخرى`;
      }
    }
    
    const keyboard = [];
    
    // Show approve buttons for first 3 requests
    if (pendingRequests.length > 0) {
      const reviewRequests = pendingRequests.slice(0, 3);
      reviewRequests.forEach(request => {
        keyboard.push([
          Markup.button.callback(`✅ موافقة #${request.id}`, `approve_topup_${request.id}`),
          Markup.button.callback(`❌ رفض #${request.id}`, `reject_topup_${request.id}`)
        ]);
      });
      
      keyboard.push([Markup.button.callback('🔄 تحديث القائمة', 'topup_requests')]);
    }
    
    keyboard.push([Markup.button.callback('← رجوع', 'back_to_main')]);
    
    await safeEditMessage(ctx, message, Markup.inlineKeyboard(keyboard));
  } catch (error) {
    console.error('Error fetching topup requests:', error);
    await safeEditMessage(ctx, '❌ حدث خطأ أثناء جلب طلبات الشحن.', 
      Markup.inlineKeyboard([[Markup.button.callback('← رجوع', 'back_to_main')]]));
  }
});

// Approve topup request
bot.action(/approve_topup_(\d+)/, async (ctx) => {
  const requestId = parseInt(ctx.match![1]);
  const adminId = ctx.from?.id;
  
  if (!adminId || !isAdmin(adminId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  try {
    await ctx.answerCbQuery('جاري معالجة الموافقة...');
    
    const result = await storage.approveBalanceTopupRequest(requestId, adminId);
    
    if (result.success) {
      await safeEditMessage(ctx, 
        `✅ تم الموافقة على طلب الشحن #${requestId} بنجاح!\n\n🎉 تم إضافة الرصيد للمستخدم.\n💳 رقم المعاملة: #${result.transaction?.id}`,
        Markup.inlineKeyboard([
          [Markup.button.callback('💳 طلبات الشحن', 'topup_requests')],
          [Markup.button.callback('← رجوع', 'back_to_main')]
        ])
      );
    } else {
      await safeEditMessage(ctx, 
        `❌ فشل في الموافقة على الطلب:\n${result.error}`,
        Markup.inlineKeyboard([
          [Markup.button.callback('💳 طلبات الشحن', 'topup_requests')],
          [Markup.button.callback('← رجوع', 'back_to_main')]
        ])
      );
    }
  } catch (error) {
    console.error('Error approving topup request:', error);
    await safeEditMessage(ctx, 
      '❌ حدث خطأ أثناء معالجة الموافقة.',
      Markup.inlineKeyboard([[Markup.button.callback('← رجوع', 'back_to_main')]])
    );
  }
});

// Reject topup request
bot.action(/reject_topup_(\d+)/, async (ctx) => {
  const requestId = parseInt(ctx.match![1]);
  const adminId = ctx.from?.id;
  
  if (!adminId || !isAdmin(adminId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  try {
    await ctx.answerCbQuery('جاري معالجة الرفض...');
    
    const result = await storage.rejectBalanceTopupRequest(requestId, adminId, 'تم الرفض من قبل الإدارة');
    
    if (result.success) {
      await safeEditMessage(ctx, 
        `❌ تم رفض طلب الشحن #${requestId}.\n\n📝 السبب: تم الرفض من قبل الإدارة`,
        Markup.inlineKeyboard([
          [Markup.button.callback('💳 طلبات الشحن', 'topup_requests')],
          [Markup.button.callback('← رجوع', 'back_to_main')]
        ])
      );
    } else {
      await safeEditMessage(ctx, 
        `❌ فشل في رفض الطلب:\n${result.error}`,
        Markup.inlineKeyboard([
          [Markup.button.callback('💳 طلبات الشحن', 'topup_requests')],
          [Markup.button.callback('← رجوع', 'back_to_main')]
        ])
      );
    }
  } catch (error) {
    console.error('Error rejecting topup request:', error);
    await safeEditMessage(ctx, 
      '❌ حدث خطأ أثناء معالجة الرفض.',
      Markup.inlineKeyboard([[Markup.button.callback('← رجوع', 'back_to_main')]])
    );
  }
});

// Balance management
bot.action('balance', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }

  try {
    const users = await storage.getAllUsers();
    const totalBalance = users.reduce((sum, user) => sum + (user.balance || 0), 0);
    
    let message = '💰 إدارة الأرصدة:\n\n';
    message += `💎 إجمالي أرصدة المستخدمين: ${totalBalance} ج.م\n`;
    message += `👥 عدد المستخدمين: ${users.length}\n\n`;
    
    // Show top 5 users by balance
    const topUsers = users
      .filter(user => (user.balance || 0) > 0)
      .sort((a, b) => (b.balance || 0) - (a.balance || 0))
      .slice(0, 5);
    
    if (topUsers.length > 0) {
      message += '🏆 أعلى الأرصدة:\n';
      topUsers.forEach((user, index) => {
        message += `${index + 1}. ${user.username || `مستخدم ${user.id}`}: ${user.balance || 0} ج.م\n`;
      });
    }
    
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('➕ إضافة رصيد لمستخدم', 'add_user_balance')],
      [Markup.button.callback('📊 إحصائيات تفصيلية', 'detailed_balance_stats')],
      [Markup.button.callback('← رجوع', 'back_to_main')]
    ]);
    
    await ctx.answerCbQuery();
    await safeEditMessage(ctx, message, keyboard);
  } catch (error) {
    console.error('Error in balance action:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء تحميل بيانات الأرصدة');
  }
});

// Settings management
bot.action('settings', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }

  const message = '⚙️ إعدادات النظام:\n\n' +
    '🔧 الإعدادات الحالية:\n' +
    `• معرف الإدارة: ${BOT_CONFIG.ADMIN_IDS.join(', ')}\n` +
    `• حالة البوتات: متصل\n` +
    `• قاعدة البيانات: متصلة\n\n` +
    '📋 الإعدادات المتاحة:';
  
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('📝 تعديل رسائل البوت', 'edit_bot_messages')],
    [Markup.button.callback('🔄 إعادة تشغيل النظام', 'restart_system')],
    [Markup.button.callback('📊 إحصائيات النظام', 'system_stats')],
    [Markup.button.callback('← رجوع', 'back_to_main')]
  ]);
  
  await ctx.answerCbQuery();
  await safeEditMessage(ctx, message, keyboard);
});

// Removed first text handler - will be merged with unified handler below

// Helper function to save category data
async function saveCategoryData(ctx: any, session: any) {
  try {
    const categoryData = {
      name: session.categoryData.name,
      description: session.categoryData.description || null,
      icon: session.categoryData.icon || '📱'
    };

    await storage.createProductCategory(categoryData);
    
    session.currentStep = 'main';
    session.categoryData = null;
    
    await ctx.reply('✅ تم إضافة الصنف الرئيسي بنجاح!', 
      Markup.inlineKeyboard([
        [Markup.button.callback('🏷️ عرض الأصناف', 'manage_main_categories')],
        [Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')]
      ])
    );
  } catch (error) {
    console.error('Error saving category:', error);
    await ctx.reply('❌ حدث خطأ أثناء إضافة الصنف.');
  }
}

// Skip category description
bot.action('skip_category_description', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) return;

  const session = getAdminSession(userId);
  session.categoryData.description = null;
  session.currentStep = 'adding_category_icon';
  
  await ctx.answerCbQuery();
  await safeEditMessage(ctx, '🎨 أرسل الأيقونة (رمز تعبيري) أو اكتب "تخطي":', 
    Markup.inlineKeyboard([
      [Markup.button.callback('⏭️ تخطي الأيقونة', 'skip_category_icon')],
      [Markup.button.callback('❌ إلغاء', 'manage_main_categories')]
    ])
  );
});

// Skip category icon
bot.action('skip_category_icon', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) return;

  const session = getAdminSession(userId);
  session.categoryData.icon = '📱';
  
  await ctx.answerCbQuery();
  await saveCategoryData(ctx, session);
});

// Skip subcategory description handler
bot.action('skip_subcategory_description', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) return;
  
  const session = getAdminSession(userId);
  session.subcategoryData.description = `فئة ${session.subcategoryData.name}`;
  session.currentStep = 'adding_subcategory_price';
  
  await ctx.answerCbQuery();
  await safeEditMessage(ctx, '💰 أرسل سعر الفئة بالنجوم:', 
    Markup.inlineKeyboard([
      [Markup.button.callback('❌ إلغاء', `edit_main_category_${session.parentProductId}`)]
    ])
  );
});

// Shipping type handlers
// 🚀 Simplified shipping handlers (keeping old ones for compatibility)
bot.action('shipping_id', async (ctx) => {
  await handleShippingTypeSelection(ctx, 'id');
});

bot.action('shipping_email', async (ctx) => {
  await handleShippingTypeSelection(ctx, 'email');
});

bot.action('shipping_phone', async (ctx) => {
  await handleShippingTypeSelection(ctx, 'phone');
});

// New simplified shipping handlers
bot.action('simple_shipping_id', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) return;

  const session = getAdminSession(userId);
  session.productData.shippingType = 'user_id';
  
  await createSimplifiedProduct(ctx, session);
});

bot.action('simple_shipping_email', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) return;

  const session = getAdminSession(userId);
  session.productData.shippingType = 'email';
  
  await createSimplifiedProduct(ctx, session);
});

bot.action('simple_shipping_phone', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) return;

  const session = getAdminSession(userId);
  session.productData.shippingType = 'phone';
  
  await createSimplifiedProduct(ctx, session);
});

async function handleShippingTypeSelection(ctx: any, shippingType: string) {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) return;

  try {
    const session = getAdminSession(userId);
    session.productData.shippingType = shippingType;

    // Select main category for the product
    const categories = await storage.getAllProductCategories();
    
    if (categories.length === 0) {
      await ctx.answerCbQuery();
      await safeEditMessage(ctx, '❌ لا توجد أصناف رئيسية.\n\nيجب إنشاء صنف رئيسي أولاً.', 
        Markup.inlineKeyboard([
          [Markup.button.callback('➕ إضافة صنف رئيسي', 'add_main_category')],
          [Markup.button.callback('❌ إلغاء', 'cancel_action')]
        ])
      );
      return;
    }

    const keyboard = categories.map(category => [
      Markup.button.callback(`${category.icon || '📱'} ${category.name}`, `select_category_${category.id}`)
    ]);
    keyboard.push([Markup.button.callback('❌ إلغاء', 'cancel_action')]);

    await ctx.answerCbQuery();
    await safeEditMessage(ctx, '🏷️ اختر الصنف الرئيسي للمنتج:', Markup.inlineKeyboard(keyboard));
  } catch (error) {
    console.error('Error in handleShippingTypeSelection:', error);
    await ctx.answerCbQuery('❌ حدث خطأ');
  }
}

// Handle category selection for product
bot.action(/select_category_(\d+)/, async (ctx) => {
  const categoryId = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) return;

  try {
    const session = getAdminSession(userId);
    
    // Create the product
    const productData = {
      name: session.productData.name,
      description: session.productData.description,
      shippingType: session.productData.shippingType,
      categoryId: categoryId
    };

    await storage.createProduct(productData);
    
    session.currentStep = 'main';
    session.productData = null;
    
    await ctx.answerCbQuery();
    await safeEditMessage(ctx, '✅ تم إضافة المنتج بنجاح!', 
      Markup.inlineKeyboard([
        [Markup.button.callback('🛍️ عرض المنتجات', 'products')],
        [Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')]
      ])
    );
  } catch (error) {
    console.error('Error creating product:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء إضافة المنتج');
  }
});

// Back to main menu
bot.action('back_to_main', async (ctx) => {
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('📊 الإحصائيات', 'stats')],
    [Markup.button.callback('💳 طلبات الشحن', 'topup_requests')],
    [Markup.button.callback('🛍️ المنتجات', 'products')],
    [Markup.button.callback('👥 المستخدمين', 'users')],
    [Markup.button.callback('💰 الرصيد', 'balance')],
    [Markup.button.callback('⚙️ الإعدادات', 'settings')],
  ]);
  
  await safeEditMessage(ctx, '👨‍💼 لوحة تحكم الإدارة', keyboard);
});

// Cancel action - Enhanced
bot.action('cancel_action', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) return;

  const session = getAdminSession(userId);
  
  // Reset session state
  session.currentStep = 'main';
  session.productData = null;
  session.categoryData = null;
  
  await ctx.answerCbQuery('❌ تم إلغاء العملية');

  // Return to main menu
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('📊 الإحصائيات', 'stats')],
    [Markup.button.callback('💳 طلبات الشحن', 'topup_requests')],
    [Markup.button.callback('🛍️ المنتجات', 'products')],
    [Markup.button.callback('👥 المستخدمين', 'users')],
    [Markup.button.callback('💰 الرصيد', 'balance')],
    [Markup.button.callback('⚙️ الإعدادات', 'settings')],
  ]);
  
  await safeEditMessage(ctx, '👨‍💼 لوحة تحكم الإدارة', keyboard);
});

// More balance actions
bot.action('add_user_balance', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }

  const session = getAdminSession(userId);
  session.currentStep = 'adding_balance_user_id';

  await ctx.answerCbQuery();
  await safeEditMessage(ctx, '➕ إضافة رصيد لمستخدم\n\n🆔 أرسل معرف المستخدم:', 
    Markup.inlineKeyboard([
      [Markup.button.callback('❌ إلغاء', 'balance')]
    ])
  );
});

bot.action('detailed_balance_stats', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }

  try {
    const users = await storage.getAllUsers();
    // Get sample transactions from first user for stats
    let transactions: any[] = [];
    if (users.length > 0) {
      transactions = await storage.getUserBalanceHistory(users[0].id);
    }
    
    const totalBalance = users.reduce((sum, user) => sum + (user.balance || 0), 0);
    const totalTransactions = transactions.length;
    const totalDeposits = transactions
      .filter((t: any) => t.type === 'deposit')
      .reduce((sum: number, t: any) => sum + t.amount, 0);
    const totalPurchases = transactions
      .filter((t: any) => t.type === 'purchase')
      .reduce((sum: number, t: any) => sum + Math.abs(t.amount), 0);
    
    const message = '📊 إحصائيات الأرصدة التفصيلية:\n\n' +
      `💰 إجمالي الأرصدة: ${totalBalance} ج.م\n` +
      `📈 إجمالي الإيداعات: ${totalDeposits} ج.م\n` +
      `📉 إجمالي المشتريات: ${totalPurchases} ج.م\n` +
      `🔄 عدد المعاملات: ${totalTransactions}\n` +
      `👥 المستخدمين النشطين: ${users.filter(u => (u.balance || 0) > 0).length}`;
    
    await ctx.answerCbQuery();
    await safeEditMessage(ctx, message, 
      Markup.inlineKeyboard([
        [Markup.button.callback('🔙 رجوع لإدارة الرصيد', 'balance')]
      ])
    );
  } catch (error) {
    console.error('Error in detailed_balance_stats:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء تحميل الإحصائيات');
  }
});

// Settings actions
bot.action('edit_bot_messages', async (ctx) => {
  await ctx.answerCbQuery();
  await safeEditMessage(ctx, '📝 تعديل رسائل البوت\n\n🚧 هذه الميزة قيد التطوير...', 
    Markup.inlineKeyboard([
      [Markup.button.callback('🔙 رجوع للإعدادات', 'settings')]
    ])
  );
});

bot.action('restart_system', async (ctx) => {
  await ctx.answerCbQuery();
  await safeEditMessage(ctx, '🔄 إعادة تشغيل النظام\n\n⚠️ هذه العملية ستؤثر على جميع المستخدمين.\n\n🚧 الميزة قيد التطوير...', 
    Markup.inlineKeyboard([
      [Markup.button.callback('🔙 رجوع للإعدادات', 'settings')]
    ])
  );
});

bot.action('system_stats', async (ctx) => {
  try {
    const users = await storage.getAllUsers();
    const products = await storage.getAllProducts();
    const categories = await storage.getAllProductCategories();
    
    const message = '📊 إحصائيات النظام:\n\n' +
      `👥 المستخدمين: ${users.length}\n` +
      `🛍️ المنتجات: ${products.length}\n` +
      `🏷️ الأصناف الرئيسية: ${categories.length}\n` +
      `💾 حالة قاعدة البيانات: متصلة\n` +
      `🤖 حالة البوتات: يعمل`;
    
    await ctx.answerCbQuery();
    await safeEditMessage(ctx, message, 
      Markup.inlineKeyboard([
        [Markup.button.callback('🔙 رجوع للإعدادات', 'settings')]
      ])
    );
  } catch (error) {
    console.error('Error in system_stats:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء تحميل إحصائيات النظام');
  }
});

// Quick approve/reject handlers for topup requests
bot.action(/quick_approve_(\d+)/, async (ctx) => {
  const requestId = parseInt(ctx.match![1]);
  const adminId = ctx.from?.id;
  
  if (!adminId || !isAdmin(adminId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  try {
    await ctx.answerCbQuery('جاري معالجة الموافقة السريعة...');
    
    const result = await storage.approveBalanceTopupRequest(requestId, adminId);
    
    if (result.success) {
      const currentMessage = (ctx.callbackQuery?.message as any)?.text || 'الطلب';
      const updatedMessage = currentMessage + 
        `\n\n✅ **تمت الموافقة على الطلب**\n👨‍💼 بواسطة: الإدارة\n⏰ في: ${new Date().toLocaleString('ar-SA')}`;
      
      await safeEditMessage(ctx, updatedMessage, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '💳 إدارة طلبات الشحن', callback_data: 'topup_requests' }],
            [{ text: '🏠 القائمة الرئيسية', callback_data: 'back_to_main' }]
          ]
        }
      });
      
      // Notify user about approval (optional enhancement)
      // Could send success message to user here
      
    } else {
      const currentMessage = (ctx.callbackQuery?.message as any)?.text || 'الطلب';
      await safeEditMessage(ctx, currentMessage + 
        `\n\n❌ **فشل في الموافقة**: ${result.error}`, {
        parse_mode: 'Markdown'
      });
    }
  } catch (error) {
    console.error('Error in quick approve:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء المعالجة');
  }
});

bot.action(/quick_reject_(\d+)/, async (ctx) => {
  const requestId = parseInt(ctx.match![1]);
  const adminId = ctx.from?.id;
  
  if (!adminId || !isAdmin(adminId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }
  
  try {
    await ctx.answerCbQuery('جاري معالجة الرفض...');
    
    const result = await storage.rejectBalanceTopupRequest(requestId, adminId, 'تم الرفض بواسطة الإدارة');
    
    if (result.success) {
      const currentMessage = (ctx.callbackQuery?.message as any)?.text || 'الطلب';
      const updatedMessage = currentMessage + 
        `\n\n❌ **تم رفض الطلب**\n👨‍💼 بواسطة: الإدارة\n⏰ في: ${new Date().toLocaleString('ar-SA')}`;
      
      await safeEditMessage(ctx, updatedMessage, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '💳 إدارة طلبات الشحن', callback_data: 'topup_requests' }],
            [{ text: '🏠 القائمة الرئيسية', callback_data: 'back_to_main' }]
          ]
        }
      });
    } else {
      const currentMessage = (ctx.callbackQuery?.message as any)?.text || 'الطلب';
      await safeEditMessage(ctx, currentMessage + 
        `\n\n❌ **فشل في الرفض**: ${result.error}`, {
        parse_mode: 'Markdown'
      });
    }
  } catch (error) {
    console.error('Error in quick reject:', error);
    await ctx.answerCbQuery('❌ حدث خطأ أثناء المعالجة');
  }
});

// 🔧 Unified text message handler for all admin operations
bot.on('text', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId || !isAdmin(userId)) return;

  const session = getAdminSession(userId);
  const text = ctx.message.text;

  try {

    // === BALANCE MANAGEMENT ===
    // Handle adding balance - get user ID
    if (session.currentStep === 'adding_balance_user_id') {
      const targetUserId = parseInt(text);
      if (isNaN(targetUserId)) {
        await ctx.reply('❌ معرف المستخدم غير صحيح. أرسل رقم صحيح.');
        return;
      }

      const targetUser = await storage.getUser(targetUserId);
      if (!targetUser) {
        await ctx.reply('❌ المستخدم غير موجود.');
        return;
      }

      session.balanceData = { userId: targetUserId, username: targetUser.username };
      session.currentStep = 'adding_balance_amount';
      
      await ctx.reply(`✅ المستخدم: ${targetUser.username || targetUserId}\n💰 الرصيد الحالي: ${targetUser.balance || 0} ج.م\n\n💵 أرسل المبلغ المراد إضافته:`);
      return;
    }

    // Handle adding balance - get amount
    if (session.currentStep === 'adding_balance_amount') {
      const amount = parseFloat(text);
      if (isNaN(amount) || amount <= 0) {
        await ctx.reply('❌ المبلغ غير صحيح. أرسل رقم أكبر من صفر.');
        return;
      }

      try {
        await storage.addUserBalance(session.balanceData.userId, amount, 'إضافة من الإدارة', userId);
        
        const username = session.balanceData.username;
        
        session.currentStep = 'main';
        session.balanceData = null;
        
        await ctx.reply(`✅ تم إضافة ${amount} ج.م للمستخدم ${username || session.balanceData?.userId} بنجاح!`, 
          Markup.inlineKeyboard([
            [Markup.button.callback('💰 إدارة الرصيد', 'balance')],
            [Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')]
          ])
        );
      } catch (error) {
        console.error('Error adding balance:', error);
        await ctx.reply('❌ حدث خطأ أثناء إضافة الرصيد.');
      }
      return;
    }

    // === PRODUCT MANAGEMENT ===
    // === SIMPLIFIED PRODUCT ADDITION SYSTEM ===
    // Handle adding product name (simplified system)
    if (session.currentStep === 'simple_adding_product_name') {
      session.productData = { name: text };
      session.currentStep = 'simple_adding_product_description';
      
      await ctx.reply(
        '✅ **تم حفظ اسم المنتج!**\n\n' +
        `📱 اسم المنتج: ${text}\n\n` +
        '📝 **خطوة 2/3:** أرسل وصف المنتج\n' +
        '💡 مثال: شحن شدات لعبة PUBG Mobile بأفضل الأسعار\n\n' +
        '👆 أكتب وصف المنتج الآن:', 
        {
          parse_mode: 'Markdown',
          ...Markup.inlineKeyboard([
            [Markup.button.callback('❌ إلغاء', 'products')]
          ])
        }
      );
      return;
    }

    // Handle adding product description (simplified system)
    if (session.currentStep === 'simple_adding_product_description') {
      session.productData.description = text;
      session.currentStep = 'simple_adding_product_shipping_type';
      
      await ctx.reply(
        '✅ **تم حفظ وصف المنتج!**\n\n' +
        `📱 اسم المنتج: ${session.productData.name}\n` +
        `📝 الوصف: ${text}\n\n` +
        '🚚 **خطوة 3/3:** اختر نوع الشحن:\n' +
        '💡 كيف سيرسل العملاء بياناتهم؟', 
        {
          parse_mode: 'Markdown',
          ...Markup.inlineKeyboard([
            [Markup.button.callback('🆔 معرف المستخدم', 'simple_shipping_id')],
            [Markup.button.callback('📧 البريد الإلكتروني', 'simple_shipping_email')],
            [Markup.button.callback('📱 رقم الهاتف', 'simple_shipping_phone')],
            [Markup.button.callback('❌ إلغاء', 'products')]
          ])
        }
      );
      return;
    }

    // === CATEGORY MANAGEMENT ===
    // Handle adding category name
    if (session.currentStep === 'adding_category_name') {
      session.categoryData = { name: text };
      session.currentStep = 'adding_category_description';
      
      await ctx.reply('✅ تم حفظ اسم الصنف.\n\n📝 أرسل وصف الصنف (أو اكتب "تخطي"):', 
        Markup.inlineKeyboard([
          [Markup.button.callback('⏭️ تخطي الوصف', 'skip_category_description')],
          [Markup.button.callback('❌ إلغاء', 'manage_main_categories')]
        ])
      );
      return;
    }

    // Handle adding category description
    if (session.currentStep === 'adding_category_description') {
      session.categoryData.description = text;
      session.currentStep = 'adding_category_icon';
      
      await ctx.reply('✅ تم حفظ وصف الصنف.\n\n🎨 أرسل الأيقونة (رمز تعبيري) أو اكتب "تخطي":', 
        Markup.inlineKeyboard([
          [Markup.button.callback('⏭️ تخطي الأيقونة', 'skip_category_icon')],
          [Markup.button.callback('❌ إلغاء', 'manage_main_categories')]
        ])
      );
      return;
    }

    // Handle adding category icon
    if (session.currentStep === 'adding_category_icon') {
      session.categoryData.icon = text;
      await saveCategoryData(ctx, session);
      return;
    }

    // === PRICING MANAGEMENT ===
    // Handle editing price
    if (session.currentStep === 'editing_price') {
      const newPrice = parseInt(text);
      if (isNaN(newPrice) || newPrice <= 0) {
        await ctx.reply('❌ السعر غير صحيح. أرسل رقم أكبر من صفر.');
        return;
      }

      try {
        const categoryId = session.editingCategoryId;
        const category = await storage.getCategory(categoryId);
        
        if (!category) {
          await ctx.reply('❌ الفئة غير موجودة.');
          return;
        }

        await storage.updateCategory(categoryId, { price: newPrice });
        
        session.currentStep = 'main';
        session.editingCategoryId = null;
        
        await ctx.reply(`✅ تم تحديث سعر "${category.name}" إلى ⭐ ${newPrice} بنجاح!`, 
          Markup.inlineKeyboard([
            [Markup.button.callback('🔙 رجوع للفئة', `edit_main_category_${category.productId}`)],
            [Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')]
          ])
        );
      } catch (error) {
        console.error('Error updating price:', error);
        await ctx.reply('❌ حدث خطأ أثناء تحديث السعر.');
      }
      return;
    }

    // Handle editing category name
    if (session.currentStep === 'editing_category_name') {
      const newName = text.trim();
      if (newName.length === 0) {
        await ctx.reply('❌ اسم الفئة لا يمكن أن يكون فارغاً.');
        return;
      }

      try {
        const categoryId = session.editingCategoryId;
        const category = await storage.getProductCategory(categoryId);
        
        if (!category) {
          await ctx.reply('❌ الفئة غير موجودة.');
          return;
        }

        await storage.updateProductCategory(categoryId, { name: newName });
        
        session.currentStep = 'main';
        session.editingCategoryId = null;
        
        await ctx.reply(`✅ تم تحديث اسم الفئة من "${category.name}" إلى "${newName}" بنجاح!`, 
          Markup.inlineKeyboard([
            [Markup.button.callback('🔙 رجوع للفئة', `edit_main_category_${categoryId}`)],
            [Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')]
          ])
        );
      } catch (error) {
        console.error('Error updating category name:', error);
        await ctx.reply('❌ حدث خطأ أثناء تحديث اسم الفئة.');
      }
      return;
    }

    // Handle editing category description
    if (session.currentStep === 'editing_category_description') {
      const newDescription = text.trim();

      try {
        const categoryId = session.editingCategoryId;
        const category = await storage.getProductCategory(categoryId);
        
        if (!category) {
          await ctx.reply('❌ الفئة غير موجودة.');
          return;
        }

        await storage.updateProductCategory(categoryId, { description: newDescription });
        
        session.currentStep = 'main';
        session.editingCategoryId = null;
        
        await ctx.reply(`✅ تم تحديث وصف الفئة "${category.name}" بنجاح!`, 
          Markup.inlineKeyboard([
            [Markup.button.callback('🔙 رجوع للفئة', `edit_main_category_${categoryId}`)],
            [Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')]
          ])
        );
      } catch (error) {
        console.error('Error updating category description:', error);
        await ctx.reply('❌ حدث خطأ أثناء تحديث وصف الفئة.');
      }
      return;
    }

    // Handle editing category icon
    if (session.currentStep === 'editing_category_icon') {
      const newIcon = text.trim();
      if (newIcon.length === 0) {
        await ctx.reply('❌ الأيقونة لا يمكن أن تكون فارغة.');
        return;
      }

      try {
        const categoryId = session.editingCategoryId;
        const category = await storage.getProductCategory(categoryId);
        
        if (!category) {
          await ctx.reply('❌ الفئة غير موجودة.');
          return;
        }

        await storage.updateProductCategory(categoryId, { icon: newIcon });
        
        session.currentStep = 'main';
        session.editingCategoryId = null;
        
        await ctx.reply(`✅ تم تحديث أيقونة الفئة "${category.name}" إلى ${newIcon} بنجاح!`, 
          Markup.inlineKeyboard([
            [Markup.button.callback('🔙 رجوع للفئة', `edit_main_category_${categoryId}`)],
            [Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')]
          ])
        );
      } catch (error) {
        console.error('Error updating category icon:', error);
        await ctx.reply('❌ حدث خطأ أثناء تحديث أيقونة الفئة.');
      }
      return;
    }

    // === SIMPLIFIED CATEGORY MANAGEMENT ===
    // Handle adding simple category name
    if (session.currentStep === 'adding_simple_category_name') {
      session.categoryData = { name: text, productId: session.selectedProductId };
      session.currentStep = 'adding_simple_category_price';
      
      const product = await storage.getProduct(session.selectedProductId);
      
      await ctx.reply(
        `✅ **تم حفظ اسم الفئة!**\n\n` +
        `📱 المنتج: ${product?.name}\n` +
        `💎 الفئة: ${text}\n\n` +
        `💰 **خطوة 2/2:** أرسل سعر الفئة بالنجوم\n` +
        `💡 مثال: 1, 5, 10, 50, 100\n\n` +
        `👆 أكتب السعر بالنجوم الآن:`, 
        {
          parse_mode: 'Markdown',
          ...Markup.inlineKeyboard([
            [Markup.button.callback('❌ إلغاء', `edit_product_${session.selectedProductId}`)]
          ])
        }
      );
      return;
    }

    // Handle adding simple category price
    if (session.currentStep === 'adding_simple_category_price') {
      const price = parseInt(text);
      if (isNaN(price) || price <= 0) {
        await ctx.reply('❌ السعر غير صحيح! أرسل رقم أكبر من صفر.');
        return;
      }

      try {
        const category = await storage.createCategory({
          productId: session.selectedProductId,
          name: session.categoryData.name,
          description: `فئة ${session.categoryData.name}`,
          price: price
        });
        
        const product = await storage.getProduct(session.selectedProductId);
        
        // Reset session
        session.currentStep = 'main';
        session.categoryData = null;
        session.selectedProductId = null;
        
        const successMessage = `✅ **تم إضافة الفئة بنجاح!**\n\n` +
          `📱 المنتج: ${product?.name}\n` +
          `💎 الفئة: ${category.name}\n` +
          `💰 السعر: ⭐ ${category.price} نجمة\n` +
          `🆔 معرف الفئة: #${category.id}\n\n` +
          `🎉 المنتج جاهز للبيع!`;
        
        await ctx.reply(successMessage, {
          parse_mode: 'Markdown',
          ...Markup.inlineKeyboard([
            [Markup.button.callback(`💎 إضافة فئة أخرى لـ ${product?.name}`, `add_category_to_${session.selectedProductId}`)],
            [Markup.button.callback('📋 عرض جميع المنتجات', 'manage_existing_products')],
            [Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')]
          ])
        });
      } catch (error) {
        console.error('Error creating simple category:', error);
        await ctx.reply('❌ حدث خطأ أثناء إضافة الفئة.');
      }
      return;
    }

    // === NEW HANDLERS FOR FIXED BUTTONS ===
    
    // Handle changing category name
    if (session.currentStep === 'changing_category_name') {
      const newName = text.trim();
      if (newName.length === 0) {
        await ctx.reply('❌ اسم الفئة لا يمكن أن يكون فارغاً.');
        return;
      }

      try {
        const categoryId = session.editingCategoryId;
        const result = await storage.updateCategory(categoryId, { name: newName });
        
        if (result) {
          session.currentStep = 'main';
          session.editingCategoryId = null;
          
          await ctx.reply(
            `✅ **تم تحديث اسم الفئة بنجاح!**\n\n` +
            `💎 الاسم الجديد: ${newName}\n\n` +
            `🎉 تم حفظ التغييرات`,
            {
              parse_mode: 'Markdown',
              ...Markup.inlineKeyboard([
                [Markup.button.callback('💎 عرض الفئة', `edit_category_${categoryId}`)],
                [Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')]
              ])
            }
          );
        } else {
          await ctx.reply('❌ فشل في تحديث اسم الفئة. حاول مرة أخرى.');
        }
      } catch (error) {
        console.error('Error updating category name:', error);
        await ctx.reply('❌ حدث خطأ أثناء تحديث اسم الفئة.');
      }
      return;
    }

    // Handle changing category price
    if (session.currentStep === 'changing_category_price') {
      const newPrice = parseInt(text);
      if (isNaN(newPrice) || newPrice <= 0) {
        await ctx.reply('❌ السعر غير صحيح. أرسل رقم أكبر من صفر.');
        return;
      }

      try {
        const categoryId = session.editingCategoryId;
        const result = await storage.updateCategory(categoryId, { price: newPrice });
        
        if (result) {
          session.currentStep = 'main';
          session.editingCategoryId = null;
          
          await ctx.reply(
            `✅ **تم تحديث سعر الفئة بنجاح!**\n\n` +
            `💰 السعر الجديد: ⭐ ${newPrice} نجمة\n\n` +
            `🎉 تم حفظ التغييرات`,
            {
              parse_mode: 'Markdown',
              ...Markup.inlineKeyboard([
                [Markup.button.callback('💎 عرض الفئة', `edit_category_${categoryId}`)],
                [Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')]
              ])
            }
          );
        } else {
          await ctx.reply('❌ فشل في تحديث سعر الفئة. حاول مرة أخرى.');
        }
      } catch (error) {
        console.error('Error updating category price:', error);
        await ctx.reply('❌ حدث خطأ أثناء تحديث سعر الفئة.');
      }
      return;
    }

    // Handle user search
    if (session.currentStep === 'searching_user') {
      const searchTerm = text.trim();
      if (searchTerm.length === 0) {
        await ctx.reply('❌ الرجاء إدخال نص للبحث.');
        return;
      }

      try {
        const users = await storage.getAllUsers();
        let foundUsers: any[] = [];

        // Search by User ID
        if (!isNaN(parseInt(searchTerm))) {
          const userId = parseInt(searchTerm);
          const userById = users.find(u => u.id === userId);
          if (userById) foundUsers.push(userById);
        }

        // Search by username (remove @ if present)
        const cleanSearchTerm = searchTerm.replace('@', '').toLowerCase();
        const usersByUsername = users.filter(u => 
          u.username && u.username.toLowerCase().includes(cleanSearchTerm)
        );
        
        // Combine results (avoid duplicates)
        foundUsers = [...foundUsers, ...usersByUsername.filter(u => !foundUsers.find(f => f.id === u.id))];

        session.currentStep = 'main';
        
        if (foundUsers.length === 0) {
          await ctx.reply(
            `🔍 **نتائج البحث**\n\n` +
            `❌ لم يتم العثور على أي مستخدم يطابق: "${searchTerm}"\n\n` +
            `💡 تأكد من صحة معرف المستخدم أو اسم المستخدم`,
            {
              parse_mode: 'Markdown',
              ...Markup.inlineKeyboard([
                [Markup.button.callback('🔍 بحث جديد', 'search_user')],
                [Markup.button.callback('👥 جميع المستخدمين', 'users')]
              ])
            }
          );
        } else {
          let message = `🔍 **نتائج البحث عن: "${searchTerm}"**\n\n`;
          message += `📊 تم العثور على ${foundUsers.length} مستخدم:\n\n`;
          
          foundUsers.slice(0, 5).forEach((user, index) => {
            message += `${index + 1}. 👤 ${user.username || `مستخدم ${user.id}`}\n`;
            message += `   🆔 المعرف: ${user.id}\n`;
            message += `   💰 الرصيد: ${user.balance || 0} ج.م\n`;
            message += `   📅 آخر نشاط: ${new Date(user.lastActive).toLocaleDateString('ar-SA')}\n\n`;
          });
          
          if (foundUsers.length > 5) {
            message += `... و ${foundUsers.length - 5} مستخدمين آخرين`;
          }
          
          await ctx.reply(message, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
              [Markup.button.callback('🔍 بحث جديد', 'search_user')],
              [Markup.button.callback('👥 جميع المستخدمين', 'users')]
            ])
          });
        }
      } catch (error) {
        console.error('Error searching users:', error);
        await ctx.reply('❌ حدث خطأ أثناء البحث عن المستخدمين.');
        session.currentStep = 'main';
      }
      return;
    }

    // Handle adding subcategory name
    if (session.currentStep === 'adding_subcategory_name') {
      const subcategoryName = text.trim();
      if (subcategoryName.length === 0) {
        await ctx.reply('❌ اسم الفئة الفرعية لا يمكن أن يكون فارغاً.');
        return;
      }

      try {
        const productId = session.parentProductId;
        const product = await storage.getProduct(productId);
        
        if (!product) {
          await ctx.reply('❌ المنتج غير موجود.');
          session.currentStep = 'main';
          return;
        }

        // Store subcategory data and move to price step
        session.subcategoryData = { 
          name: subcategoryName,
          productId: productId
        };
        session.currentStep = 'adding_subcategory_price';

        await ctx.reply(
          `✅ **تم حفظ اسم الفئة الفرعية!**\n\n` +
          `📱 المنتج: ${product.name}\n` +
          `💎 الفئة الفرعية: ${subcategoryName}\n\n` +
          `💰 **خطوة 2/2:** أرسل سعر الفئة بالنجوم\n` +
          `💡 مثال: 1, 5, 10, 50, 100\n\n` +
          `👆 أكتب السعر بالنجوم الآن:`,
          {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
              [Markup.button.callback('❌ إلغاء', `edit_product_${productId}`)]
            ])
          }
        );
      } catch (error) {
        console.error('Error handling subcategory name:', error);
        await ctx.reply('❌ حدث خطأ أثناء معالجة اسم الفئة الفرعية.');
      }
      return;
    }

    // Handle adding subcategory price
    if (session.currentStep === 'adding_subcategory_price') {
      const price = parseInt(text);
      if (isNaN(price) || price <= 0) {
        await ctx.reply('❌ السعر غير صحيح! أرسل رقم أكبر من صفر.');
        return;
      }

      try {
        const category = await storage.createCategory({
          productId: session.subcategoryData.productId,
          name: session.subcategoryData.name,
          description: `فئة ${session.subcategoryData.name}`,
          price: price
        });
        
        const product = await storage.getProduct(session.subcategoryData.productId);
        const savedProductId = session.subcategoryData.productId; // Save before reset
        
        // Reset session
        session.currentStep = 'main';
        session.subcategoryData = null;
        session.parentProductId = null;
        
        const successMessage = `✅ **تم إضافة الفئة الفرعية بنجاح!**\n\n` +
          `📱 المنتج: ${product?.name}\n` +
          `💎 الفئة الفرعية: ${category.name}\n` +
          `💰 السعر: ⭐ ${category.price} نجمة\n` +
          `🆔 معرف الفئة: #${category.id}\n\n` +
          `🎉 الفئة جاهزة للبيع!`;
        
        await ctx.reply(successMessage, {
          parse_mode: 'Markdown',
          ...Markup.inlineKeyboard([
            [Markup.button.callback(`💎 إضافة فئة أخرى لـ ${product?.name}`, `add_subcategory_${savedProductId}`)],
            [Markup.button.callback('📋 عرض جميع المنتجات', 'manage_existing_products')],
            [Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')]
          ])
        });
      } catch (error) {
        console.error('Error creating subcategory:', error);
        await ctx.reply('❌ حدث خطأ أثناء إضافة الفئة الفرعية.');
      }
      return;
    }

    // === ORDER COMPLETION & CANCELLATION ===
    // Handle completion details input
    if (session.currentStep === 'waiting_completion_details' && session.currentOrder) {
      const orderId = session.currentOrder;
      
      // Use atomic completion method for safety
      const result = await storage.completeOrderAtomic(orderId, userId, text);
      
      if (!result.success) {
        await ctx.reply(`❌ ${result.error}`);
        session.currentStep = 'main';
        session.currentOrder = null;
        return;
      }
      
      const order = result.order!;
      
      // Get user info for notification
      const user = await storage.getUser(order.userId);
      const product = await storage.getProduct(order.productId);
      const category = await storage.getCategory(order.categoryId);
      
      const username = user?.username || `المستخدم ${order.userId}`;
      const productName = product?.name || 'منتج محذوف';
      const categoryName = category?.name || 'فئة محذوفة';
      
      // Send success confirmation to admin
      let adminMessage = `✅ **تم إكمال الطلب #${orderId} بنجاح!**\n\n`;
      adminMessage += `👤 العميل: ${username}\n`;
      adminMessage += `🎮 المنتج: ${productName} - ${categoryName}\n`;
      adminMessage += `📝 التفاصيل المُرسلة:\n\`${text}\`\n\n`;
      adminMessage += `📧 تم إرسال إشعار للعميل تلقائياً`;
      
      const adminKeyboard = Markup.inlineKeyboard([
        [Markup.button.callback(`👀 عرض الطلب #${orderId}`, `order_${orderId}`)],
        [Markup.button.callback('📦 جميع الطلبات', 'orders')],
        [Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')]
      ]);
      
      await ctx.reply(adminMessage, { parse_mode: 'Markdown', ...adminKeyboard });
      
      // Send notification to customer
      try {
        await NotificationService.notifyOrderCompleted(order, user!, product!, category!, text);
      } catch (error) {
        console.error('Error sending customer notification:', error);
        await ctx.reply('⚠️ تم إكمال الطلب ولكن فشل في إرسال الإشعار للعميل');
      }
      
      // Reset session
      session.currentStep = 'main';
      session.currentOrder = null;
      return;
    }
    
    // Handle cancellation reason input
    if (session.currentStep === 'waiting_cancellation_reason' && session.currentOrder) {
      const orderId = session.currentOrder;
      
      // Use atomic cancellation method for safety
      const result = await storage.cancelOrderAtomic(orderId, userId, text);
      
      if (!result.success) {
        await ctx.reply(`❌ ${result.error}`);
        session.currentStep = 'main';
        session.currentOrder = null;
        return;
      }
      
      const order = result.order!;
      
      // Get user info for notification
      const user = await storage.getUser(order.userId);
      const product = await storage.getProduct(order.productId);
      const category = await storage.getCategory(order.categoryId);
      
      const username = user?.username || `المستخدم ${order.userId}`;
      const productName = product?.name || 'منتج محذوف';
      const categoryName = category?.name || 'فئة محذوفة';
      
      // Send success confirmation to admin
      let adminMessage = `❌ **تم إلغاء الطلب #${orderId} بنجاح!**\n\n`;
      adminMessage += `👤 العميل: ${username}\n`;
      adminMessage += `🎮 المنتج: ${productName} - ${categoryName}\n`;
      adminMessage += `💰 المبلغ المُسترد: ⭐ ${order.paidAmount || 0}\n`;
      adminMessage += `📝 سبب الإلغاء:\n${text}\n\n`;
      adminMessage += `📧 تم إرسال إشعار للعميل تلقائياً`;
      
      const adminKeyboard = Markup.inlineKeyboard([
        [Markup.button.callback(`👀 عرض الطلب #${orderId}`, `order_${orderId}`)],
        [Markup.button.callback('📦 جميع الطلبات', 'orders')],
        [Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')]
      ]);
      
      await ctx.reply(adminMessage, { parse_mode: 'Markdown', ...adminKeyboard });
      
      // Send notification to customer
      try {
        await NotificationService.notifyOrderCancelled(order, user!, text, order.paidAmount || 0);
      } catch (error) {
        console.error('Error sending customer notification:', error);
        await ctx.reply('⚠️ تم إلغاء الطلب واسترداد المبلغ ولكن فشل في إرسال الإشعار للعميل');
      }
      
      // Reset session
      session.currentStep = 'main';
      session.currentOrder = null;
      return;
    }

    // Removed old subcategory price handler - replaced with simplified system above

  } catch (error) {
    console.error('Error handling text message:', error);
    await ctx.reply('❌ حدث خطأ أثناء معالجة الرسالة.');
  }
});

// 🚀 Simplified Product Creation Function
async function createSimplifiedProduct(ctx: any, session: any) {
  try {
    await ctx.answerCbQuery('جاري إنشاء المنتج...');
    
    // Create the product
    const newProduct = await storage.createProduct({
      name: session.productData.name,
      description: session.productData.description,
      categoryId: 1, // Default category
      shippingType: session.productData.shippingType
    });
    
    // Reset session
    session.currentStep = 'main';
    session.productData = null;
    
    const shippingText: { [key: string]: string } = {
      'user_id': 'معرف المستخدم',
      'email': 'البريد الإلكتروني', 
      'phone': 'رقم الهاتف'
    };
    
    const successMessage = `✅ **تم إنشاء المنتج بنجاح!**\n\n` +
      `📱 اسم المنتج: ${newProduct.name}\n` +
      `📝 الوصف: ${newProduct.description}\n` +
      `🚚 نوع الشحن: ${shippingText[newProduct.shippingType] || newProduct.shippingType}\n` +
      `🆔 معرف المنتج: #${newProduct.id}\n\n` +
      `🎯 **الخطوة التالية:** أضف فئات (أسعار) لهذا المنتج`;
    
    await safeEditMessage(ctx, successMessage, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback(`💎 إضافة فئة لـ ${newProduct.name}`, `add_category_to_${newProduct.id}`)],
        [Markup.button.callback('📋 عرض جميع المنتجات', 'manage_existing_products')],
        [Markup.button.callback('🏠 القائمة الرئيسية', 'back_to_main')]
      ])
    });
    
  } catch (error) {
    console.error('Error creating simplified product:', error);
    await ctx.reply('❌ حدث خطأ أثناء إنشاء المنتج. حاول مرة أخرى.');
    session.currentStep = 'main';
    session.productData = null;
  }
}

// 💎 Add Category to Product Handler
bot.action(/add_category_to_(\d+)/, async (ctx) => {
  const productId = parseInt(ctx.match![1]);
  const userId = ctx.from?.id;
  
  if (!userId || !isAdmin(userId)) {
    await ctx.answerCbQuery('❌ غير مصرح لك بهذا الإجراء');
    return;
  }

  try {
    const product = await storage.getProduct(productId);
    if (!product) {
      await ctx.answerCbQuery('❌ المنتج غير موجود');
      return;
    }

    const session = getAdminSession(userId);
    session.currentStep = 'adding_simple_category_name';
    session.selectedProductId = productId;

    await ctx.answerCbQuery();
    await safeEditMessage(ctx,
      `💎 **إضافة فئة جديدة**\n\n` +
      `📱 المنتج: ${product.name}\n\n` +
      `📝 **خطوة 1/2:** أرسل اسم الفئة\n` +
      `💡 مثال: 60 شدة، 300 شدة، 1200 شدة\n\n` +
      `👆 أكتب اسم الفئة الآن:`,
      {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('❌ إلغاء', `edit_product_${productId}`)]
        ])
      }
    );
  } catch (error) {
    console.error('Error in add_category_to:', error);
    await ctx.answerCbQuery('❌ حدث خطأ');
  }
});

export async function startAdminBot(): Promise<void> {
  try {
    console.log('🔧 Starting admin bot...');
    
    // Clear any existing webhook first - SAME AS USER BOT
    await bot.telegram.deleteWebhook();
    console.log('🗑️ Cleared admin bot webhook');
    
    // Test bot connection first - SAME AS USER BOT
    const botInfo = await bot.telegram.getMe();
    console.log(`📱 Admin bot info: @${botInfo.username} (ID: ${botInfo.id})`);
    
    // Configure bot settings - SAME AS USER BOT
    bot.telegram.webhookReply = false;
    
    // Start the bot without timeout - ALLOW ALL UPDATES
    console.log('🚀 Launching admin bot...');
    bot.launch({
      dropPendingUpdates: true
      // Remove allowedUpdates restriction to allow all updates including callback_query  
    }).then(() => {
      console.log('✅ Admin bot connected and ready!');
    }).catch((error) => {
      console.error('❌ Admin bot launch failed:', error);
      console.log('🔄 Will retry in 10 seconds...');
      setTimeout(() => startAdminBot(), 10000);
    });
    
    // Don't wait for launch - return immediately - SAME AS USER BOT
    console.log('🎆 Admin bot startup initiated');
    
  } catch (error) {
    console.error('❌ Failed to start admin bot:', error);
    console.log('🔄 Retrying in 5 seconds...');
    setTimeout(() => startAdminBot(), 5000);
  }
}

// Graceful shutdown
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
