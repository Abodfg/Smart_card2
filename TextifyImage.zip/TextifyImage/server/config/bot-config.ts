export const BOT_CONFIG = {
  USER_BOT_TOKEN: process.env.USER_BOT_TOKEN!,
  ADMIN_BOT_TOKEN: process.env.ADMIN_BOT_TOKEN!,
  PAYMENT_TOKEN: process.env.PAYMENT_TOKEN || '1877036958:TEST:ff33b93779c2a0821d986fc97943d8cfaec36851',
  
  // Admin user IDs (you can add more admin IDs here)
  ADMIN_IDS: [
    7040570081, // Main admin ID as specified in requirements
  ],
  
  // Bot settings
  WEBHOOK_URL: process.env.WEBHOOK_URL || '',
  PORT: parseInt(process.env.PORT || '5000'),
  
  // Messages
  MESSAGES: {
    WELCOME: '🎮 أهلاً بك في بوت شحن الألعاب والاشتراكات الرقمية 🎮\nاختر الخدمة من القائمة 👇',
    SUPPORT_INFO: '📩 للتواصل مع الدعم الفني:\n@AbodStoreVIP',
    DEVELOPER_INFO: 'عبود طالب IT ومطور بوتات تليجرام\nللطلب: @AbodStoreVIP',
    ORDER_SUCCESS: '✅ تم استلام طلبك بنجاح.\nرقم الطلب: #{orderId}\nالحالة: جاري المعالجة...',
    ORDER_COMPLETED: '✅ تم تنفيذ طلبك\nالمنتج: {product}\nالفئة: {category}\nالتفاصيل: {details}',
    PAYMENT_REQUIRED: '💳 يرجى إتمام الدفع لتأكيد طلبك',
    INVALID_INPUT: '❌ البيانات المدخلة غير صحيحة، يرجى المحاولة مرة أخرى',
    ORDER_CANCELLED: '❌ تم إلغاء طلبك',
  }
};
